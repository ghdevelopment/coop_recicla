import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import { initDB } from './db.js'
import postsRouter from './routes/posts.js'
import worksRouter from './routes/works.js'
import tagsRouter from './routes/tags.js'
import uploadRouter from './routes/upload.js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'
import authRouter from './routes/auth.js'

const app = express()
const PORT = process.env.PORT || 5050

await initDB()

// Security headers
app.use(helmet())

// Body parsing
app.use(express.json({ limit: '1mb' }))

// CORS - allow dev client(s)
// If CORS_ORIGINS is set, use it (comma-separated). Otherwise allow localhost, 127.0.0.1 and LAN origins in dev.
const envOrigins = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean)
const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true) // non-browser or same-origin via proxy
    if (envOrigins.length > 0) {
      return callback(null, envOrigins.includes(origin))
    }
    const isLocal = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)
    const isLAN = /^http:\/\/(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?$/.test(origin)
    return callback(null, isLocal || isLAN)
  },
  credentials: false,
}
app.use(cors(corsOptions))

// Basic rate limiting
const limiter = rateLimit({ windowMs: 60 * 1000, max: 300 })
app.use(limiter)

// Health
app.get('/api/health', (req, res) => res.json({ ok: true }))

// Routes
app.use('/api/auth', authRouter)
app.use('/api/posts', postsRouter)
app.use('/api/works', worksRouter)
app.use('/api/tags', tagsRouter)
app.use('/api/upload', uploadRouter)

// Static serving for uploaded files
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const uploadsDir = path.resolve(__dirname, 'uploads')
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}
app.use('/api/uploads', express.static(uploadsDir))

app.use((err, req, res, next) => {
  console.error(err)
  res.status(err.status || 500).json({ error: err.message || 'Erro interno' })
})

app.listen(PORT, () => {
  console.log(`[server] API rodando em http://localhost:${PORT}`)
})
