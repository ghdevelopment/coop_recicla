import express from 'express'
import jwt from 'jsonwebtoken'
import { z } from 'zod'
import { db } from '../db.js'

const router = express.Router()

const LoginSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(3)
})

router.post('/login', async (req, res) => {
  const parse = LoginSchema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  const { username, password } = parse.data
  await db.read()
  const user = db.data.users.find((u) => u.username === username)
  if (!user) return res.status(401).json({ error: 'Usuário ou senha incorretos.' })

  // bcryptjs compareSync to avoid native deps
  const { default: bcrypt } = await import('bcryptjs')
  const ok = bcrypt.compareSync(password, user.passwordHash)
  if (!ok) return res.status(401).json({ error: 'Usuário ou senha incorretos.' })

  const secret = process.env.JWT_SECRET || 'dev-secret-change-me'
  const token = jwt.sign({ sub: user.id, username: user.username, role: user.role }, secret, { expiresIn: '8h' })
  res.json({ token, user: { id: user.id, username: user.username, role: user.role } })
})

export default router
