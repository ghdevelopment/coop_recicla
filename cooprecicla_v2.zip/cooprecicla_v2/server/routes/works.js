import express from 'express'
import { z } from 'zod'
import { db, findOrCreateTagsByNames, expandTags } from '../db.js'
import { requireAuth } from '../middleware/auth.js'
import { nanoid } from 'nanoid'

const router = express.Router()

const WorkSchema = z.object({
  title: z.string().min(3),
  // Tornar restantes opcionais para simplificar "acadêmicos"
  author: z.string().min(2).optional(),
  // adiciona novas categorias: 'children' (Histórias Infantis) e 'law' (Leis)
  category: z.enum(['academic', 'books', 'articles', 'manuals', 'children', 'law']).optional(),
  year: z.number().int().min(1900).max(new Date().getFullYear() + 1).optional(),
  pages: z.number().int().min(1).max(10000).optional(),
  description: z.string().min(5).max(1000),
  // URL única de redirecionamento (alias para previewUrl)
  url: z.string().url().optional(),
  downloadUrl: z.string().url().optional().or(z.literal('#')).optional(),
  previewUrl: z.string().url().optional().or(z.literal('#')).optional(),
  image: z.string().optional(),
  tags: z.array(z.string()).optional()
})

router.get('/', async (req, res) => {
  await db.read()
  let items = db.data.works
  const { category, tag, search, sort } = req.query
  if (category) items = items.filter((w) => w.category === category)
  if (tag) {
    const t = db.data.tags.find((t) => t.slug === tag || t.name === tag)
    if (t) items = items.filter((w) => w.tagIds?.includes(t.id))
    else items = []
  }
  if (search) {
    const s = String(search).toLowerCase()
    items = items.filter((w) =>
      w.title.toLowerCase().includes(s) || (w.author || '').toLowerCase().includes(s) || (w.description || '').toLowerCase().includes(s)
    )
  }
  const srt = sort || '-createdAt'
  if (srt === '-createdAt') {
    items = items.slice().sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
  } else if (srt === 'createdAt') {
    items = items.slice().sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0))
  }
  res.json(items.map((w) => ({ ...w, tags: expandTags(w.tagIds || []) })))
})

router.post('/', requireAuth, async (req, res) => {
  const parse = WorkSchema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  await db.read()
  const { tags = [], url, ...data } = parse.data
  const tagIds = findOrCreateTagsByNames(tags)
  const work = {
    id: nanoid(),
    title: data.title,
    description: data.description,
    image: data.image,
    author: data.author || '',
    category: data.category || 'academic',
    year: data.year,
    pages: data.pages,
    // mapear url -> previewUrl; manter downloadUrl opcional
    previewUrl: data.previewUrl || url || '#',
    downloadUrl: data.downloadUrl || '#',
    tagIds,
    createdAt: new Date().toISOString()
  }
  db.data.works.unshift(work)
  await db.write()
  res.status(201).json({ ...work, tags: expandTags(tagIds) })
})

router.put('/:id', requireAuth, async (req, res) => {
  const parse = WorkSchema.partial().safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  await db.read()
  const idx = db.data.works.findIndex((w) => w.id === req.params.id)
  if (idx === -1) return res.status(404).json({ error: 'Não encontrado' })
  const current = db.data.works[idx]
  const { tags, url, ...data } = parse.data
  let tagIds = current.tagIds || []
  if (tags) tagIds = findOrCreateTagsByNames(tags)
  const updated = { ...current, ...data, tagIds }
  if (url && !data.previewUrl) updated.previewUrl = url
  if (!updated.category) updated.category = 'academic'
  db.data.works[idx] = updated
  await db.write()
  res.json({ ...updated, tags: expandTags(tagIds) })
})

router.delete('/:id', requireAuth, async (req, res) => {
  await db.read()
  const before = db.data.works.length
  db.data.works = db.data.works.filter((w) => w.id !== req.params.id)
  if (db.data.works.length === before) return res.status(404).json({ error: 'Não encontrado' })
  await db.write()
  res.status(204).end()
})

export default router
