import express from 'express'
import { z } from 'zod'
import { db } from '../db.js'
import { requireAuth } from '../middleware/auth.js'
import { nanoid } from 'nanoid'

const router = express.Router()

router.get('/', async (req, res) => {
  await db.read()
  res.json(db.data.tags)
})

router.post('/', requireAuth, async (req, res) => {
  const schema = z.object({ name: z.string().min(2) })
  const parse = schema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  const name = parse.data.name.trim()
  const slug = name.toLowerCase().replace(/\s+/g, '-')
  await db.read()
  const exists = db.data.tags.find((t) => t.slug === slug)
  if (exists) return res.status(409).json({ error: 'Tag já existe' })
  const tag = { id: nanoid(), name, slug }
  db.data.tags.push(tag)
  await db.write()
  res.status(201).json(tag)
})

router.delete('/:id', requireAuth, async (req, res) => {
  await db.read()
  const before = db.data.tags.length
  db.data.tags = db.data.tags.filter((t) => t.id !== req.params.id)
  if (db.data.tags.length === before) return res.status(404).json({ error: 'Não encontrado' })
  await db.write()
  res.status(204).end()
})

export default router
