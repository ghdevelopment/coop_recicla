import express from 'express'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'
import { requireAuth } from '../middleware/auth.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const uploadsDir = path.resolve(__dirname, '..', 'uploads')

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

const allowedMime = new Set(['image/jpeg', 'image/png', 'image/webp'])

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase()
    const base = path.basename(file.originalname, ext).replace(/[^a-z0-9-_]/gi, '_')
    const name = `${Date.now()}_${Math.random().toString(36).slice(2,8)}_${base}${ext}`
    cb(null, name)
  },
})

const upload = multer({
  storage,
  // sem limite de tamanho por solicitação do usuário (cuidado em produção)
  fileFilter: (req, file, cb) => {
    if (allowedMime.has(file.mimetype)) return cb(null, true)
    cb(new Error('Tipo de arquivo não suportado. Use JPG, PNG ou WEBP.'))
  },
})

const router = express.Router()

// Auth required
router.post('/', requireAuth, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Arquivo não enviado' })
  const url = `/api/uploads/${req.file.filename}`
  res.status(201).json({
    url,
    filename: req.file.filename,
    originalName: req.file.originalname,
    size: req.file.size,
    type: req.file.mimetype,
  })
})

export default router
