import express from 'express'
import { z } from 'zod'
import { db, findOrCreateTagsByNames, expandTags } from '../db.js'
import { requireAuth } from '../middleware/auth.js'
import rateLimit from 'express-rate-limit'
import { nanoid } from 'nanoid'
import jwt from 'jsonwebtoken'
import sanitizeHtml from 'sanitize-html'

const router = express.Router()

// Accept image as full URL or backend-served relative path (/api/uploads/..), or empty
const ImageField = z.union([z.literal(''), z.string()])
  .optional()
  .refine(
    (v) =>
      v === undefined ||
      v === '' ||
      /^https?:\/\//.test(v) ||
      (typeof v === 'string' && v.startsWith('/api/uploads/')),
    { message: 'Imagem inválida' }
  )

const PostSchema = z.object({
  titulo: z.string().min(3),
  resumo: z.string().min(10).max(500),
  conteudo: z.string().min(10),
  categoria: z.string().min(2),
  status: z.enum(['Rascunho', 'Publicado', 'Arquivado']),
  autor: z.string().min(2).optional(),
  imagem: ImageField,
  tags: z.array(z.string()).optional()
})

// HTML sanitization options for rich content with images
const sanitizeOptions = {
  allowedTags: sanitizeHtml.defaults.allowedTags.concat(['img', 'figure', 'figcaption']),
  allowedAttributes: {
    ...sanitizeHtml.defaults.allowedAttributes,
    img: ['src', 'alt', 'title', 'width', 'height', 'style'],
    a: ['href', 'name', 'target', 'rel'],
    div: ['style'],
    span: ['style'],
    p: ['style'],
    figure: ['style']
  },
  allowedStyles: {
    '*': {
      'text-align': [/^left$|^right$|^center$/],
      'float': [/^left$|^right$|^none$/],
      'margin': [/^[0-9.]+(px|rem|em|%)?(\s[0-9.]+(px|rem|em|%)?){0,3}$|^0$/],
      'width': [/^[0-9.]+(px|%|rem|em)$/],
      'height': [/^[0-9.]+(px|%|rem|em)$/],
      'display': [/^block$|^inline$|^inline-block$|^flex$/],
      'max-width': [/^[0-9.]+(px|%|rem|em)$/]
    }
  },
  transformTags: {
    'a': sanitizeHtml.simpleTransform('a', { rel: 'noopener noreferrer' })
  }
}

// List with simple filters
router.get('/', async (req, res) => {
  await db.read()
  let items = db.data.posts
  const { status, categoria, tag, search, limit, sort } = req.query

  if (status) items = items.filter((p) => p.status === status)
  if (categoria) items = items.filter((p) => p.categoria === categoria)
  if (tag) {
    const t = db.data.tags.find((t) => t.slug === tag || t.name === tag)
    if (t) items = items.filter((p) => p.tagIds?.includes(t.id))
    else items = []
  }
  if (search) {
    const s = String(search).toLowerCase()
    items = items.filter((p) =>
      p.titulo.toLowerCase().includes(s) ||
      p.resumo.toLowerCase().includes(s) ||
      p.conteudo.toLowerCase().includes(s)
    )
  }

  // sort: '-data' or 'data' — funciona com ISO datetime
  if (sort === '-data') items = items.sort((a, b) => new Date(b.data) - new Date(a.data))
  if (sort === 'data')  items = items.sort((a, b) => new Date(a.data) - new Date(b.data))

  const lim = Math.min(Number(limit) || items.length, 100)
  const mapped = items.slice(0, lim).map((p) => ({ ...p, tags: expandTags(p.tagIds || []) }))
  res.json(mapped)
})

router.get('/:id', async (req, res) => {
  await db.read()
  const post = db.data.posts.find((p) => p.id === req.params.id)
  if (!post) return res.status(404).json({ error: 'Não encontrado' })
  // Only published posts are public; drafts/archived require a valid JWT (preview)
  if (post.status !== 'Publicado') {
    const header = req.headers.authorization || ''
    const token = header.startsWith('Bearer ') ? header.slice(7) : null
    if (!token) return res.status(404).json({ error: 'Não encontrado' })
    try {
      const secret = process.env.JWT_SECRET || 'dev-secret-change-me'
      jwt.verify(token, secret)
    } catch {
      return res.status(404).json({ error: 'Não encontrado' })
    }
  }
  res.json({ ...post, tags: expandTags(post.tagIds || []) })
})

router.post('/', requireAuth, async (req, res) => {
  const parse = PostSchema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })

  await db.read()
  const { tags = [], ...data } = parse.data

  const conteudoSanitizado = sanitizeHtml(data.conteudo, sanitizeOptions)
  const tagIds = findOrCreateTagsByNames(tags)

  const now = new Date().toISOString() // ⬅️ datetime completo

  const post = {
    id: nanoid(),
    ...data,
    conteudo: conteudoSanitizado,
    autor: 'Equipe COOP-Recicla',
    data: now,                // ⬅️ salva ISO completo (antes: slice(0,10))
    visualizacoes: 0,
    tagIds
  }

  db.data.posts.unshift(post)
  await db.write()
  res.status(201).json({ ...post, tags: expandTags(tagIds) })
})

router.put('/:id', requireAuth, async (req, res) => {
  const parse = PostSchema.partial().safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })

  await db.read()
  const idx = db.data.posts.findIndex((p) => p.id === req.params.id)
  if (idx === -1) return res.status(404).json({ error: 'Não encontrado' })

  const current = db.data.posts[idx]
  const { tags, ...data } = parse.data
  let tagIds = current.tagIds || []
  if (tags) tagIds = findOrCreateTagsByNames(tags)

  const updated = { ...current, ...data, autor: 'Equipe COOP-Recicla', tagIds }

  if (typeof data.conteudo === 'string') {
    updated.conteudo = sanitizeHtml(data.conteudo, sanitizeOptions)
  }

  db.data.posts[idx] = updated
  await db.write()
  res.json({ ...updated, tags: expandTags(tagIds) })
})

router.delete('/:id', requireAuth, async (req, res) => {
  await db.read()
  const before = db.data.posts.length
  db.data.posts = db.data.posts.filter((p) => p.id !== req.params.id)
  if (db.data.posts.length === before) return res.status(404).json({ error: 'Não encontrado' })
  await db.write()
  res.status(204).end()
})

// Increment views - rate limited per IP
router.post('/:id/view', rateLimit({ windowMs: 60 * 1000, max: 30 }), async (req, res) => {
  await db.read()
  const post = db.data.posts.find((p) => p.id === req.params.id)
  if (!post) return res.status(404).json({ error: 'Não encontrado' })
  if (post.status !== 'Publicado') {
    return res.json({ visualizacoes: post.visualizacoes || 0 })
  }
  post.visualizacoes = (post.visualizacoes || 0) + 1
  await db.write()
  res.json({ visualizacoes: post.visualizacoes })
})

export default router
