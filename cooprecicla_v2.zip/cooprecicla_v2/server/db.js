import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'
import path from 'path'
import { fileURLToPath } from 'url'
import { nanoid } from 'nanoid'
import bcrypt from 'bcryptjs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const dataDir = path.resolve(__dirname, '..', 'data')
const dbFile = path.resolve(dataDir, 'db.json')

// Ensure directory exists
import fs from 'fs'
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true })
}

const adapter = new JSONFile(dbFile)
export const db = new Low(adapter, { posts: [], works: [], tags: [], users: [] })

export async function initDB() {
  await db.read()
  if (!db.data) {
    db.data = { posts: [], works: [], tags: [], users: [] }
  }

  // Seed admin user if none
  if (!db.data.users || db.data.users.length === 0) {
    const passwordHash = bcrypt.hashSync('admin123', 10)
    db.data.users = [
      { id: nanoid(), username: 'admin', passwordHash, role: 'admin', createdAt: new Date().toISOString() }
    ]
  }

  // Ensure arrays exist
  db.data.posts ||= []
  db.data.works ||= []
  db.data.tags ||= []

  // Normalize: enforce default author on posts
  const DEFAULT_AUTHOR = 'Equipe COOP-Recicla'
  let changed = false
  for (const p of db.data.posts) {
    if (p.autor !== DEFAULT_AUTHOR) {
      p.autor = DEFAULT_AUTHOR
      changed = true
    }
  }

  if (changed) {
    await db.write()
  } else {
    await db.write()
  }
}

export function findOrCreateTagsByNames(names = []) {
  const sluggify = (s) => s.toString().trim().toLowerCase().replace(/\s+/g, '-')
  const ids = []
  names.forEach((name) => {
    const slug = sluggify(name)
    let tag = db.data.tags.find((t) => t.slug === slug)
    if (!tag) {
      tag = { id: nanoid(), name: name.trim(), slug }
      db.data.tags.push(tag)
    }
    ids.push(tag.id)
  })
  return ids
}

export function expandTags(ids = []) {
  const tags = ids.map((id) => db.data.tags.find((t) => t.id === id)).filter(Boolean)
  return tags.map((t) => ({ id: t.id, name: t.name, slug: t.slug }))
}
