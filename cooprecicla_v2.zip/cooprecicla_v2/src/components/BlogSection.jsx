import { useEffect, useState } from 'react'
import { ArrowRight, CalendarDays } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { api } from '@/lib/api'
import { normalizeImageUrl } from '@/lib/utils'

const BlogSection = () => {
  const [posts, setPosts] = useState([])

  useEffect(() => {
    const load = async () => {
      const data = await api.listPosts({ status: 'Publicado', sort: '-data', limit: 3 })
      setPosts(
        data.map((p) => ({
          id: p.id,
          title: p.titulo,
          date: new Date(p.data).toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
          }),
          excerpt: p.resumo,
          link: `/novidades/publicacoes/${p.id}`,
          cover: normalizeImageUrl(p.imagem || null),
        }))
      )
    }
    load()
  }, [])

  return (
    <section id="blog" className="py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Nosso Blog
          </h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">
            Últimas Notícias e Eventos
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Fique por dentro das novidades, projetos e ações da COOP RECICLA em prol da
            sustentabilidade e da comunidade.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8 mb-16">
          {posts.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 flex flex-col h-full"
            >
              {/* Capa responsiva (menor no mobile) */}
              {post.cover ? (
                <Link to={post.link} className="block">
                  <div className="relative w-full bg-gray-100 overflow-hidden">
                    {/* Alturas por breakpoint; em lg vira 16:9 */}
                    <div className="w-full h-40 sm:h-52 md:h-56 lg:h-auto lg:aspect-[16/9]">
                      <img
                        src={post.cover}
                        alt={post.title}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        decoding="async"
                      />
                    </div>
                  </div>
                </Link>
              ) : (
                <div className="w-full h-40 sm:h-52 md:h-56 lg:h-auto lg:aspect-[16/9] bg-gradient-to-br from-green-400 to-green-600" />
              )}

              {/* Conteúdo */}
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center text-gray-500 text-sm">
                  <CalendarDays size={16} className="mr-2" />
                  <span>{post.date}</span>
                </div>

                <h4 className="mt-2 text-xl font-bold text-gray-900 leading-tight line-clamp-2">
                  {post.title}
                </h4>

                <p className="mt-2 text-gray-600 leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>

                {/* empurra o botão pro rodapé para padronizar alturas */}
                <div className="flex-1" />

                {/* Botão verde padronizado, mantendo Arrow */}
                <div className="mt-4">
                  <Link to={post.link}>
                    <Button className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 rounded-full text-sm md:text-base flex items-center justify-center">
                      Ler Mais
                      <ArrowRight className="ml-2" size={16} />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/novidades/publicacoes">
              <Button
                variant="outline"
                size="lg"
                className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 rounded-full text-lg font-semibold"
              >
                Ver Todas as Publicações
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default BlogSection
