import { useEffect, useMemo, useState, useCallback } from 'react'
import { useParams, useSearchParams, Link, useLocation } from 'react-router-dom'
import { api } from '@/lib/api'
import { Badge } from '@/components/ui/badge'
import {
  Calendar, Eye, User, ArrowLeft, Tag as TagIcon,
  Share2, Copy, ArrowUpRight
} from 'lucide-react'
import { Button } from '@/components/ui/button'

function fmtDate(d) {
  try {
    return new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })
  } catch { return d }
}

export default function PostPage() {
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const isPreview = searchParams.get('preview') === '1'
  const [post, setPost] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [related, setRelated] = useState([])
  const location = useLocation()

  const shareUrl = useMemo(
    () => (typeof window !== 'undefined' ? window.location.origin + location.pathname : ''),
    [location]
  )
  const handleCopy = useCallback(async () => {
    try { await navigator.clipboard.writeText(shareUrl); alert('Link copiado!') }
    catch { alert('Não foi possível copiar o link.') }
  }, [shareUrl])

  useEffect(() => {
    let mounted = true
    const load = async () => {
      setLoading(true); setError('')
      try {
        const data = await api.getPost(id, { preview: isPreview })
        if (!mounted) return
        setPost(data)
        if (data.status === 'Publicado' && !isPreview) api.viewPost(id).catch(() => {})
        try {
          const rel = await api.listPosts({ limit: 6, categoria: data.categoria, exclude: data.id })
          if (mounted) setRelated((rel || []).filter(r => r.id !== data.id).slice(0, 3))
        } catch {}
      } catch (e) {
        setError(e.message || 'Publicação não encontrada')
      } finally { if (mounted) setLoading(false) }
    }
    load(); return () => { mounted = false }
  }, [id, isPreview])

  if (loading) return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-10 max-w-5xl">
        <div className="h-5 w-32 bg-gray-200 rounded animate-pulse mb-3" />
        <div className="h-8 w-3/4 bg-gray-200 rounded animate-pulse mb-6" />
        <div className="h-64 w-full bg-gray-200 rounded-xl animate-pulse mb-8" />
        <div className="space-y-3">
          <div className="h-4 w-full bg-gray-200 rounded animate-pulse" />
          <div className="h-4 w-5/6 bg-gray-200 rounded animate-pulse" />
        </div>
      </div>
    </div>
  )

  if (error || !post || (post.status !== 'Publicado' && !isPreview)) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center">
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-semibold text-gray-900 mb-2">Publicação não encontrada</h1>
          <p className="text-gray-600 mb-6">A publicação pode ter sido removida ou o link está incorreto.</p>
          <Link to="/novidades">
            <Button className="bg-green-600 hover:bg-green-700">Voltar às Publicações</Button>
          </Link>
        </div>
      </div>
    )
  }

  const tags = (post.tags || []).map(t => t.name || t)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Preview banner */}
      {isPreview && (
        <div className="bg-yellow-50 border-b border-yellow-200">
          <div className="container mx-auto px-4 py-2 text-yellow-800 text-sm flex items-center justify-between max-w-6xl">
            <span>Pré-visualização ({post.status}). Somente você pode ver esta página.</span>
            <Link to={`/novidades/publicacoes/${post.id}`} className="underline">Ver versão pública</Link>
          </div>
        </div>
      )}

      {/* HERO enxuto */}
      <div className="bg-green-600 text-white">
        <div className="container mx-auto px-4 py-4 max-w-6xl">
          <div className="flex items-center justify-between">
            <Link to="/novidades/publicacoes">
              <Button variant="ghost" className="text-white hover:bg-white/10 px-0">
                <ArrowLeft className="mr-2" size={16} /> Todas as Publicações
              </Button>
            </Link>
            <Badge className="bg-white text-green-700 rounded-full">{post.categoria}</Badge>
          </div>
        </div>
      </div>

      {/* CARTÃO PRINCIPAL */}
      <div className="container mx-auto px-4 py-8">
        <article className="mx-auto w-full max-w-3xl bg-white rounded-2xl shadow-sm ring-1 ring-black/5 p-6 md:p-8">
          {/* Título + meta + share */}
          <header className="mb-6">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight mb-3">
              {post.titulo}
            </h1>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-gray-600 text-sm">
              <span className="inline-flex items-center"><User size={14} className="mr-1" /> {post.autor}</span>
              <span className="inline-flex items-center"><Calendar size={14} className="mr-1" /> {fmtDate(post.data)}</span>
              <span className="ml-auto inline-flex gap-2">
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(post.titulo + ' ' + shareUrl)}`}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center text-sm font-medium bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-md px-3 py-2"
                >
                  <Share2 size={14} className="mr-2" /> Compartilhar
                </a>
              </span>
            </div>
          </header>

          {/* Capa (contida, elegante) */}
          {post.imagem && (
            <figure className="mb-6 rounded-xl overflow-hidden bg-white">
              <img
                src={post.imagem}
                alt={post.titulo}
                className="w-full max-h-[520px] object-contain bg-white rounded-xl shadow-md ring-1 ring-black/5"
                loading="lazy"
              />
            </figure>
          )}

          {/* Conteúdo */}
          <div className="prose prose-lg max-w-none text-gray-800 prose-a:text-green-700 hover:prose-a:text-green-800 prose-img:rounded-xl prose-img:shadow-sm">
            {/* Se vier HTML pronto, troque por dangerouslySetInnerHTML com sanitização */}
            <div className="whitespace-pre-line">{post.conteudo}</div>
          </div>

          {/* Tags */}
          {tags.length > 0 && (
            <div className="mt-8 pt-6 border-t">
              <div className="flex items-center gap-2 text-gray-700 mb-2">
                <TagIcon size={18} /> Tags
              </div>
              <div className="flex flex-wrap gap-2">
                {tags.map((t, i) => (
                  <Badge key={i} variant="secondary" className="text-xs rounded-full">{t}</Badge>
                ))}
              </div>
            </div>
          )}
        </article>
      </div>

      {/* RELACIONADOS */}
      {related?.length > 0 && (
        <div className="container mx-auto px-4 pb-14">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg md:text-xl font-semibold text-gray-900">Mais sobre {post.categoria}</h2>
              <Link to="/novidades/publicacoes" className="text-green-700 text-sm inline-flex items-center">
                Ver todas <ArrowUpRight size={16} className="ml-1" />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {related.map((r) => (
                <Link key={r.id} to={`/novidades/publicacoes/${r.id}`} className="group bg-white rounded-2xl overflow-hidden shadow-sm ring-1 ring-black/5 hover:shadow-md transition">
                  <div className="aspect-[16/9] overflow-hidden bg-gray-100">
                    <img src={r.imagem} alt={r.titulo} className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300" loading="lazy" />
                  </div>
                  <div className="p-4">
                    <Badge variant="secondary" className="mb-2 rounded-full">{r.categoria}</Badge>
                    <h3 className="font-semibold text-gray-900 line-clamp-2 mb-1">{r.titulo}</h3>
                    <div className="text-xs text-gray-600 flex items-center gap-3">
                      <span className="inline-flex items-center gap-1"><Calendar size={14} /> {fmtDate(r.data)}</span>
                      <span className="inline-flex items-center gap-1"><User size={14} /> {r.autor}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
