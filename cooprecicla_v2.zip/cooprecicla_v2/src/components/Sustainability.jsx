import { Leaf, Droplets, Zap, TreePine, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'

const Sustainability = () => {
  const impactData = [
    {
      icon: <Leaf className="text-green-600" size={32} />,
      value: "1.200+",
      unit: "Toneladas",
      description: "de carbono não emitido na atmosfera",
      bgColor: "bg-green-100"
    },
    {
      icon: <TreePine className="text-green-600" size={32} />,
      value: "15.000+",
      unit: "Árvores",
      description: "preservadas na fabricação de papel",
      bgColor: "bg-green-100"
    },
    {
      icon: <Zap className="text-yellow-600" size={32} />,
      value: "2.500",
      unit: "MWh",
      description: "reduzidos em gastos energéticos",
      bgColor: "bg-yellow-100"
    },
    {
      icon: <Droplets className="text-blue-600" size={32} />,
      value: "50.000+",
      unit: "Litros",
      description: "economizados na fabricação de novos materiais",
      bgColor: "bg-blue-100"
    }
  ]

  return (
    <section id="sustainability" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Sustentabilidade e Impacto
          </h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">
            Nosso Impacto no Meio Ambiente
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Através do nosso trabalho, contribuímos diretamente para a preservação ambiental 
            e o desenvolvimento sustentável da nossa região.
          </p>
        </div>

        {/* Impact Statistics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {impactData.map((item, index) => (
            <div 
              key={index}
              className="bg-white rounded-2xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow duration-300"
            >
              <div className={`w-16 h-16 ${item.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                {item.icon}
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-gray-900">{item.value}</div>
                <div className="text-sm font-semibold text-gray-700 uppercase tracking-wide">{item.unit}</div>
                <p className="text-gray-600 text-sm leading-relaxed">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Sustainability

