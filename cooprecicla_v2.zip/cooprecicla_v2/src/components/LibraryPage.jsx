import { useEffect, useMemo, useState } from 'react'
import { Search, BookOpen, FileText, GraduationCap, ExternalLink, Filter, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { normalizeImageUrl } from '@/lib/utils'
import { Link, useNavigate } from 'react-router-dom'
import { api } from '@/lib/api'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

const categories = [
  { id: 'all', name: 'Todas as Categorias', icon: BookOpen },
  { id: 'academic', name: 'Trabalhos Acadêmicos', icon: GraduationCap },
  { id: 'children', name: 'Infantil', icon: BookOpen },
  { id: 'law', name: 'Leis', icon: FileText },
  { id: 'books', name: 'Livros', icon: BookOpen },
  { id: 'articles', name: 'Artigos', icon: FileText },
  { id: 'manuals', name: 'Manuais', icon: FileText },
]

const typeLabel = (cat) =>
  ({
    academic: 'Trabalho Acadêmico',
    children: 'Infantil',
    law: 'Lei',
    books: 'Livro',
    articles: 'Artigo',
    manuals: 'Manual',
  }[cat] || 'Recurso')

const LibraryPage = () => {
  // ===== Estado de UI =====
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [sortBy, setSortBy] = useState('recent')
  const [currentPage, setCurrentPage] = useState(1)
  const perPage = 9

  // ===== Dados =====
  const [resources, setResources] = useState([])
  useEffect(() => {
    const load = async () => {
      const data = await api.listWorks({ sort: '-createdAt' })
      const sorted = [...data].sort(
        (a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)
      )
      const normalized = sorted.map((w) => ({
        ...w,
        image: normalizeImageUrl(w.image || w.imagem || null),
        previewUrl: w.previewUrl || w.url || '#',
      }))
      setResources(normalized)
    }
    load()
  }, [])

  // ===== Filtro + Ordenação =====
  const filteredAndSorted = useMemo(() => {
    const s = searchTerm.toLowerCase()
    const arr = resources
      .filter((r) => {
        const matchesSearch =
          (r.title || '').toLowerCase().includes(s) ||
          (r.description || '').toLowerCase().includes(s) ||
          (r.author || '').toLowerCase().includes(s)
        const matchesCategory = selectedCategory === 'all' || r.category === selectedCategory
        return matchesSearch && matchesCategory
      })
      .sort((a, b) => {
        if (sortBy === 'recent') return new Date(b.createdAt || 0) - new Date(a.createdAt || 0)
        if (sortBy === 'oldest') return new Date(a.createdAt || 0) - new Date(b.createdAt || 0)
        // 'title-asc'
        return (a.title || '').localeCompare(b.title || '')
      })
    return arr
  }, [resources, searchTerm, selectedCategory, sortBy])

  // ===== Paginação =====
  const total = filteredAndSorted.length
  const totalPages = Math.max(1, Math.ceil(total / perPage))
  const startIndex = (currentPage - 1) * perPage
  const currentItems = filteredAndSorted.slice(startIndex, startIndex + perPage)

  // resetar página quando filtro/busca mudar
  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm, selectedCategory, sortBy])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER PADRÃO */}
      <div className="bg-green-600 text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="mb-6">
            <Link to="/recursos-educacionais">
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white rounded-full px-6 py-2 flex items-center gap-2 transition-all">
                 <ArrowLeft size={20} />
                Voltar
              </Button>
            </Link>
            </div>
          <div className="max-w-4xl">
            <h1 className="text-4xl font-bold mb-4">Biblioteca de Recursos Educacionais</h1>
            <p className="text-xl text-green-100">
              Acesse nossa coleção completa de livros, manuais, trabalhos e artigos sobre sustentabilidade.
            </p>
          </div>
        </div>
      </div>

      {/* FILTROS / CONTROLES */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 lg:gap-6 justify-between flex-wrap">
            {/* Busca */}
            <div className="w-full lg:flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-green-700" size={16} />
                <Input
                  placeholder="Buscar por título, autor ou descrição..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-11 w-full sm:w-[32rem] md:w-[36rem] lg:w-full max-w-full"
                />
              </div>
            </div>

            {/* Controles à direita */}
            <div className="w-full lg:w-auto flex flex-col sm:flex-row gap-3 items-stretch sm:items-center flex-wrap">
              {/* Categoria */}
              <Select value={selectedCategory} onValueChange={(v) => setSelectedCategory(v)}>
                <SelectTrigger className="w-full sm:w-56 shrink-0 h-11 border-0 border-b-2 rounded-none focus:ring-0 focus:outline-none border-gray-200 focus:border-green-600">
                  <Filter size={16} className="mr-2 text-green-700" />
                  <SelectValue placeholder="Todas as Categorias"/>
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Ordenação */}
              <Select value={sortBy} onValueChange={(v) => setSortBy(v)}>
                <SelectTrigger className="w-full sm:w-48 shrink-0 h-11 border-0 border-b-2 rounded-none focus:ring-0 focus:outline-none border-gray-200 focus:border-green-600">
                  <Filter size={16} className="mr-2 text-green-700" />
                  <SelectValue placeholder="Mais Recentes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Mais Recentes</SelectItem>
                  <SelectItem value="oldest">Mais Antigos</SelectItem>
                  <SelectItem value="title-asc">Título (A–Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Estatísticas */}
          <div className="mt-4 pt-4 border-t grid gap-2 sm:flex sm:items-center sm:justify-between text-sm text-gray-600">
            <span>
              Mostrando {total === 0 ? 0 : startIndex + 1}-{Math.min(startIndex + perPage, total)} de {total} resultados
            </span>
          </div>
        </div>

        {/* RESULTADOS — GRID ÚNICO */}
        {currentItems.length === 0 ? (
          <div className="bg-white rounded-lg p-12 text-center shadow-sm">
            <Search className="mx-auto mb-4 text-gray-400" size={48} />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum resultado encontrado</h3>
            <p className="text-gray-600">Tente ajustar os termos de busca ou filtros para encontrar o que procura.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-8 lg:gap-8">
            {currentItems.map((r) => (
              <a
                key={r.id}
                href={r.previewUrl}
                target="_blank"
                rel="noreferrer"
                className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1.5 overflow-hidden flex flex-col h-full"
              >
                {/* NOVA CAPA (aspect 4/5 → 5/6 no md, com padding e sombra) */}
                
                <div className="bg-gradient-to-br rounded-lg mb-4 overflow-hidden">
                  <div className="relative w-full h-[200px] sm:h-[240px] md:h-[300px] lg:h-[340px] xl:h-[480px]">
                    {r.image ? (
                      <img
                        src={r.image}
                        alt={r.title}
                        className="absolute inset-0 w-full h-full object-contain p-3 sm:p-4 md:p-5"
                        loading="lazy"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center text-6xl text-white">📚</div>
                    )}
                  </div>
                </div>

                {/* Corpo do card */}
                <div className="p-4 md:p-5 flex-1 min-h-0 flex flex-col">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] md:text-xs font-semibold text-green-700 bg-green-100 px-2 py-1 rounded-full">
                      {typeLabel(r.category)}
                    </span>
                    <BookOpen size={16} className="text-gray-400" />
                  </div>

                  <h3 className="mt-2 md:mt-3 text-[15px] md:text-lg font-semibold text-gray-900 leading-snug line-clamp-2">
                    {r.title}
                  </h3>

                  {!!r.author && (
                    <p className="text-xs md:text-sm text-gray-600 font-medium line-clamp-1">
                      {r.author}
                    </p>
                  )}

                  {!!r.description && (
                    <p className="mt-2 text-xs md:text-sm text-gray-500 leading-relaxed line-clamp-3">
                      {r.description}
                    </p>
                  )}

                  <div className="flex-1" />

                  {/* Botão verde padronizado */}
                  <Button
                    size="sm"
                    className="mt-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-full py-3"
                    onClick={(e) => {
                      e.preventDefault()
                      window.open(r.previewUrl, '_blank', 'noopener,noreferrer')
                    }}
                  >
                    Acessar
                    <ExternalLink size={14} className="ml-2" />
                  </Button>
                </div>
              </a>
            ))}
          </div>
        )}

        {/* Paginação */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-10">
            <Button
              variant="outline"
              className="rounded-full"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            >
              Anterior
            </Button>
            <span className="text-sm text-gray-700 px-2">
              Página {currentPage} de {totalPages}
            </span>
            <Button
              variant="outline"
              className="rounded-full"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            >
              Próxima
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

export default LibraryPage
