/**
 * Script de migração de lowDB (JSON) para SQLite
 * 
 * Uso: node server/migrate.js
 */

import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'
import { db, initDB, setPostTags, setWorkTags } from './database.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const dataDir = path.resolve(__dirname, '..', 'data')
const dbFile = path.resolve(dataDir, 'db.json')

async function migrate() {
  console.log('='.repeat(60))
  console.log('MIGRAÇÃO DE LOWDB PARA SQLITE')
  console.log('='.repeat(60))
  
  // Verifica se o arquivo JSON existe
  if (!fs.existsSync(dbFile)) {
    console.error('❌ Arquivo db.json não encontrado em:', dbFile)
    process.exit(1)
  }
  
  // Lê dados do lowDB
  console.log('\n📖 Lendo dados do lowDB...')
  const adapter = new JSONFile(dbFile)
  const lowdb = new Low(adapter, { posts: [], works: [], tags: [], users: [] })
  await lowdb.read()
  
  if (!lowdb.data) {
    console.error('❌ Dados do lowDB não encontrados')
    process.exit(1)
  }
  
  const { users, tags, posts, works } = lowdb.data
  
  console.log(`   - ${users.length} usuários`)
  console.log(`   - ${tags.length} tags`)
  console.log(`   - ${posts.length} posts`)
  console.log(`   - ${works.length} works`)
  
  // Inicializa SQLite
  console.log('\n🔧 Inicializando banco SQLite...')
  initDB()
  
  // Limpa tabelas existentes (para re-migração)
  console.log('\n🗑️  Limpando tabelas existentes...')
  db.exec('DELETE FROM post_tags')
  db.exec('DELETE FROM work_tags')
  db.exec('DELETE FROM posts')
  db.exec('DELETE FROM works')
  db.exec('DELETE FROM tags')
  db.exec('DELETE FROM users')
  
  // Migra usuários
  console.log('\n👤 Migrando usuários...')
  const userStmt = db.prepare(`
    INSERT INTO users (id, username, password_hash, role, created_at)
    VALUES (?, ?, ?, ?, ?)
  `)
  
  for (const user of users) {
    userStmt.run(
      user.id,
      user.username,
      user.passwordHash,
      user.role || 'admin',
      user.createdAt || new Date().toISOString()
    )
  }
  console.log(`   ✅ ${users.length} usuários migrados`)
  
  // Migra tags
  console.log('\n🏷️  Migrando tags...')
  const tagStmt = db.prepare(`
    INSERT INTO tags (id, name, slug)
    VALUES (?, ?, ?)
  `)
  
  for (const tag of tags) {
    tagStmt.run(tag.id, tag.name, tag.slug)
  }
  console.log(`   ✅ ${tags.length} tags migradas`)
  
  // Migra posts
  console.log('\n📰 Migrando posts...')
  const postStmt = db.prepare(`
    INSERT INTO posts (
      id, titulo, resumo, conteudo, categoria, status, autor, imagem, data, visualizacoes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `)
  
  for (const post of posts) {
    const now = new Date().toISOString()
    postStmt.run(
      post.id,
      post.titulo,
      post.resumo,
      post.conteudo,
      post.categoria,
      post.status,
      post.autor || 'Equipe COOP-Recicla',
      post.imagem || null,
      post.data || now,
      post.visualizacoes || 0,
      post.createdAt || now,
      post.updatedAt || now
    )
    
    // Migra relacionamentos post-tags
    if (post.tagIds && post.tagIds.length > 0) {
      setPostTags(post.id, post.tagIds)
    }
  }
  console.log(`   ✅ ${posts.length} posts migrados`)
  
  // Migra works
  console.log('\n📚 Migrando works...')
  const workStmt = db.prepare(`
    INSERT INTO works (
      id, title, author, category, year, pages, description, preview_url, download_url, image, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `)
  
  for (const work of works) {
    const now = new Date().toISOString()
    workStmt.run(
      work.id,
      work.title,
      work.author || null,
      work.category || 'academic',
      work.year || null,
      work.pages || null,
      work.description,
      work.previewUrl || null,
      work.downloadUrl || null,
      work.image || null,
      work.createdAt || now,
      work.updatedAt || now
    )
    
    // Migra relacionamentos work-tags
    if (work.tagIds && work.tagIds.length > 0) {
      setWorkTags(work.id, work.tagIds)
    }
  }
  console.log(`   ✅ ${works.length} works migrados`)
  
  // Verifica integridade
  console.log('\n🔍 Verificando integridade dos dados...')
  const counts = {
    users: db.prepare('SELECT COUNT(*) as count FROM users').get().count,
    tags: db.prepare('SELECT COUNT(*) as count FROM tags').get().count,
    posts: db.prepare('SELECT COUNT(*) as count FROM posts').get().count,
    works: db.prepare('SELECT COUNT(*) as count FROM works').get().count,
    postTags: db.prepare('SELECT COUNT(*) as count FROM post_tags').get().count,
    workTags: db.prepare('SELECT COUNT(*) as count FROM work_tags').get().count
  }
  
  console.log(`   - Usuários: ${counts.users}`)
  console.log(`   - Tags: ${counts.tags}`)
  console.log(`   - Posts: ${counts.posts}`)
  console.log(`   - Works: ${counts.works}`)
  console.log(`   - Relacionamentos post-tags: ${counts.postTags}`)
  console.log(`   - Relacionamentos work-tags: ${counts.workTags}`)
  
  // Cria backup do arquivo JSON
  const backupFile = path.resolve(dataDir, `db.json.backup.${Date.now()}`)
  console.log('\n💾 Criando backup do arquivo JSON...')
  fs.copyFileSync(dbFile, backupFile)
  console.log(`   ✅ Backup salvo em: ${backupFile}`)
  
  console.log('\n' + '='.repeat(60))
  console.log('✅ MIGRAÇÃO CONCLUÍDA COM SUCESSO!')
  console.log('='.repeat(60))
  console.log('\n📝 Próximos passos:')
  console.log('   1. Teste o sistema com SQLite')
  console.log('   2. Se tudo estiver funcionando, você pode remover o db.json')
  console.log('   3. Atualize o server/index.js para usar database.js')
  console.log('')
}

// Executa migração
migrate()
  .then(() => {
    db.close()
    process.exit(0)
  })
  .catch((error) => {
    console.error('\n❌ Erro na migração:', error)
    db.close()
    process.exit(1)
  })
