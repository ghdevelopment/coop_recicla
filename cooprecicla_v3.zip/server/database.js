import Database from 'better-sqlite3'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'
import { nanoid } from 'nanoid'
import bcrypt from 'bcryptjs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const dataDir = path.resolve(__dirname, '..', 'data')
const dbFile = path.resolve(dataDir, 'database.sqlite')

// Garante que o diretório existe
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true })
}

// Cria conexão com SQLite
// Modo verbose removido para logs mais limpos
export const db = new Database(dbFile)

// Habilita foreign keys
db.pragma('foreign_keys = ON')

/**
 * Inicializa o banco de dados criando as tabelas
 */
export function initDB() {
  console.log('[database] Inicializando banco de dados SQLite...')
  
  // Tabela de usuários
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin',
      created_at TEXT NOT NULL
    )
  `)
  
  // Tabela de tags
  db.exec(`
    CREATE TABLE IF NOT EXISTS tags (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL
    )
  `)
  
  // Tabela de posts
  db.exec(`
    CREATE TABLE IF NOT EXISTS posts (
      id TEXT PRIMARY KEY,
      titulo TEXT NOT NULL,
      resumo TEXT NOT NULL,
      conteudo TEXT NOT NULL,
      categoria TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('Rascunho', 'Publicado', 'Arquivado')),
      autor TEXT NOT NULL DEFAULT 'Equipe COOP-Recicla',
      imagem TEXT,
      data TEXT NOT NULL,
      visualizacoes INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `)
  
  // Tabela de works
  db.exec(`
    CREATE TABLE IF NOT EXISTS works (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      author TEXT,
      category TEXT CHECK(category IN ('academic', 'books', 'articles', 'manuals', 'children', 'law')),
      year INTEGER,
      pages INTEGER,
      description TEXT NOT NULL,
      preview_url TEXT,
      download_url TEXT,
      image TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `)
  
  // Tabela de relacionamento posts-tags (many-to-many)
  db.exec(`
    CREATE TABLE IF NOT EXISTS post_tags (
      post_id TEXT NOT NULL,
      tag_id TEXT NOT NULL,
      PRIMARY KEY (post_id, tag_id),
      FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
      FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
    )
  `)
  
  // Tabela de relacionamento works-tags (many-to-many)
  db.exec(`
    CREATE TABLE IF NOT EXISTS work_tags (
      work_id TEXT NOT NULL,
      tag_id TEXT NOT NULL,
      PRIMARY KEY (work_id, tag_id),
      FOREIGN KEY (work_id) REFERENCES works(id) ON DELETE CASCADE,
      FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
    )
  `)
  
  // Índices para otimização
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status);
    CREATE INDEX IF NOT EXISTS idx_posts_categoria ON posts(categoria);
    CREATE INDEX IF NOT EXISTS idx_posts_data ON posts(data DESC);
    CREATE INDEX IF NOT EXISTS idx_works_category ON works(category);
    CREATE INDEX IF NOT EXISTS idx_works_created_at ON works(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_tags_slug ON tags(slug);
  `)
  
  // Seed admin user se não existir
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count
  if (userCount === 0) {
    const passwordHash = bcrypt.hashSync('admin123', 10)
    db.prepare(`
      INSERT INTO users (id, username, password_hash, role, created_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(nanoid(), 'admin', passwordHash, 'admin', new Date().toISOString())
    console.log('[database] Usuário admin criado')
  }
  
  console.log('[database] Banco de dados inicializado com sucesso')
}

/**
 * Encontra ou cria tags por nomes
 * @param {string[]} names - Array de nomes de tags
 * @returns {string[]} - Array de IDs de tags
 */
export function findOrCreateTagsByNames(names = []) {
  const sluggify = (s) => s.toString().trim().toLowerCase().replace(/\s+/g, '-')
  const ids = []
  
  const findStmt = db.prepare('SELECT id FROM tags WHERE slug = ?')
  const insertStmt = db.prepare('INSERT INTO tags (id, name, slug) VALUES (?, ?, ?)')
  
  for (const name of names) {
    const slug = sluggify(name)
    let tag = findStmt.get(slug)
    
    if (!tag) {
      const id = nanoid()
      insertStmt.run(id, name.trim(), slug)
      tag = { id }
    }
    
    ids.push(tag.id)
  }
  
  return ids
}

/**
 * Expande IDs de tags para objetos completos
 * @param {string[]} ids - Array de IDs de tags
 * @returns {object[]} - Array de objetos de tags
 */
export function expandTags(ids = []) {
  if (ids.length === 0) return []
  
  const placeholders = ids.map(() => '?').join(',')
  const stmt = db.prepare(`SELECT id, name, slug FROM tags WHERE id IN (${placeholders})`)
  return stmt.all(...ids)
}

/**
 * Obtém tags de um post
 * @param {string} postId - ID do post
 * @returns {object[]} - Array de objetos de tags
 */
export function getPostTags(postId) {
  const stmt = db.prepare(`
    SELECT t.id, t.name, t.slug
    FROM tags t
    INNER JOIN post_tags pt ON t.id = pt.tag_id
    WHERE pt.post_id = ?
  `)
  return stmt.all(postId)
}

/**
 * Obtém tags de um work
 * @param {string} workId - ID do work
 * @returns {object[]} - Array de objetos de tags
 */
export function getWorkTags(workId) {
  const stmt = db.prepare(`
    SELECT t.id, t.name, t.slug
    FROM tags t
    INNER JOIN work_tags wt ON t.id = wt.tag_id
    WHERE wt.work_id = ?
  `)
  return stmt.all(workId)
}

/**
 * Define tags de um post (substitui as existentes)
 * @param {string} postId - ID do post
 * @param {string[]} tagIds - Array de IDs de tags
 */
export function setPostTags(postId, tagIds) {
  const deleteStmt = db.prepare('DELETE FROM post_tags WHERE post_id = ?')
  const insertStmt = db.prepare('INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)')
  
  deleteStmt.run(postId)
  for (const tagId of tagIds) {
    insertStmt.run(postId, tagId)
  }
}

/**
 * Define tags de um work (substitui as existentes)
 * @param {string} workId - ID do work
 * @param {string[]} tagIds - Array de IDs de tags
 */
export function setWorkTags(workId, tagIds) {
  const deleteStmt = db.prepare('DELETE FROM work_tags WHERE work_id = ?')
  const insertStmt = db.prepare('INSERT INTO work_tags (work_id, tag_id) VALUES (?, ?)')
  
  deleteStmt.run(workId)
  for (const tagId of tagIds) {
    insertStmt.run(workId, tagId)
  }
}

/**
 * Fecha a conexão com o banco de dados
 */
export function closeDB() {
  db.close()
  console.log('[database] Conexão com banco de dados fechada')
}
