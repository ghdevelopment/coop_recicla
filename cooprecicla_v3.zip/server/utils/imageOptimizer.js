import sharp from 'sharp'
import path from 'path'
import fs from 'fs'

/**
 * Configurações padrão de otimização
 */
const DEFAULT_OPTIONS = {
  maxWidth: 2560,           // Largura máxima em pixels (aumentado para melhor qualidade)
  maxHeight: 2560,          // Altura máxima em pixels (quadrado para não forçar proporção)
  quality: 85,              // Qualidade WEBP (0-100)
  fit: 'inside',            // Reduz apenas se necessário, mantendo proporção EXATA
  withoutEnlargement: true, // Não aumenta imagens pequenas
  position: 'centre'        // Centraliza se houver crop (mas 'inside' evita crop)
}

/**
 * Otimiza uma imagem convertendo para WEBP e redimensionando
 * @param {Buffer} inputBuffer - Buffer da imagem original
 * @param {object} options - Opções de otimização (opcional)
 * @returns {Promise<Buffer>} - Buffer da imagem otimizada
 */
export async function optimizeImage(inputBuffer, options = {}) {
  const opts = { ...DEFAULT_OPTIONS, ...options }
  
  try {
    const optimized = await sharp(inputBuffer)
      .rotate() // Aplica rotação EXIF se existir, depois remove metadados
      .resize({
        width: opts.maxWidth,
        height: opts.maxHeight,
        fit: opts.fit,
        withoutEnlargement: opts.withoutEnlargement
      })
      .webp({ quality: opts.quality })
      .toBuffer()
    
    return optimized
  } catch (error) {
    console.error('[imageOptimizer] Erro ao otimizar imagem:', error)
    throw new Error('Falha ao otimizar imagem')
  }
}

/**
 * Otimiza uma imagem de arquivo e salva o resultado
 * @param {string} inputPath - Caminho do arquivo de entrada
 * @param {string} outputPath - Caminho do arquivo de saída
 * @param {object} options - Opções de otimização (opcional)
 * @returns {Promise<object>} - Informações da imagem otimizada
 */
export async function optimizeImageFile(inputPath, outputPath, options = {}) {
  try {
    if (!fs.existsSync(inputPath)) {
      throw new Error('Arquivo de entrada não encontrado')
    }
    
    const inputBuffer = fs.readFileSync(inputPath)
    const optimizedBuffer = await optimizeImage(inputBuffer, options)
    
    // Garante que o diretório de saída existe
    const outputDir = path.dirname(outputPath)
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true })
    }
    
    fs.writeFileSync(outputPath, optimizedBuffer)
    
    const inputStats = fs.statSync(inputPath)
    const outputStats = fs.statSync(outputPath)
    const reduction = ((1 - outputStats.size / inputStats.size) * 100).toFixed(2)
    
    return {
      originalSize: inputStats.size,
      optimizedSize: outputStats.size,
      reduction: `${reduction}%`,
      outputPath
    }
  } catch (error) {
    console.error('[imageOptimizer] Erro ao otimizar arquivo:', error)
    throw error
  }
}

/**
 * Obtém metadados de uma imagem
 * @param {Buffer} buffer - Buffer da imagem
 * @returns {Promise<object>} - Metadados da imagem
 */
export async function getImageMetadata(buffer) {
  try {
    const metadata = await sharp(buffer).metadata()
    return {
      format: metadata.format,
      width: metadata.width,
      height: metadata.height,
      space: metadata.space,
      channels: metadata.channels,
      hasAlpha: metadata.hasAlpha,
      size: buffer.length
    }
  } catch (error) {
    console.error('[imageOptimizer] Erro ao obter metadados:', error)
    throw new Error('Falha ao obter metadados da imagem')
  }
}

/**
 * Valida se um buffer é uma imagem válida
 * @param {Buffer} buffer - Buffer a ser validado
 * @returns {Promise<boolean>} - true se válido, false caso contrário
 */
export async function isValidImage(buffer) {
  try {
    await sharp(buffer).metadata()
    return true
  } catch {
    return false
  }
}

/**
 * Gera nome de arquivo com extensão .webp
 * @param {string} originalFilename - Nome do arquivo original
 * @returns {string} - Nome do arquivo com extensão .webp
 */
export function generateWebpFilename(originalFilename) {
  const ext = path.extname(originalFilename)
  const base = path.basename(originalFilename, ext)
  return `${base}.webp`
}

/**
 * Cria múltiplas versões de uma imagem (thumbnail, medium, large)
 * @param {Buffer} inputBuffer - Buffer da imagem original
 * @returns {Promise<object>} - Objeto com buffers de diferentes tamanhos
 */
export async function createImageVariants(inputBuffer) {
  try {
    const [thumbnail, medium, large] = await Promise.all([
      sharp(inputBuffer)
        .resize({ width: 300, height: 300, fit: 'cover' })
        .webp({ quality: 80 })
        .toBuffer(),
      sharp(inputBuffer)
        .resize({ width: 800, height: 600, fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 85 })
        .toBuffer(),
      sharp(inputBuffer)
        .resize({ width: 1920, height: 1080, fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 85 })
        .toBuffer()
    ])
    
    return { thumbnail, medium, large }
  } catch (error) {
    console.error('[imageOptimizer] Erro ao criar variantes:', error)
    throw new Error('Falha ao criar variantes da imagem')
  }
}
