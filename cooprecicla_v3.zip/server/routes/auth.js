import express from 'express'
import jwt from 'jsonwebtoken'
import { z } from 'zod'
import { db } from '../database.js'
import { requireAuth } from '../middleware/auth.js'
import { addToBlacklist, getBlacklistStats } from '../utils/tokenBlacklist.js'
import bcrypt from 'bcryptjs'

const router = express.Router()

const LoginSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(3)
})

router.post('/login', async (req, res) => {
  const parse = LoginSchema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  
  const { username, password } = parse.data
  
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username)
  if (!user) return res.status(401).json({ error: 'Usuário ou senha incorretos.' })

  const ok = bcrypt.compareSync(password, user.password_hash)
  if (!ok) return res.status(401).json({ error: 'Usuário ou senha incorretos.' })

  const secret = process.env.JWT_SECRET || 'dev-secret-change-me'
  const token = jwt.sign({ sub: user.id, username: user.username, role: user.role }, secret, { expiresIn: '8h' })
  res.json({ token, user: { id: user.id, username: user.username, role: user.role } })
})

// ⚡ NOVO ENDPOINT: Logout (revoga o token)
router.post('/logout', requireAuth, async (req, res) => {
  try {
    const token = req.token
    const payload = req.user
    
    // Adiciona o token à blacklist até sua expiração natural
    const expiresAt = payload.exp * 1000 // Converte de segundos para milissegundos
    addToBlacklist(token, expiresAt)
    
    res.json({ message: 'Logout realizado com sucesso' })
  } catch (error) {
    console.error('Erro no logout:', error)
    res.status(500).json({ error: 'Erro ao realizar logout' })
  }
})

// ⚡ NOVO ENDPOINT: Verifica se o token ainda é válido
router.get('/verify', requireAuth, async (req, res) => {
  res.json({ 
    valid: true, 
    user: { 
      id: req.user.sub, 
      username: req.user.username, 
      role: req.user.role 
    } 
  })
})

// ⚡ NOVO ENDPOINT: Estatísticas da blacklist (apenas para debug/admin)
router.get('/blacklist-stats', requireAuth, async (req, res) => {
  const stats = getBlacklistStats()
  res.json(stats)
})

export default router
