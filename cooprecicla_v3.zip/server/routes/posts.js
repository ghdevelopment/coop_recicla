import express from 'express'
import { z } from 'zod'
import { db, findOrCreateTagsByNames, getPostTags, setPostTags } from '../database.js'
import { requireAuth } from '../middleware/auth.js'
import rateLimit from 'express-rate-limit'
import { nanoid } from 'nanoid'
import jwt from 'jsonwebtoken'
import sanitizeHtml from 'sanitize-html'
import { deleteImageFile } from '../utils/fileManager.js'

const router = express.Router()

// Accept image as full URL or backend-served relative path (/api/uploads/..), or empty
const ImageField = z.union([z.literal(''), z.string()])
  .optional()
  .refine(
    (v) =>
      v === undefined ||
      v === '' ||
      /^https?:\/\//.test(v) ||
      (typeof v === 'string' && v.startsWith('/api/uploads/')),
    { message: 'Imagem inválida' }
  )

const PostSchema = z.object({
  titulo: z.string().min(3),
  resumo: z.string().min(10).max(500),
  conteudo: z.string().min(10),
  categoria: z.string().min(2),
  status: z.enum(['Rascunho', 'Publicado', 'Arquivado']),
  autor: z.string().min(2).optional(),
  imagem: ImageField,
  tags: z.array(z.string()).optional()
})

// HTML sanitization options for rich content with images
const sanitizeOptions = {
  allowedTags: sanitizeHtml.defaults.allowedTags.concat(['img', 'figure', 'figcaption']),
  allowedAttributes: {
    ...sanitizeHtml.defaults.allowedAttributes,
    img: ['src', 'alt', 'title', 'width', 'height', 'style'],
    a: ['href', 'name', 'target', 'rel'],
    div: ['style'],
    span: ['style'],
    p: ['style'],
    figure: ['style']
  },
  allowedStyles: {
    '*': {
      'text-align': [/^left$|^right$|^center$/],
      'float': [/^left$|^right$|^none$/],
      'margin': [/^[0-9.]+(px|rem|em|%)?(\s[0-9.]+(px|rem|em|%)?){0,3}$|^0$/],
      'width': [/^[0-9.]+(px|%|rem|em)$/],
      'height': [/^[0-9.]+(px|%|rem|em)$/],
      'display': [/^block$|^inline$|^inline-block$|^flex$/],
      'max-width': [/^[0-9.]+(px|%|rem|em)$/]
    }
  },
  transformTags: {
    'a': sanitizeHtml.simpleTransform('a', { rel: 'noopener noreferrer' })
  }
}

// List with simple filters
router.get('/', async (req, res) => {
  const { status, categoria, tag, search, limit, sort } = req.query
  
  let query = 'SELECT * FROM posts WHERE 1=1'
  const params = []
  
  if (status) {
    query += ' AND status = ?'
    params.push(status)
  }
  
  if (categoria) {
    query += ' AND categoria = ?'
    params.push(categoria)
  }
  
  if (tag) {
    // Busca por slug ou nome da tag
    const tagRecord = db.prepare('SELECT id FROM tags WHERE slug = ? OR name = ?').get(tag, tag)
    if (tagRecord) {
      query += ' AND id IN (SELECT post_id FROM post_tags WHERE tag_id = ?)'
      params.push(tagRecord.id)
    } else {
      // Tag não encontrada, retorna vazio
      return res.json([])
    }
  }
  
  if (search) {
    const s = `%${search.toLowerCase()}%`
    query += ' AND (LOWER(titulo) LIKE ? OR LOWER(resumo) LIKE ? OR LOWER(conteudo) LIKE ?)'
    params.push(s, s, s)
  }
  
  // Ordenação
  if (sort === '-data') {
    query += ' ORDER BY data DESC'
  } else if (sort === 'data') {
    query += ' ORDER BY data ASC'
  } else {
    query += ' ORDER BY data DESC' // Padrão
  }
  
  // Limite
  const lim = Math.min(Number(limit) || 100, 100)
  query += ' LIMIT ?'
  params.push(lim)
  
  const posts = db.prepare(query).all(...params)
  
  // Adiciona tags a cada post
  const mapped = posts.map((p) => ({ ...p, tags: getPostTags(p.id) }))
  
  res.json(mapped)
})

router.get('/:id', async (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id)
  
  if (!post) return res.status(404).json({ error: 'Não encontrado' })
  
  // Only published posts are public; drafts/archived require a valid JWT (preview)
  if (post.status !== 'Publicado') {
    const header = req.headers.authorization || ''
    const token = header.startsWith('Bearer ') ? header.slice(7) : null
    if (!token) return res.status(404).json({ error: 'Não encontrado' })
    try {
      const secret = process.env.JWT_SECRET || 'dev-secret-change-me'
      jwt.verify(token, secret)
    } catch {
      return res.status(404).json({ error: 'Não encontrado' })
    }
  }
  
  res.json({ ...post, tags: getPostTags(post.id) })
})

router.post('/', requireAuth, async (req, res) => {
  const parse = PostSchema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })

  const { tags = [], ...data } = parse.data

  const conteudoSanitizado = sanitizeHtml(data.conteudo, sanitizeOptions)
  const tagIds = findOrCreateTagsByNames(tags)

  const now = new Date().toISOString()
  const id = nanoid()

  const stmt = db.prepare(`
    INSERT INTO posts (
      id, titulo, resumo, conteudo, categoria, status, autor, imagem, data, visualizacoes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `)
  
  stmt.run(
    id,
    data.titulo,
    data.resumo,
    conteudoSanitizado,
    data.categoria,
    data.status,
    'Equipe COOP-Recicla',
    data.imagem || null,
    now,
    0,
    now,
    now
  )
  
  // Define tags
  setPostTags(id, tagIds)
  
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(id)
  res.status(201).json({ ...post, tags: getPostTags(id) })
})

router.put('/:id', requireAuth, async (req, res) => {
  const parse = PostSchema.partial().safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })

  const current = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id)
  if (!current) return res.status(404).json({ error: 'Não encontrado' })

  const { tags, ...data } = parse.data
  
  // Atualiza campos fornecidos
  const updates = []
  const params = []
  
  if (data.titulo !== undefined) {
    updates.push('titulo = ?')
    params.push(data.titulo)
  }
  if (data.resumo !== undefined) {
    updates.push('resumo = ?')
    params.push(data.resumo)
  }
  if (data.conteudo !== undefined) {
    updates.push('conteudo = ?')
    params.push(sanitizeHtml(data.conteudo, sanitizeOptions))
  }
  if (data.categoria !== undefined) {
    updates.push('categoria = ?')
    params.push(data.categoria)
  }
  if (data.status !== undefined) {
    updates.push('status = ?')
    params.push(data.status)
  }
  if (data.imagem !== undefined) {
    updates.push('imagem = ?')
    params.push(data.imagem || null)
  }
  
  updates.push('autor = ?')
  params.push('Equipe COOP-Recicla')
  
  updates.push('updated_at = ?')
  params.push(new Date().toISOString())
  
  params.push(req.params.id)
  
  if (updates.length > 0) {
    const query = `UPDATE posts SET ${updates.join(', ')} WHERE id = ?`
    db.prepare(query).run(...params)
  }
  
  // Atualiza tags se fornecidas
  if (tags) {
    const tagIds = findOrCreateTagsByNames(tags)
    setPostTags(req.params.id, tagIds)
  }

  const updated = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id)
  res.json({ ...updated, tags: getPostTags(req.params.id) })
})

router.delete('/:id', requireAuth, async (req, res) => {
  // Encontra o post antes de deletar para pegar a imagem
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id)
  if (!post) return res.status(404).json({ error: 'Não encontrado' })
  
  // Remove o post do banco (CASCADE remove automaticamente as tags)
  db.prepare('DELETE FROM posts WHERE id = ?').run(req.params.id)
  
  // ⚡ REMOÇÃO EM CASCATA: Deleta a imagem associada
  if (post.imagem) {
    deleteImageFile(post.imagem)
  }
  
  res.status(204).end()
})

// Increment views - rate limited per IP
router.post('/:id/view', rateLimit({ windowMs: 60 * 1000, max: 30 }), async (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id)
  if (!post) return res.status(404).json({ error: 'Não encontrado' })
  
  if (post.status !== 'Publicado') {
    return res.json({ visualizacoes: post.visualizacoes || 0 })
  }
  
  db.prepare('UPDATE posts SET visualizacoes = visualizacoes + 1 WHERE id = ?').run(req.params.id)
  
  const updated = db.prepare('SELECT visualizacoes FROM posts WHERE id = ?').get(req.params.id)
  res.json({ visualizacoes: updated.visualizacoes })
})

export default router
