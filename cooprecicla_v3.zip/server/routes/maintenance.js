import express from 'express'
import { requireAuth } from '../middleware/auth.js'
import { db } from '../database.js'
import path from 'path'
import { fileURLToPath } from 'url'
import fs from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const uploadsDir = path.resolve(__dirname, '..', 'uploads')

/**
 * Extrai o nome do arquivo de uma URL ou caminho
 */
function extractFilename(imageUrl) {
  if (!imageUrl || typeof imageUrl !== 'string') return null
  if (imageUrl.startsWith('/api/uploads/')) {
    return imageUrl.replace('/api/uploads/', '')
  }
  return null
}

/**
 * Encontra arquivos órfãos (não referenciados no banco)
 */
function findOrphanFiles() {
  const referencedImages = new Set()
  
  // Posts
  const posts = db.prepare('SELECT imagem FROM posts WHERE imagem IS NOT NULL').all()
  for (const post of posts) {
    const filename = extractFilename(post.imagem)
    if (filename) referencedImages.add(filename)
  }
  
  // Works
  const works = db.prepare('SELECT image FROM works WHERE image IS NOT NULL').all()
  for (const work of works) {
    const filename = extractFilename(work.image)
    if (filename) referencedImages.add(filename)
  }
  
  // Lista todos os arquivos no diretório uploads
  if (!fs.existsSync(uploadsDir)) return []
  const allFiles = fs.readdirSync(uploadsDir)
  
  // Identifica órfãos
  const orphans = allFiles.filter(file => !referencedImages.has(file))
  
  return orphans
}

/**
 * Limpa arquivos órfãos do diretório de uploads
 */
function cleanOrphanFiles() {
  const orphans = findOrphanFiles()
  
  let deletedCount = 0
  for (const filename of orphans) {
    const filepath = path.join(uploadsDir, filename)
    try {
      fs.unlinkSync(filepath)
      console.log(`[maintenance] Órfão deletado: ${filename}`)
      deletedCount++
    } catch (error) {
      console.error(`[maintenance] Erro ao deletar órfão ${filename}:`, error)
    }
  }
  
  return deletedCount
}

const router = express.Router()

/**
 * Lista arquivos órfãos (não referenciados no banco)
 * GET /api/maintenance/orphans
 */
router.get('/orphans', requireAuth, async (req, res) => {
  try {
    const orphans = findOrphanFiles()
    res.json({
      count: orphans.length,
      files: orphans,
      message: orphans.length === 0 
        ? 'Nenhum arquivo órfão encontrado' 
        : `${orphans.length} arquivo(s) órfão(s) encontrado(s)`
    })
  } catch (error) {
    console.error('Erro ao listar órfãos:', error)
    res.status(500).json({ error: 'Erro ao listar arquivos órfãos' })
  }
})

/**
 * Remove arquivos órfãos do diretório de uploads
 * DELETE /api/maintenance/orphans
 */
router.delete('/orphans', requireAuth, async (req, res) => {
  try {
    const deletedCount = cleanOrphanFiles()
    res.json({
      deletedCount,
      message: deletedCount === 0
        ? 'Nenhum arquivo órfão foi deletado'
        : `${deletedCount} arquivo(s) órfão(s) deletado(s) com sucesso`
    })
  } catch (error) {
    console.error('Erro ao limpar órfãos:', error)
    res.status(500).json({ error: 'Erro ao limpar arquivos órfãos' })
  }
})

/**
 * Estatísticas do sistema de arquivos
 * GET /api/maintenance/stats
 */
router.get('/stats', requireAuth, async (req, res) => {
  try {
    const orphans = findOrphanFiles()
    
    // Conta registros
    const postsCount = db.prepare('SELECT COUNT(*) as count FROM posts').get().count
    const worksCount = db.prepare('SELECT COUNT(*) as count FROM works').get().count
    
    // Conta imagens referenciadas
    const postsWithImages = db.prepare('SELECT COUNT(*) as count FROM posts WHERE imagem IS NOT NULL AND imagem LIKE ?').get('/api/uploads/%').count
    const worksWithImages = db.prepare('SELECT COUNT(*) as count FROM works WHERE image IS NOT NULL AND image LIKE ?').get('/api/uploads/%').count
    const referencedCount = postsWithImages + worksWithImages
    
    res.json({
      posts: postsCount,
      works: worksCount,
      referencedImages: referencedCount,
      orphanFiles: orphans.length,
      totalFiles: referencedCount + orphans.length
    })
  } catch (error) {
    console.error('Erro ao obter estatísticas:', error)
    res.status(500).json({ error: 'Erro ao obter estatísticas' })
  }
})

export default router
