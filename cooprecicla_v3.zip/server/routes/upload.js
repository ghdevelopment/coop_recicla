import express from 'express'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'
import { requireAuth } from '../middleware/auth.js'
import { optimizeImage, getImageMetadata, generateWebpFilename } from '../utils/imageOptimizer.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const uploadsDir = path.resolve(__dirname, '..', 'uploads')

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

const allowedMime = new Set(['image/jpeg', 'image/png', 'image/webp'])

// ⚡ MUDANÇA: Usar memoryStorage em vez de diskStorage
// Imagens ficam em buffer (RAM) até serem confirmadas
const storage = multer.memoryStorage()

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (allowedMime.has(file.mimetype)) return cb(null, true)
    cb(new Error('Tipo de arquivo não suportado. Use JPG, PNG ou WEBP.'))
  },
})

const router = express.Router()

// Armazena buffers temporários em memória (será limpo periodicamente)
const tempBuffers = new Map()

// Limpeza automática de buffers antigos (> 1 hora)
setInterval(() => {
  const oneHourAgo = Date.now() - 60 * 60 * 1000
  for (const [key, data] of tempBuffers.entries()) {
    if (data.timestamp < oneHourAgo) {
      tempBuffers.delete(key)
    }
  }
}, 10 * 60 * 1000) // Executa a cada 10 minutos

// ⚡ NOVO ENDPOINT: Upload temporário (mantém em memória)
router.post('/temp', requireAuth, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Arquivo não enviado' })
  
  try {
    // Obtém metadados da imagem original
    const metadata = await getImageMetadata(req.file.buffer)
    
    const ext = path.extname(req.file.originalname).toLowerCase()
    const base = path.basename(req.file.originalname, ext).replace(/[^a-z0-9-_]/gi, '_')
    const tempId = `${Date.now()}_${Math.random().toString(36).slice(2,8)}_${base}.webp`
    
    // Armazena buffer em memória
    tempBuffers.set(tempId, {
      buffer: req.file.buffer,
      mimetype: req.file.mimetype,
      originalname: req.file.originalname,
      size: req.file.size,
      metadata,
      timestamp: Date.now()
    })
    
    res.status(201).json({
      tempId,
      originalName: req.file.originalname,
      size: req.file.size,
      type: req.file.mimetype,
      metadata: {
        width: metadata.width,
        height: metadata.height,
        format: metadata.format
      },
      message: 'Upload temporário realizado. Confirme para salvar permanentemente.'
    })
  } catch (error) {
    console.error('Erro no upload temporário:', error)
    res.status(500).json({ error: 'Erro ao processar imagem' })
  }
})

// ⚡ NOVO ENDPOINT: Confirmar upload (otimiza e salva em disco)
router.post('/confirm/:tempId', requireAuth, async (req, res) => {
  const { tempId } = req.params
  const data = tempBuffers.get(tempId)
  
  if (!data) {
    return res.status(404).json({ error: 'Upload temporário não encontrado ou expirado' })
  }
  
  try {
    // ⚡ OTIMIZAÇÃO: Converte para WEBP mantendo proporção original
    const optimizedBuffer = await optimizeImage(data.buffer)
    
    const filename = tempId
    const filepath = path.join(uploadsDir, filename)
    
    // Salva buffer otimizado em disco
    fs.writeFileSync(filepath, optimizedBuffer)
    
    // Remove do buffer temporário
    tempBuffers.delete(tempId)
    
    const originalSize = data.size
    const optimizedSize = optimizedBuffer.length
    const reduction = ((1 - optimizedSize / originalSize) * 100).toFixed(2)
    
    const url = `/api/uploads/${filename}`
    res.status(201).json({
      url,
      filename,
      originalName: data.originalname,
      originalSize,
      optimizedSize,
      reduction: `${reduction}%`,
      format: 'webp',
      message: 'Imagem otimizada e salva com sucesso'
    })
  } catch (error) {
    console.error('Erro ao confirmar upload:', error)
    res.status(500).json({ error: 'Erro ao salvar arquivo' })
  }
})

// ⚡ NOVO ENDPOINT: Cancelar upload temporário
router.delete('/temp/:tempId', requireAuth, async (req, res) => {
  const { tempId } = req.params
  const deleted = tempBuffers.delete(tempId)
  
  if (!deleted) {
    return res.status(404).json({ error: 'Upload temporário não encontrado' })
  }
  
  res.status(204).end()
})

// ⚡ ENDPOINT ATUALIZADO: Upload direto com otimização automática
// Usado para uploads que não precisam de confirmação
router.post('/', requireAuth, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Arquivo não enviado' })
  
  try {
    // ⚡ OTIMIZAÇÃO: Converte para WEBP mantendo proporção original
    const optimizedBuffer = await optimizeImage(req.file.buffer)
    
    const ext = path.extname(req.file.originalname).toLowerCase()
    const base = path.basename(req.file.originalname, ext).replace(/[^a-z0-9-_]/gi, '_')
    const filename = `${Date.now()}_${Math.random().toString(36).slice(2,8)}_${base}.webp`
    const filepath = path.join(uploadsDir, filename)
    
    fs.writeFileSync(filepath, optimizedBuffer)
    
    const originalSize = req.file.size
    const optimizedSize = optimizedBuffer.length
    const reduction = ((1 - optimizedSize / originalSize) * 100).toFixed(2)
    
    const url = `/api/uploads/${filename}`
    res.status(201).json({
      url,
      filename,
      originalName: req.file.originalname,
      originalSize,
      optimizedSize,
      reduction: `${reduction}%`,
      format: 'webp',
      message: 'Imagem otimizada e salva com sucesso'
    })
  } catch (error) {
    console.error('Erro ao salvar arquivo:', error)
    res.status(500).json({ error: 'Erro ao salvar arquivo' })
  }
})

/**
 * DELETE /api/upload/:filename
 * Remove um arquivo de upload específico
 */
router.delete('/:filename', requireAuth, async (req, res) => {
  try {
    const filename = req.params.filename
    const filepath = path.join(uploadsDir, filename)
    
    // Verifica se o arquivo existe
    if (!fs.existsSync(filepath)) {
      return res.status(404).json({ error: 'Arquivo não encontrado' })
    }
    
    // Remove o arquivo
    fs.unlinkSync(filepath)
    console.log(`[upload] Arquivo removido: ${filename}`)
    
    res.json({ message: 'Arquivo removido com sucesso' })
  } catch (error) {
    console.error('Erro ao remover arquivo:', error)
    res.status(500).json({ error: 'Erro ao remover arquivo' })
  }
})

export default router
