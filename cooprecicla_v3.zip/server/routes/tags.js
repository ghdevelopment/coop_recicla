import express from 'express'
import { z } from 'zod'
import { db } from '../database.js'
import { requireAuth } from '../middleware/auth.js'
import { nanoid } from 'nanoid'

const router = express.Router()

// List all tags
router.get('/', async (req, res) => {
  const tags = db.prepare('SELECT * FROM tags ORDER BY name ASC').all()
  res.json(tags)
})

// Get a single tag by slug
router.get('/:slug', async (req, res) => {
  const tag = db.prepare('SELECT * FROM tags WHERE slug = ?').get(req.params.slug)
  if (!tag) return res.status(404).json({ error: 'Tag não encontrada' })
  res.json(tag)
})

// Create a new tag
router.post('/', requireAuth, async (req, res) => {
  const schema = z.object({ name: z.string().min(2) })
  const parse = schema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  
  const name = parse.data.name.trim()
  const slug = name.toLowerCase().replace(/\s+/g, '-')
  
  const exists = db.prepare('SELECT * FROM tags WHERE slug = ?').get(slug)
  if (exists) return res.status(409).json({ error: 'Tag já existe' })
  
  const id = nanoid()
  db.prepare('INSERT INTO tags (id, name, slug) VALUES (?, ?, ?)').run(id, name, slug)
  
  const tag = db.prepare('SELECT * FROM tags WHERE id = ?').get(id)
  res.status(201).json(tag)
})

// Delete a tag
router.delete('/:id', requireAuth, async (req, res) => {
  const tag = db.prepare('SELECT * FROM tags WHERE id = ?').get(req.params.id)
  if (!tag) return res.status(404).json({ error: 'Não encontrado' })
  
  db.prepare('DELETE FROM tags WHERE id = ?').run(req.params.id)
  res.status(204).end()
})

export default router
