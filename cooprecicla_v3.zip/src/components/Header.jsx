import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Menu, X, Phone, Mail } from "lucide-react";
import coopLogo from "../assets/coop-recicla-logo.png";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const toggleMenu = () => setIsMenuOpen((v) => !v);

  // todas são rotas limpas
  const menuItems = [
    { name: "Início", href: "/inicio" },
    { name: "Quem Somos", href: "/quem-somos" },
    { name: "Serviços", href: "/servicos" },
    { name: "Sustentabilidade", href: "/sustentabilidade" },
    { name: "Novidades", href: "/novidades" },
    { name: "Biblioteca", href: "/recursos-educacionais" },
    { name: "Contato", href: "/contato" },
  ];

  const WHATSAPP_NUMBER = "5564992603912";
  const WHATSAPP_MESSAGE =
    "Olá, gostaria de mais informações sobre os serviços da Coop-recicla.";
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    WHATSAPP_MESSAGE
  )}`;

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Top bar */}
      <div className="bg-green-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-center sm:justify-end items-center text-sm">
            <span>Rio Verde/GO - Sustentabilidade em Ação</span>
        </div>
      </div>

      {/* Main nav */}
      <nav className="container mx-auto px-4 py-3 md:py-4">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          {/* Logo */}
          <div className="flex items-center gap-3 min-w-0">
            <Link
              to="/inicio"
              className="flex items-center gap-3 min-w-0 group"
            >
              <img
                src={coopLogo}
                alt="COOP RECICLA Logo"
                className="h-25 w-auto md:h-25 xl:h-25 flex-shrink-0 transition-transform duration-200 group-hover:scale-106"
              />
              {/* Texto da logo: visível somente a partir de sm (≥640px) */}
              <div className="hidden sm:block min-w-0">
                <h1 className="text-xl md:text-xl xl:text-xl font-bold text-green-700 leading-tight whitespace-nowrap">
                  COOP-RECICLA
                </h1>
                <p className="text-sm md:text-sm text-gray-600 whitespace-nowrap">
                  Cooperativa de Reciclagem
                </p>
              </div>
            </Link>
          </div>


          {/* Desktop menu (apenas XL+) */}
          <div className="hidden xl:flex items-center gap-6 2xl:gap-8">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200 whitespace-nowrap"
              >
                {item.name}
              </Link>
              
            ))}
          </div>

          {/* CTA + Mobile toggle */}
          <div className="flex items-center gap-3 md:gap-4 shrink-0">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0"
            >
              <Button className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold px-4 md:px-6 py-2 rounded-full text-base md:text-base">
                Fale Conosco
              </Button>
            </a>

            {/* Hambúrguer visível até XL */}
            <button
              onClick={toggleMenu}
              className="xl:hidden p-2 rounded-md text-gray-700 hover:text-green-600"
              aria-label="Abrir menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile/Tablet menu (até XL) */}
        {isMenuOpen && (
          <div className="xl:hidden mt-3 pb-4 border-t border-gray-200">
            <div className="flex flex-col space-y-2 pt-4">
              {menuItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-gray-700 hover:text-green-600 font-medium py-2 transition-colors duration-200"
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
