import { Button } from '@/components/ui/button'
import { Phone, Mail, Clock, ExternalLink } from 'lucide-react'
import facebookLogo from '../assets/facebook.png'
import instagramLogo from '../assets/Instagram.png'
import whatsappLogo from '../assets/whatsapp.png'

const Contact = () => {
  const WHATSAPP_NUMBER = '5564992603912'
  const WHATSAPP_MESSAGE = 'Olá, gostaria de mais informações sobre os serviços da Coop-recicla.'
  const whatsappLink = 'https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}'
  const EMAIL = 'coop-recicla@hotmail.com'

  // Página do Google Maps (link externo) e URL do embed
  const mapsPageUrl =
    'https://www.google.com/maps/place/Cooperativa+de+Trabalho+de+Catadores+de+Material+Recicl%C3%A1vel+em+Geral+do+Sudoeste+-+(COOP-RECICLA)/@-17.7947689,-50.8866425,17z/data=!4m6!3m5!1s0x9361db09d104f4ad:0x60301105170fd791!8m2!3d-17.7947638!4d-50.8840676!16s%2Fg%2F11nh6lnf_t?entry=ttu'
  const mapsEmbedUrl =
    'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3798.934851914023!2d-50.88664252406729!3d-17.794758675386714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9361db09d104f4ad%3A0x60301105170fd791!2sCooperativa%20de%20Trabalho%20de%20Catadores%20de%20Material%20Recicl%C3%A1vel%20em%20Geral%20do%20Sudoeste%20-%20(COOP-RECICLA)!5e0!3m2!1spt-BR!2sbr!4v1761785534509!5m2!1spt-BR!2sbr'

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">Entre em Contato</h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">Vamos Conversar Sobre Sustentabilidade</h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Estamos prontos para atender você ou sua empresa com soluções personalizadas em gestão de resíduos.
            Fale conosco por telefone, e-mail ou WhatsApp.
          </p>
        </div>

        {/* Abaixo de 1280px fica 1 coluna; em ≥1280px vira 2 colunas */}
        <div className="grid gap-8 xl:gap-10 xl:grid-cols-2">
          {/* Bloco: Informações de contato */}
          <div className="bg-gray-50 rounded-2xl p-8">
            <h4 className="text-2xl font-bold text-gray-900 mb-6">Informações de Contato</h4>

            {/* Linha 1: Telefone + Horário */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Telefone */}
              <div className="bg-white p-6 rounded-xl border border-gray-100 hover:shadow-sm transition">
                <div className="flex items-start gap-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Phone className="text-green-600" size={22} />
                  </div>
                  <div className="min-w-0">
                    <h5 className="font-semibold text-gray-900 mb-1">Telefone</h5>
                    <p className="text-gray-900 font-medium">(64) 9 9260-3912</p>
                    <p className="text-gray-600 text-sm">Atendimento de segunda à sexta</p>
                  </div>
                </div>
              </div>

              {/* Horário (subido para a 1ª linha) */}
              <div className="bg-white p-6 rounded-xl border border-gray-100 hover:shadow-sm transition">
                <div className="flex items-start gap-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Clock className="text-green-600" size={22} />
                  </div>
                  <div className="min-w-0">
                    <h5 className="font-semibold text-gray-900 mb-1">Horário</h5>
                    <p className="text-gray-900 font-medium">07:00 às 17:00</p>
                    <p className="text-gray-600 text-sm">Segunda à sexta-feira</p>
                  </div>
                </div>
              </div>

              {/* Linha 2: E-mail ocupando a largura toda */}
              <div className="bg-white p-6 sm:p-7 rounded-xl border border-gray-100 hover:shadow-sm transition sm:col-span-2">
                <div className="flex items-start gap-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Mail className="text-green-600" size={22} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h5 className="font-semibold text-gray-900 mb-1">E-mail</h5>
                    <p className="text-gray-900 font-medium break-all">{EMAIL}</p>
                    <p className="text-gray-600 text-sm mb-4">Resposta em até 24 horas</p>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA WhatsApp */}
            <div className="mt-8 rounded-2xl bg-green-600 text-white p-6 flex flex-col sm:flex-row items-center gap-4 justify-between">
              <div className="text-center sm:text-left">
                <h5 className="text-xl font-bold">Precisa de atendimento imediato?</h5>
                <p className="opacity-90">Chame no WhatsApp e fale com a equipe</p>
              </div>
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button className="bg-white text-green-700 hover:bg-gray-100 px-6 py-6 rounded-full font-semibold">
                  <img className="h-7 w-auto mr-2" src={whatsappLogo} alt="whatsapp logo" />
                  Chamar no WhatsApp
                </Button>
              </a>
            </div>
          </div>

          {/* Bloco: Mapa (vai para baixo quando < 1280px) */}
          <div className="bg-gray-50 rounded-2xl p-8">
            <h4 className="text-2xl font-bold text-gray-900 mb-6">Nossa Localização</h4>
            <a href={mapsPageUrl} target="_blank" rel="noopener noreferrer" className="block group">
              <div className="relative w-full h-[260px] md:h-[300px] lg:h-[320px] rounded-xl overflow-hidden shadow-sm bg-white">
                <iframe
                  src={mapsEmbedUrl}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0 w-full h-full border-0"
                  title="Mapa COOP-RECICLA"
                ></iframe>
                <div className="absolute inset-0 bg-transparent cursor-pointer" />
              </div>

              <div className="pt-5 text-center">
                <p className="text-gray-600">Rua 2, Quadra 3, Lote 1, Setor Industrial</p>
                <p className="text-gray-600 mb-3">Rio Verde - GO, CEP: 75905-020</p>
                <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50 rounded-full">
                  Ver no Google Maps  <ExternalLink size={14} />
                </Button>
              </div>
            </a>
          </div>
        </div>

        {/* Redes sociais */}
        <div className="mt-12">
          <h5 className="text-lg font-semibold text-gray-900 mb-4 text-center">Siga-nos nas Redes Sociais</h5>
          <div className="flex items-center justify-center gap-5">
            <a
              href="https://www.facebook.com/Coopreciclasudoeste"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="relative w-12 h-12 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
            >
              <img src={facebookLogo} alt="facebook logo" className="absolute inset-0 w-full h-full object-cover" draggable="false" />
            </a>
            <a
              href="https://www.instagram.com/coop_recicla"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="relative w-12 h-12 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
            >
              <img src={instagramLogo} alt="instagram logo" className="absolute inset-0 w-full h-full object-cover" draggable="false" />
            </a>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="relative w-14 h-13  overflow-hidden  hover:ring-black/20 transition"
            >
              <img src='https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg' alt="whatsapp logo" className="absolute inset-0 w-full h-full object-cover" draggable="false" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
