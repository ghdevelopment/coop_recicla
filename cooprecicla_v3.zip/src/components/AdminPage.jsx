import { useState, useEffect, useRef } from 'react'
import React from 'react'
import { Plus, Edit, Trash2, Save, Calendar, Eye, Search, MoreVertical, FileText, Image as ImageIcon, LogOut } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { ImageDropzone } from '@/components/ui/image-dropzone'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { api } from '@/lib/api'
import { useNavigate } from 'react-router-dom'

class FormErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }
  componentDidCatch(error, info) {
    // noop: could log to server later
    console.error('Form ErrorBoundary caught:', error, info)
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 text-sm text-red-700 bg-red-50 border border-red-100 rounded">
          Ocorreu um erro ao carregar o formulário. Mensagem: {String(this.state.error?.message || this.state.error || 'desconhecido')}
        </div>
      )
    }
    return this.props.children
  }
}

const AdminPage = ({ onBack }) => {
  const [posts, setPosts] = useState([])
  const [works, setWorks] = useState([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isWorkDialogOpen, setIsWorkDialogOpen] = useState(false)
  const [editingPost, setEditingPost] = useState(null)
  const [editingWork, setEditingWork] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('todos')
  const [filterCategory, setFilterCategory] = useState('todas')
  const [activeTab, setActiveTab] = useState('posts')

  const [formData, setFormData] = useState({
    titulo: '', resumo: '', conteudo: '', categoria: '', status: 'Rascunho', imagem: '', tags: ''
  })
  const [uploadingImage, setUploadingImage] = useState(false)
  const [uploadError, setUploadError] = useState('')
  const fileInputRef = useRef(null)
  const navigate = useNavigate()

  const handleLogout = () => {
    try {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
    } catch {}
    if (onBack) onBack()
    navigate('/admin')
  }
  const [savingPost, setSavingPost] = useState(false)
  const [postError, setPostError] = useState('')

  const handleImageFile = async (file) => {
    setUploadError('')
    setUploadingImage(true)
    
    // Se já tinha uma imagem e não está editando, deleta a antiga antes de fazer upload da nova
    const oldImage = formData.imagem
    if (oldImage && !editingPost) {
      try {
        await api.deleteUpload(oldImage)
        console.log('[admin] Imagem antiga removida ao trocar')
      } catch (err) {
        console.error('[admin] Erro ao remover imagem antiga:', err)
      }
    }
    
    try {
      const res = await api.upload(file)
      setFormData((fd) => ({ ...fd, imagem: res.url }))
    } catch (err) {
      setUploadError(err.message || 'Falha ao enviar imagem')
    } finally {
      setUploadingImage(false)
    }
  }
  const [workForm, setWorkForm] = useState({
    title: '', description: '', previewUrl: '', image: '', tags: '', category: 'academic'
  })

  const categorias = ['Educação', 'Parcerias', 'Eventos', 'Sustentabilidade', 'Tecnologia', 'Comunidade']
  const statusOptions = ['Rascunho', 'Publicado', 'Arquivado']

  useEffect(() => {
    const load = async () => {
      const [p, w] = await Promise.all([api.listPosts(), api.listWorks()])
      setPosts(p.map((post) => ({ ...post, tags: (post.tags || []).map((t) => t.name) })))
      setWorks(w.map((work) => ({ ...work, tags: (work.tags || []).map((t) => t.name) })))
    }
    load()
  }, [])

  const resetForm = async (deleteImage = true) => {
    // Se houver imagem anexada e não estamos editando (novo post), remove do servidor
    // deleteImage=false quando salvamos com sucesso (imagem deve permanecer)
    if (deleteImage && formData.imagem && !editingPost) {
      try {
        await api.deleteUpload(formData.imagem)
        console.log('[admin] Imagem removida ao cancelar')
      } catch (err) {
        console.error('[admin] Erro ao remover imagem:', err)
      }
    }
    setFormData({ titulo: '', resumo: '', conteudo: '', categoria: '', status: 'Rascunho', imagem: '', tags: '' })
    setEditingPost(null)
  }
  const resetWorkForm = async (deleteImage = true) => {
    // Se houver imagem anexada e não estamos editando (novo work), remove do servidor
    // deleteImage=false quando salvamos com sucesso (imagem deve permanecer)
    if (deleteImage && workForm.image && !editingWork) {
      try {
        await api.deleteUpload(workForm.image)
        console.log('[admin] Imagem removida ao cancelar work')
      } catch (err) {
        console.error('[admin] Erro ao remover imagem work:', err)
      }
    }
    setWorkForm({ title: '', description: '', previewUrl: '', image: '', tags: '', category: 'academic' })
    setEditingWork(null)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setPostError('')
    // validações básicas do formulário
    if (!formData.titulo?.trim() || !formData.resumo?.trim() || !formData.conteudo?.trim()) {
      setPostError('Preencha título, resumo e conteúdo.')
      return
    }
    if (!formData.categoria) {
      setPostError('Selecione uma categoria.')
      return
    }
    setSavingPost(true)
    try {
      const payload = { ...formData, tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean) }
      if (editingPost) {
        const updated = await api.updatePost(editingPost.id, payload)
        const normalized = { ...updated, tags: (updated.tags || []).map(t => t.name) }
        setPosts((ps) => ps.map((p) => p.id === editingPost.id ? normalized : p))
      } else {
        const created = await api.createPost(payload)
        const normalized = { ...created, tags: (created.tags || []).map(t => t.name) }
        setPosts((ps) => [normalized, ...ps])
      }
      resetForm(false); setIsDialogOpen(false) // false = não deletar imagem (sucesso)
    } catch (err) {
      const msg = err?.message || 'Falha ao salvar publicação'
      setPostError(msg)
    } finally {
      setSavingPost(false)
    }
  }

  const handlePreview = async () => {
    setPostError('')
    // validações mínimas exigidas pelo backend
    if (!formData.titulo?.trim() || !formData.resumo?.trim() || !formData.conteudo?.trim()) {
      setPostError('Preencha título, resumo e conteúdo para pré-visualizar.')
      return
    }
    if (!formData.categoria) {
      setPostError('Selecione uma categoria para pré-visualizar.')
      return
    }
    setSavingPost(true)
    try {
      const payloadBase = { ...formData, tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean) }
      const payload = { ...payloadBase, status: 'Rascunho' }
      let postId
      if (editingPost) {
        const updated = await api.updatePost(editingPost.id, payload)
        const normalized = { ...updated, tags: (updated.tags || []).map(t => t.name) }
        setPosts((ps) => ps.map((p) => p.id === editingPost.id ? normalized : p))
        setFormData((fd) => ({ ...fd, status: normalized.status }))
        postId = normalized.id
      } else {
        const created = await api.createPost(payload)
        const normalized = { ...created, tags: (created.tags || []).map(t => t.name) }
        setPosts((ps) => [normalized, ...ps])
        // virar "edição" após criar para UX consistente
        postId = normalized.id
      }
      // abrir nova aba em modo preview
      window.open(`/novidades/publicacoes/${postId}?preview=1`, '_blank', 'noopener,noreferrer')
    } catch (err) {
      const msg = err?.message || 'Falha ao salvar rascunho para pré-visualizar'
      setPostError(msg)
    } finally {
      setSavingPost(false)
    }
  }

  const handleEdit = (post) => {
    setEditingPost(post)
  setFormData({ titulo: post.titulo, resumo: post.resumo, conteudo: post.conteudo, categoria: post.categoria, status: post.status, imagem: post.imagem, tags: (post.tags || []).join(', ') })
    setIsDialogOpen(true)
  }
  const handleDelete = async (id) => { await api.deletePost(id); setPosts((ps) => ps.filter((p) => p.id !== id)) }

  const handleWorkSubmit = async (e) => {
    e.preventDefault()
    // validar campos mínimos
    if (!workForm.title?.trim() || !workForm.description?.trim() || !workForm.previewUrl?.trim()) {
      alert('Preencha título, resumo e URL do trabalho.')
      return
    }
  const payload = { title: workForm.title, description: workForm.description, url: workForm.previewUrl, image: workForm.image, category: workForm.category || 'academic', tags: workForm.tags.split(',').map(t => t.trim()).filter(Boolean) }
    if (editingWork) {
      const updated = await api.updateWork(editingWork.id, payload)
      const normalized = { ...updated, tags: (updated.tags || []).map(t => t.name) }
      setWorks((ws) => ws.map((w) => w.id === editingWork.id ? normalized : w))
    } else {
      const created = await api.createWork(payload)
      const normalized = { ...created, tags: (created.tags || []).map(t => t.name) }
      setWorks((ws) => [normalized, ...ws])
    }
    resetWorkForm(false); setIsWorkDialogOpen(false) // false = não deletar imagem (sucesso)
  }
  const handleWorkEdit = (work) => { setEditingWork(work); setWorkForm({ title: work.title || '', description: work.description || '', previewUrl: work.previewUrl || '', image: work.image || '', tags: (work.tags || []).join(', '), category: work.category || 'academic' }); setIsWorkDialogOpen(true) }
  const handleWorkDelete = async (id) => { await api.deleteWork(id); setWorks((ws) => ws.filter((w) => w.id !== id)) }

  const filteredPosts = posts.filter((post) => {
    const s = searchTerm.toLowerCase()
    const matchesSearch = post.titulo.toLowerCase().includes(s) || post.resumo.toLowerCase().includes(s)
    const matchesStatus = filterStatus === 'todos' || post.status === filterStatus
    const matchesCategory = filterCategory === 'todas' || post.categoria === filterCategory
    return matchesSearch && matchesStatus && matchesCategory
  })

  const getStatusColor = (status) => ({ 'Publicado': 'bg-green-100 text-green-700', 'Rascunho': 'bg-yellow-100 text-yellow-700', 'Arquivado': 'bg-gray-100 text-gray-700' }[status] || 'bg-gray-100 text-gray-700')

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Administração</h1>
              <p className="text-gray-600">Gerencie notícias e o catálogo de trabalhos</p>
            </div>
            <div className="flex gap-3">
              <Dialog open={isDialogOpen} onOpenChange={(open) => {
                if (!open) resetForm() // Limpa ao fechar
                setIsDialogOpen(open)
              }}>
                <DialogTrigger asChild>
                  <Button className="bg-green-600 hover:bg-green-700" onClick={() => { setActiveTab('posts'); resetForm() }}>
                    <Plus className="mr-2" size={16} /> Nova Publicação
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-2xl lg:max-w-4xl w-[calc(100%-2rem)] p-0 overflow-hidden">
                  <FormErrorBoundary>
                  <div className="border-b p-6">
                    <DialogHeader>
                      <DialogTitle>{editingPost ? 'Editar Publicação' : 'Nova Publicação'}</DialogTitle>
                      <DialogDescription>{editingPost ? 'Edite as informações da publicação' : 'Crie uma nova publicação para o blog'}</DialogDescription>
                    </DialogHeader>
                  </div>
                  <form id="postForm" onSubmit={handleSubmit} className="max-h-[70vh] overflow-y-auto p-6 space-y-6">
                    {postError && (
                      <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded p-2">
                        {postError}
                      </div>
                    )}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="titulo">Título *</Label>
                        <Input id="titulo" value={formData.titulo} onChange={(e) => setFormData({ ...formData, titulo: e.target.value })} required />
                      </div>
                      <div className="space-y-2">
                        <Label>Autor</Label>
                        <Input value="Equipe COOP Recicla" disabled />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="resumo">Resumo *</Label>
                      <Textarea id="resumo" value={formData.resumo} onChange={(e) => setFormData({ ...formData, resumo: e.target.value })} maxLength={200} rows={3} required />
                      <div className="text-xs text-gray-500 text-right">{formData.resumo.length}/200 caracteres</div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="conteudo">Conteúdo *</Label>
                      <Textarea id="conteudo" value={formData.conteudo} onChange={(e) => setFormData({ ...formData, conteudo: e.target.value })} rows={8} required />
                    </div>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="categoria">Categoria *</Label>
                        <Select value={formData.categoria || undefined} onValueChange={(value) => setFormData({ ...formData, categoria: value })}>
                          <SelectTrigger><SelectValue placeholder="Selecione uma categoria" /></SelectTrigger>
                          <SelectContent>{categorias.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="status">Status *</Label>
                        <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>{statusOptions.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Imagem da Publicação</Label>
                        <ImageDropzone
                          value={formData.imagem}
                          onChange={handleImageFile}
                          onRemove={async () => {
                            // Deleta imagem do servidor (sempre, inclusive em edição)
                            if (formData.imagem) {
                              try {
                                await api.deleteUpload(formData.imagem)
                                console.log('[admin] Imagem removida manualmente')
                              } catch (err) {
                                console.error('[admin] Erro ao remover imagem:', err)
                              }
                            }
                            setFormData({ ...formData, imagem: '' })
                          }}
                          disabled={uploadingImage}
                        />
                        {uploadingImage && <div className="text-xs text-gray-600">Enviando imagem...</div>}
                        {uploadError && <div className="text-xs text-red-600">{uploadError}</div>}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tags">Tags</Label>
                      <Input id="tags" value={formData.tags} onChange={(e) => setFormData({ ...formData, tags: e.target.value })} placeholder="educação, sustentabilidade, reciclagem" />
                      <div className="text-xs text-gray-500">Separe as tags com vírgulas</div>
                    </div>
                  </form>
                  <div className="border-t p-4">
                    <DialogFooter>
                      <DialogClose asChild>
                        <Button type="button" variant="outline">Cancelar</Button>
                      </DialogClose>
                      <Button type="button" variant="outline" onClick={handlePreview} disabled={savingPost} className="border-green-600 text-green-700 hover:bg-green-50 disabled:opacity-60">
                        <Eye className="mr-2" size={16} /> Pré-visualizar
                      </Button>
                      <Button type="submit" form="postForm" disabled={savingPost} className="bg-green-600 hover:bg-green-700 disabled:opacity-60 disabled:cursor-not-allowed">
                        <Save className="mr-2" size={16} />
                        {savingPost ? 'Salvando...' : (editingPost ? 'Salvar Alterações' : 'Criar Publicação')}
                      </Button>
                    </DialogFooter>
                  </div>
                  </FormErrorBoundary>
                </DialogContent>
              </Dialog>

              <Dialog open={isWorkDialogOpen} onOpenChange={(open) => {
                if (!open) resetWorkForm() // Limpa ao fechar
                setIsWorkDialogOpen(open)
              }}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50" onClick={() => { setActiveTab('works'); resetWorkForm() }}>
                    <Plus className="mr-2" size={16} /> Novo Trabalho
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-2xl lg:max-w-4xl w-[calc(100%-2rem)] p-0 overflow-hidden">
                  <div className="border-b p-6">
                    <DialogHeader>
                      <DialogTitle>{editingWork ? 'Editar Trabalho' : 'Novo Trabalho'}</DialogTitle>
                      <DialogDescription>{editingWork ? 'Edite as informações do trabalho acadêmico' : 'Cadastre um novo trabalho acadêmico'}</DialogDescription>
                    </DialogHeader>
                  </div>
                  <form id="workForm" onSubmit={handleWorkSubmit} className="max-h-[70vh] overflow-y-auto p-6 space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="wtitle">Título *</Label>
                        <Input id="wtitle" value={workForm.title} onChange={(e) => setWorkForm({ ...workForm, title: e.target.value })} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="wcategory">Categoria *</Label>
                        <Select value={workForm.category} onValueChange={(v) => setWorkForm({ ...workForm, category: v })}>
                          <SelectTrigger id="wcategory"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="academic">Trabalho Acadêmico</SelectItem>
                            <SelectItem value="children">Infantil</SelectItem>
                            <SelectItem value="law">Leis</SelectItem>
                            <SelectItem value="books">Livros</SelectItem>
                            <SelectItem value="articles">Artigos</SelectItem>
                            <SelectItem value="manuals">Manuais</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="wdesc">Resumo do Trabalho *</Label>
                      <Textarea id="wdesc" rows={4} value={workForm.description} onChange={(e) => setWorkForm({ ...workForm, description: e.target.value })} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="wpreview">URL do Trabalho *</Label>
                      <Input id="wpreview" value={workForm.previewUrl} onChange={(e) => setWorkForm({ ...workForm, previewUrl: e.target.value })} required />
                    </div>
                    <div className="space-y-2">
                      <Label>Imagem de Capa</Label>
                      <ImageDropzone
                        value={workForm.image}
                        onChange={async (file) => {
                          // Se já tinha uma imagem e não está editando, deleta a antiga
                          const oldImage = workForm.image
                          if (oldImage && !editingWork) {
                            try {
                              await api.deleteUpload(oldImage)
                              console.log('[admin] Imagem antiga de work removida ao trocar')
                            } catch (err) {
                              console.error('[admin] Erro ao remover imagem antiga de work:', err)
                            }
                          }
                          
                          try {
                            const res = await api.upload(file)
                            setWorkForm((wf) => ({ ...wf, image: res.url }))
                          } catch (err) {
                            alert(err?.message || 'Falha ao enviar imagem')
                          }
                        }}
                        onRemove={async () => {
                          // Deleta imagem do servidor (sempre, inclusive em edição)
                          if (workForm.image) {
                            try {
                              await api.deleteUpload(workForm.image)
                              console.log('[admin] Imagem de work removida manualmente')
                            } catch (err) {
                              console.error('[admin] Erro ao remover imagem de work:', err)
                            }
                          }
                          setWorkForm({ ...workForm, image: '' })
                        }}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="wtags">Tags</Label>
                      <Input id="wtags" value={workForm.tags} onChange={(e) => setWorkForm({ ...workForm, tags: e.target.value })} placeholder="separe por vírgulas" />
                    </div>
                  </form>
                  <div className="border-t p-4">
                    <DialogFooter>
                      <DialogClose asChild>
                        <Button type="button" variant="outline">Cancelar</Button>
                      </DialogClose>
                      <Button type="submit" form="workForm" className="bg-green-600 hover:bg-green-700">Salvar</Button>
                    </DialogFooter>
                  </div>
                </DialogContent>
              </Dialog>
              <Button variant="outline" className="border-red-600 text-red-600 hover:bg-red-50" onClick={handleLogout}>
                <LogOut className="mr-2" size={16} /> Sair
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="bg-white rounded-lg p-2 mb-6 shadow-sm inline-flex gap-2">
          <Button variant={activeTab === 'posts' ? 'default' : 'outline'} onClick={() => setActiveTab('posts')} className={activeTab === 'posts' ? 'bg-green-600 hover:bg-green-700' : ''}>Publicações</Button>
          <Button variant={activeTab === 'works' ? 'default' : 'outline'} onClick={() => setActiveTab('works')} className={activeTab === 'works' ? 'bg-green-600 hover:bg-green-700' : ''}>Trabalhos</Button>
        </div>

        {activeTab === 'posts' && (
          <>
            <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                    <Input placeholder="Buscar publicações..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
                  </div>
                </div>
                <div className="flex gap-3">
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Status</SelectItem>
                      {statusOptions.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Todas as Categorias</SelectItem>
                      {categorias.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-gray-600">Total de Posts</p><p className="text-2xl font-bold text-gray-900">{posts.length}</p></div><FileText className="text-green-600" size={24} /></div></CardContent></Card>
              <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-gray-600">Publicados</p><p className="text-2xl font-bold text-green-600">{posts.filter(p => p.status === 'Publicado').length}</p></div><Eye className="text-green-600" size={24} /></div></CardContent></Card>
              <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-gray-600">Rascunhos</p><p className="text-2xl font-bold text-yellow-600">{posts.filter(p => p.status === 'Rascunho').length}</p></div><Edit className="text-yellow-600" size={24} /></div></CardContent></Card>
              <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-gray-600">Visualizações</p><p className="text-2xl font-bold text-blue-600">{posts.reduce((t, p) => t + (p.visualizacoes || 0), 0)}</p></div><Eye className="text-blue-600" size={24} /></div></CardContent></Card>
            </div>

            <div className="space-y-4">
              {filteredPosts.length === 0 ? (
                <Card><CardContent className="p-12 text-center"><FileText className="mx-auto mb-4 text-gray-400" size={48} /><h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma publicação encontrada</h3><p className="text-gray-600">{searchTerm || filterStatus !== 'todos' || filterCategory !== 'todas' ? 'Tente ajustar os filtros de busca' : 'Crie sua primeira publicação clicando no botão "Nova Publicação"'}</p></CardContent></Card>
              ) : (
                filteredPosts.map((post) => (
                  <Card key={post.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex gap-6">
                        <div className="flex-shrink-0"><div className="w-24 h-24 bg-gray-200 rounded-lg overflow-hidden">{post.imagem ? (<img src={post.imagem} alt={post.titulo} className="w-full h-full object-cover" />) : (<div className="w-full h-full flex items-center justify-center"><ImageIcon className="text-gray-400" size={24} /></div>)}</div></div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="text-lg font-semibold text-gray-900 truncate pr-4">{post.titulo}</h3>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreVertical size={16} /></Button></DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem asChild>
                                  <a href={`/novidades/publicacoes/${post.id}?preview=1`} target="_blank" rel="noreferrer">
                                    <Eye className="mr-2" size={14} /> Pré-visualizar
                                  </a>
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleEdit(post)}><Edit className="mr-2" size={14} />Editar</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleDelete(post.id)} className="text-red-600"><Trash2 className="mr-2" size={14} />Excluir</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                          <p className="text-gray-600 text-sm mb-3 line-clamp-2">{post.resumo}</p>
                          <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                            <span className="flex items-center"><Calendar className="mr-1" size={12} />{new Date(post.data).toLocaleDateString('pt-BR')}</span>
                            <span>Por {post.autor}</span>
                            <span className="flex items-center"><Eye className="mr-1" size={12} />{post.visualizacoes} visualizações</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2"><Badge className={getStatusColor(post.status)}>{post.status}</Badge><Badge variant="outline">{post.categoria}</Badge></div>
                            <div className="flex gap-2">{post.tags.slice(0,3).map((tag, i) => (<Badge key={i} variant="secondary" className="text-xs">{tag}</Badge>))}{post.tags.length>3 && (<Badge variant="secondary" className="text-xs">+{post.tags.length-3}</Badge>)}</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </>
        )}

        {activeTab === 'works' && (
          <div className="space-y-4">
            {works.length === 0 ? (
              <Card><CardContent className="p-12 text-center"><FileText className="mx-auto mb-4 text-gray-400" size={48} /><h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum trabalho cadastrado</h3><p className="text-gray-600">Cadastre um novo trabalho clicando em "Novo Trabalho"</p></CardContent></Card>
            ) : (
              works.map((w) => (
                <Card key={w.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <div className="w-24 h-24 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                        {w.image ? <img src={w.image} alt={w.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-gray-400">📄</div>}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <h3 className="text-lg font-semibold text-gray-900 truncate pr-4">{w.title}</h3>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" className="border-green-600 text-green-700 hover:bg-green-50" onClick={() => window.open(w.previewUrl || w.url, '_blank')}>Acessar</Button>
                            <Button variant="ghost" size="sm" onClick={() => handleWorkEdit(w)}><Edit size={16} /></Button>
                            <Button variant="ghost" size="sm" className="text-red-600" onClick={() => handleWorkDelete(w.id)}><Trash2 size={16} /></Button>
                          </div>
                        </div>
                        <p className="text-gray-700 mt-2 line-clamp-2">{w.description}</p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {(w.tags || []).slice(0,4).map((t,i)=>(<Badge key={i} variant="secondary" className="text-xs">{t.name ? t.name : t}</Badge>))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default AdminPage
