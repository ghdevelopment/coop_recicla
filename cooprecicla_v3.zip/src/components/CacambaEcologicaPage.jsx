import {
  ArrowLeft, CheckCircle, Truck, Shield, Clock, DollarSign, Phone, MapPin
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Link } from 'react-router-dom'
import cacambaImg from '@/assets/cacamba.png'

const CacambaEcologicaPage = () => {
  const WHATSAPP_NUMBER = '5564993095334'
  const WHATSAPP_MESSAGE = 'Olá, gostaria de mais informações sobre o serviço de Caçamba Ecológica.'
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`

  const benefits = [
    { icon: <Shield className="text-green-600" size={24} />, title: 'Conformidade Legal', description: 'Atendem às normas da Política Nacional de Resíduos Sólidos' },
    { icon: <CheckCircle className="text-green-600" size={24} />, title: 'Preservação Ambiental', description: 'Previnem descartes irregulares e protegem o meio ambiente' },
    { icon: <Truck className="text-green-600" size={24} />, title: 'Eficiência Operacional', description: 'Simplificam o transporte e o descarte de materiais' },
  ]

  const plans = [
    {
      title: 'Plano Semanal',
      price: 'R$ 350,00',
      period: '7 dias',
      collections: '1 Coleta',
      description: 'Ideal para pequenos volumes de resíduos',
      features: ['1 caçamba por 7 dias', '1 coleta incluída', 'Retirada automática após prazo', 'Possibilidade de extensão'],
      bgColor: 'bg-green-600',
    },
    {
      title: 'Plano Quinzenal',
      price: 'R$ 700,00',
      period: '15 dias',
      collections: '2 Coletas',
      description: 'Para empresas com volume médio de resíduos',
      features: ['2 caçambas ou 2 coletas', 'Prazo de 15 dias', 'Flexibilidade de uso', 'Melhor custo-benefício'],
      bgColor: 'bg-yellow-500',
      popular: true,
    },
    {
      title: 'Plano Mensal',
      price: 'R$ 1.400,00',
      period: '30 dias',
      collections: '4 Coletas',
      description: 'Para empresas com alto volume de resíduos',
      features: ['4 caçambas ou 4 coletas', 'Prazo de 30 dias', 'Máxima flexibilidade', 'Economia para grandes volumes'],
      bgColor: 'bg-blue-600',
    },
  ]

  const allowedWaste = ['Plástico', 'Papel', 'Metal', 'Vidro', 'Eletrônicos']

  const rentalAdvantages = [
    { icon: <DollarSign className="text-green-600" size={24} />, title: 'Custo Inicial Baixo', description: 'Indicado para projetos temporários sem grandes investimentos' },
    { icon: <Shield className="text-green-600" size={24} />, title: 'Manutenção Inclusa', description: 'A cooperativa cuida de todos os reparos e manutenções' },
    { icon: <Clock className="text-green-600" size={24} />, title: 'Flexibilidade', description: 'Permite usar diferentes modelos conforme a necessidade' },
  ]

  return (
    <div className="min-h-screen bg-white">

      {/* HERO padronizado (altura fixa + imagem absoluta) */}
      <section className="relative bg-green-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/10" aria-hidden="true" />

        <div className="container mx-auto px-4 relative z-10 py-16 lg:py-20">
          {/* Voltar */}
          <div className="mb-6">
            <Link to="/servicos">
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white rounded-full px-6 py-2 flex items-center gap-2 transition-all"
              >
                <ArrowLeft size={20} />
                Voltar
              </Button>
            </Link>
          </div>

          {/* Grid hero */}
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            {/* Texto à esquerda */}
            <div className="max-w-2xl">
              <div className="flex items-center mb-6">
                <div className="bg-white rounded-full mr-4 shadow-sm w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center flex-shrink-0">
                  <Truck className="w-10 h-10 lg:w-12 lg:h-12 text-green-600" />
                </div>
                <div>
                  <h1 className="text-4xl lg:text-5xl font-bold mb-2">Caçamba Ecológica</h1>
                  <p className="text-lg lg:text-xl text-green-100">
                    Soluções completas em aluguel de caçambas ecológicas com tampa para empresas e propriedades rurais
                  </p>
                </div>
              </div>
            </div>

            {/* Direita: imagem com wrapper de altura fixa (não altera o header) */}
            <div className="relative">
              <div
                className="
                  relative mx-auto w-full max-w-[520px]
                  h-[230px] sm:h-[260px] md:h-[300px] lg:h-[340px] xl:h-[360px]
                "
              >
                {/* halo/chão */}
                <div
                  className="absolute bottom-2 left-1/2 -translate-x-1/2 w-3/4 h-5 rounded-full bg-black/15 blur-lg opacity-50"
                  aria-hidden="true"
                />
                {/* imagem absoluta, escala sem empurrar layout */}
                <img
                  src={cacambaImg}
                  alt="Caçamba Ecológica Coop-Recicla"
                  loading="eager"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-contain drop-shadow-[0_8px_20px_rgba(0,0,0,0.25)] pointer-events-none select-none"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Principal */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Caçamba com Tampa</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-green-600 mb-3">Principais Benefícios</h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    Solução ideal para armazenamento temporário de recicláveis, com proteção contra odores
                    e acesso de animais, mantendo a área organizada e segura.
                  </p>
                </div>

                <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded-r-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Informações Rápidas</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} /><strong>Finalidade:</strong>&nbsp;Armazenar resíduos recicláveis</li>
                    <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} /><strong>Benefícios:</strong>&nbsp;Proteção contra odores e animais</li>
                    <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} /><strong>Agendamento:</strong>&nbsp;Solicitar com antecedência</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Nossos Benefícios</h3>
              <div className="space-y-6">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="bg-green-100 p-3 rounded-full flex-shrink-0">{benefit.icon}</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{benefit.title}</h4>
                      <p className="text-gray-600 text-sm">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Resíduos Permitidos */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Resíduos Permitidos</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Aceitamos todos os tipos de resíduos recicláveis para destinação ambientalmente correta.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {allowedWaste.map((waste, index) => (
              <div key={index} className="bg-white px-6 py-3 rounded-full shadow-md border-2 border-green-200">
                <span className="text-green-700 font-semibold">{waste}</span>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Vantagens do Aluguel</h3>
            <div className="grid md:grid-cols-3 gap-8">
              {rentalAdvantages.map((advantage, index) => (
                <div key={index} className="text-center">
                  <div className="bg-green-100 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                    {advantage.icon}
                  </div>
                  <h4 className="text-xl font-semibold text-gray-900 mb-2">{advantage.title}</h4>
                  <p className="text-gray-600">{advantage.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Planos */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Planos de Aluguel</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Escolha o plano que melhor se adequa às necessidades da sua empresa.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <Card
                key={index}
                className={`relative overflow-hidden hover:shadow-xl transition-all duration-300 ${plan.popular ? 'ring-2 ring-yellow-500 scale-[1.02]' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute top-0 right-0 bg-yellow-500 text-white px-4 py-1 text-sm font-semibold">
                    Mais Popular
                  </div>
                )}
                <CardContent className="p-8">
                  <div className={`w-16 h-16 ${plan.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <Truck className="text-white" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 text-center mb-2">{plan.title}</h3>
                  <div className="text-center mb-4">
                    <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                    <p className="text-gray-600">{plan.collections} • {plan.period}</p>
                  </div>
                  <p className="text-gray-600 text-center mb-6">{plan.description}</p>

                  <div className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <CheckCircle className="text-green-600 flex-shrink-0" size={16} />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                    <Button className={`w-full ${plan.bgColor} hover:opacity-90 text-white font-semibold py-3 rounded-full`}>
                      Escolher Plano
                    </Button>
                  </a>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Coleta Rural */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-green-100 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
              <MapPin className="text-green-600" size={32} />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Coleta Rural</h2>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Atendemos propriedades e empresas fora da área urbana, garantindo destinação correta dos recicláveis.
            </p>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Valor da Coleta Rural</h3>
                  <div className="text-4xl font-bold text-green-600 mb-2">R$ 6,00</div>
                  <p className="text-gray-600 mb-4">por quilômetro rodado</p>
                  <p className="text-gray-700">
                    Cobrança justa e transparente baseada na distância percorrida.
                  </p>
                </div>
                <div className="bg-green-50 p-6 rounded-xl">
                  <h4 className="font-semibold text-gray-900 mb-3">Materiais Aceitos</h4>
                  <div className="space-y-2">
                    {allowedWaste.map((waste, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <CheckCircle className="text-green-600" size={16} />
                        <span className="text-gray-700">{waste}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Pronto para Alugar sua Caçamba Ecológica?</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Entre em contato para agendar seu aluguel. Recomenda-se solicitar com antecedência.
          </p>

          <div className="flex justify-center gap-3 sm:gap-6 flex-wrap">
            <Link to="/contato">
              <Button className="bg-white text-green-600 hover:bg-gray-100 
                px-8 py-4 sm:px-8 sm:py-4 
                rounded-full text-md sm:text-lg font-semibold 
                flex items-center justify-center">
                <Phone size={20} />
                (64) 9 9309-5334
              </Button>
            </Link>

            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="bg-green-700 hover:bg-green-800 
                px-8 py-4 sm:px-8 sm:py-4 
                rounded-full text-md sm:text-lg font-semibold 
                border-2 border-white 
                flex items-center justify-center gap-2">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
                  alt="WhatsApp"
                  className="w-6 h-6 sm:w-7 sm:h-7 shrink-0"
                />
                WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default CacambaEcologicaPage
