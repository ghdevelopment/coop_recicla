import { BookOpen, ExternalLink, ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { normalizeImageUrl } from '@/lib/utils'
import { useEffect, useState, useCallback, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { api } from '@/lib/api'

/** Hook simples para breakpoints via matchMedia */
function useBreakpoint() {
  const get = () => ({
    isLg: typeof window !== 'undefined' && window.matchMedia('(min-width: 1024px)').matches, // lg+
    isMd: typeof window !== 'undefined' && window.matchMedia('(min-width: 768px)').matches,  // md+
  })
  const [bp, setBp] = useState(get)
  useEffect(() => {
    if (typeof window === 'undefined') return
    const qLg = window.matchMedia('(min-width: 1024px)')
    const qMd = window.matchMedia('(min-width: 768px)')
    const onChange = () => setBp(get())
    qLg.addEventListener('change', onChange)
    qMd.addEventListener('change', onChange)
    return () => {
      qLg.removeEventListener('change', onChange)
      qMd.removeEventListener('change', onChange)
    }
  }, [])
  return bp
}

/** Card reutilizável (inteiro clicável) */
const ResourceCard = ({ resource, compact = false }) => {
  const openPreview = useCallback(() => {
    if (resource.previewUrl && resource.previewUrl !== '#') {
      window.open(resource.previewUrl, '_blank', 'noopener,noreferrer')
    }
  }, [resource.previewUrl])

  const onKey = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      openPreview()
    }
  }

  return (
    <div
      role="link"
      tabIndex={0}
      aria-label={`Abrir ${resource.title}`}
      onClick={openPreview}
      onKeyDown={onKey}
      //bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1.5 overflow-hidden flex flex-col h-full
      className={[
        'bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 cursor-pointer',
        'focus:outline-none focus:ring-2 focus:ring-green-600',
        compact ? 'p-3 rounded-xl hover:-translate-y-1' : 'p-6',
        // alturas mínimas para alinhar o botão na base em todos os cards
        'flex flex-col justify-between min-h-[500px] md:min-h-[500px] lg:min-h-[500px]',
      ].join(' ')}
    >
      {/* Topo: imagem + textos */}
      <div>
        <div className="bg-gradient-to-br rounded-lg mb-4 overflow-hidden">
          <div className="relative w-full h-[500px] sm:h-[500px] md:h-[500px] lg:h-[500px] xl:h-[500px]">
            {resource.cover ? (
              <img
                  src={resource.cover}
                  alt={resource.title}
                  className="absolute inset-0 w-full h-full object-contain p-3 sm:p-4 md:p-5"
                  loading="lazy"
                  />
              ) : (
              <div className="absolute inset-0 flex items-center justify-center text-6xl text-white">📚</div>
            )}
          </div>
        </div>

        <div className={compact ? 'space-y-1' : 'space-y-3'}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">
              {resource.type}
            </span>
            {!compact && <BookOpen size={16} className="text-gray-400" />}
          </div>

          <h4
            className={[
              'font-bold text-gray-900 leading-tight',
              compact ? 'text-sm line-clamp-2' : 'text-base md:text-lg line-clamp-2',
            ].join(' ')}
            title={resource.title}
          >
            {resource.title}
          </h4>

          {resource.author && (
            <p
              className={[
                'text-gray-600 font-medium',
                compact ? 'text-xs line-clamp-1' : 'text-sm line-clamp-1',
              ].join(' ')}
              title={resource.author}
            >
              {resource.author}
            </p>
          )}

          {!compact && resource.description && (
            <p className="text-sm md:text-base text-gray-600 leading-relaxed line-clamp-4 md:line-clamp-3">
              {resource.description}
            </p>
          )}
        </div>
      </div>

      {/* Base: botão sempre alinhado */}
      <div className="mt-3">
        <Button
          onClick={(e) => {
            e.stopPropagation()
            openPreview()
          }}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 rounded-full text-sm md:text-base flex items-center justify-center"
        >
          Acessar<ExternalLink size={16} className="ml-2" />
        </Button>
      </div>
    </div>
  )
}

const EducationalResources = () => {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [resources, setResources] = useState([])
  const { isLg, isMd } = useBreakpoint()

  // Itens por "página" conforme breakpoint (padronizado):
  // - sm: 2 itens (1 linha, 2 colunas) → evitando voltar a 4 itens no mobile
  // - md: 3 itens (1 linha, 3 colunas)
  // - lg+: 4 itens (1 linha, 4 colunas)
  const itemsPerPage = useMemo(() => {
    // Padrão do site: 3 cards em lg+, 2 cards em md, 1 card em mobile
    if (isLg) return 3
    if (isMd) return 2
    return 1
  }, [isLg, isMd])

  // Normaliza índice quando o itemsPerPage muda
  useEffect(() => {
    setCurrentIndex((prev) => Math.floor(prev / itemsPerPage) * itemsPerPage)
  }, [itemsPerPage])

  useEffect(() => {
    const load = async () => {
      const data = await api.listWorks({ sort: '-createdAt' })
      const mapType = (cat) =>
        ({
          academic: 'Trabalho Acadêmico',
          children: 'Infantil',
          law: 'Lei',
          books: 'Livro',
          articles: 'Artigo',
          manuals: 'Manual',
        }[cat] || 'Recurso')

      const normalized = data.map((w) => ({
        id: w.id,
        title: w.title,
        author: w.author,
        type: mapType(w.category),
        description: w.description,
        cover: normalizeImageUrl(w.image || w.imagem || null),
        downloadUrl: w.downloadUrl || '#',
        previewUrl: w.previewUrl || w.url || '#',
      }))
      setResources(normalized)
    }
    load()
  }, [])

  const totalPages = useMemo(() => {
    const len = Math.max(resources.length, 1)
    return Math.ceil(len / itemsPerPage)
  }, [resources.length, itemsPerPage])

  const nextSlide = () => {
    setCurrentIndex((prev) => {
      const next = prev + itemsPerPage
      return next >= resources.length ? 0 : next
    })
  }

  const prevSlide = () => {
    setCurrentIndex((prev) => {
      const next = prev - itemsPerPage
      return next < 0 ? Math.max(0, resources.length - itemsPerPage) : next
    })
  }

  const currentResources = useMemo(
    () => resources.slice(currentIndex, currentIndex + itemsPerPage),
    [resources, currentIndex, itemsPerPage]
  )

  return (
    <section id="educational-resources" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-10 lg:mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Recursos Educacionais
          </h2>
          <h3 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 lg:mb-6">
            Biblioteca de Conhecimento
          </h3>
          <p className="text-base lg:text-lg text-gray-600 max-w-3xl mx-auto">
            Acesse nossa coleção de livros, manuais, trabalhos acadêmicos e artigos científicos sobre
            reciclagem, sustentabilidade e gestão de resíduos.
          </p>
        </div>

        {/* Carousel / Grid */}
        <div className="relative">
          {/* Mobile: 1 card por página (melhor leitura; demais no carrossel) */}
          <div className="md:hidden mb-6">
            {currentResources.map((resource) => (
              <div key={resource.id} className="max-w-md mx-auto">
                <ResourceCard resource={resource} />
              </div>
            ))}
          </div>

          {/* md: 2 colunas; lg+: 3 colunas — alinhado com itemsPerPage */}
          <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {currentResources.map((resource) => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>

          {/* Navegação */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={prevSlide}
                className="border-green-600 text-green-600 hover:bg-green-50"
                aria-label="Página anterior"
              >
                <ChevronLeft size={16} />
              </Button>

              <div className="flex gap-2">
                {Array.from({ length: totalPages }, (_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index * itemsPerPage)}
                    aria-label={`Ir para página ${index + 1}`}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      Math.floor(currentIndex / itemsPerPage) === index
                        ? 'bg-green-600'
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={nextSlide}
                className="border-green-600 text-green-600 hover:bg-green-50"
                aria-label="Próxima página"
              >
                <ChevronRight size={16} />
              </Button>
            </div>
          )}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/recursos-educacionais/biblioteca">
              <Button
                variant="outline"
                size="lg"
                className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 rounded-full text-lg font-semibold"
              >
                Ver Biblioteca Completa
                <ArrowRight className="ml-2" size={16} />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default EducationalResources
