import { useState, useCallback } from 'react'
import { Upload, X } from 'lucide-react'
import { Button } from './button'

export function ImageDropzone({ value, onChange, onRemove, disabled }) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    if (!disabled) setIsDragging(true)
  }, [disabled])

  const handleDragLeave = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    if (disabled) return

    const files = e.dataTransfer?.files
    if (files && files.length > 0) {
      const file = files[0]
      if (file.type.startsWith('image/')) {
        onChange?.(file)
      }
    }
  }, [disabled, onChange])

  const handleFileSelect = useCallback((e) => {
    const file = e.target.files?.[0]
    if (file) {
      onChange?.(file)
      e.target.value = '' // Reset input
    }
  }, [onChange])

  if (value) {
    return (
      <div className="space-y-2">
        <div className="relative w-full aspect-video bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
          <img 
            src={value} 
            alt="Pré-visualização" 
            className="w-full h-full object-contain"
          />
          {!disabled && (
            <button
              type="button"
              onClick={onRemove}
              className="absolute top-2 right-2 p-1.5 bg-red-500 hover:bg-red-600 text-white rounded-full shadow-lg transition-colors"
              title="Remover imagem"
            >
              <X size={16} />
            </button>
          )}
        </div>
        {!disabled && (
          <div className="flex gap-2">
            <Button type="button" variant="outline" size="sm" onClick={onRemove}>
              Remover
            </Button>
            <Button type="button" variant="secondary" size="sm" asChild>
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileSelect}
                  disabled={disabled}
                />
                Trocar Imagem
              </label>
            </Button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`
        relative w-full border-2 border-dashed rounded-lg transition-all
        ${isDragging 
          ? 'border-blue-500 bg-blue-50' 
          : 'border-gray-300 hover:border-gray-400 bg-gray-50'
        }
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
      `}
    >
      <input
        type="file"
        accept="image/*"
        className="hidden"
        id="dropzone-file-input"
        onChange={handleFileSelect}
        disabled={disabled}
      />
      <label
        htmlFor="dropzone-file-input"
        className={`flex flex-col items-center justify-center w-full h-48 ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6">
          <Upload 
            className={`w-10 h-10 mb-3 ${isDragging ? 'text-blue-500' : 'text-gray-400'}`}
          />
          <p className="mb-2 text-sm text-gray-600 font-medium">
            {isDragging ? (
              <span className="text-blue-600">Solte a imagem aqui</span>
            ) : (
              <>
                <span className="font-semibold">Clique para selecionar</span> ou arraste e solte
              </>
            )}
          </p>
          <p className="text-xs text-gray-500">JPG, PNG ou WEBP (máx. 10MB)</p>
        </div>
      </label>
    </div>
  )
}
