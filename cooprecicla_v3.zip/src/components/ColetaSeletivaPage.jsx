import {
  ArrowLeft, CheckCircle, Users, School, Truck, Phone
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Link } from 'react-router-dom'
import recyclingSymbol from '../assets/simbolo-de-reciclagem.png'
import pevImg from '../assets/pev.png'

const ColetaSeletivaPage = () => {
  const WHATSAPP_NUMBER = '5564992603912'
  const WHATSAPP_MESSAGE = 'Olá, gostaria de mais informações sobre o serviço de Coleta Seletiva.'
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`

  const benefits = [
    { icon: <School className="text-green-600" size={24} />, title: 'Educação Ambiental', description: 'Programas educativos em escolas para conscientização sobre reciclagem' },
    { icon: <Users className="text-green-600" size={24} />, title: 'Inclusão Social', description: 'Geração de renda e oportunidades para catadores e comunidade' },
    { icon: <Truck className="text-green-600" size={24} />, title: 'Coleta Programada', description: 'Cronograma personalizado de coleta para empresas e instituições' },
  ]

  const processSteps = [
    { number: '01', title: 'Separação', description: 'Separação correta dos materiais recicláveis na origem' },
    { number: '02', title: 'Coleta', description: 'Coleta programada conforme cronograma estabelecido' },
    { number: '03', title: 'Triagem', description: 'Triagem e classificação dos materiais na cooperativa' },
    { number: '04', title: 'Destinação', description: 'Destinação ambientalmente correta dos materiais' },
  ]

  return (
    <div className="min-h-screen bg-white">

      {/* HERO padronizado e com altura fixa */}
      <section className="relative bg-green-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/10" aria-hidden="true" />

        <div className="container mx-auto px-4 relative z-10 py-16 lg:py-20">
          {/* Botão Voltar */}
          <div className="mb-6">
            <Link to="/servicos">
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white rounded-full px-6 py-2 flex items-center gap-2 transition-all"
              >
                <ArrowLeft size={20} />
                Voltar
              </Button>
            </Link>
          </div>

          {/* Grid principal */}
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            {/* Texto à esquerda */}
            <div className="max-w-2xl">
              <div className="flex items-center mb-6">
                <div className="bg-white rounded-full mr-4 shadow-sm w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center flex-shrink-0">
                  <img
                    src={recyclingSymbol}
                    alt="Símbolo de Reciclagem"
                    className="w-10 h-10 lg:w-12 lg:h-12 object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-4xl lg:text-5xl font-bold mb-2">Coleta Seletiva</h1>
                  <p className="text-lg lg:text-xl text-green-100">
                    Soluções completas em coleta seletiva e conscientização ambiental
                  </p>
                </div>
              </div>
            </div>

            {/* Imagem do PEV fixa e proporcional */}
            <div className="relative">
              <div className="
                relative mx-auto w-full max-w-[480px]
                h-[260px] sm:h-[260px] md:h-[320px] lg:h-[340px] xl:h-[360px]
              ">
                {/* halo/“chão” */}
                <div
                  className="absolute bottom-2 left-1/2 -translate-x-1/2 w-3/4 h-5 rounded-full bg-black/15 blur-lg opacity-50"
                  aria-hidden="true"
                />
                {/* imagem absoluta, não afeta o tamanho do header */}
                <img
                  src={pevImg}
                  alt="Ponto de Entrega Voluntária (PEV) - Coop-Recicla"
                  loading="eager"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-contain drop-shadow-[0_8px_20px_rgba(0,0,0,0.25)] pointer-events-none select-none"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Principal */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Coleta Seletiva e Conscientização</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-green-600 mb-3">Como Funciona Nossa Coleta Seletiva:</h3>
                  <p className="text-gray-700 leading-relaxed">
                    A Cooperativa RECICLA possui uma parceria estratégica com a Prefeitura de Rio Verde. 
                    Realizamos a coleta seletiva nas regiões dos PEV (Pontos de Entrega Voluntária) e nas 
                    escolas municipais, enquanto nas empresas privadas, nossa cooperativa é responsável 
                    pela coleta especializada.
                  </p>
                </div>

                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Informações Importantes:</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} />Cobramos R$ 350,00 por tonelada de material reciclável</li>
                    <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} />Taxa de R$ 30,00 por coleta de Big Bag nas empresas</li>
                    <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} />Certificados ambientais e relatórios de sustentabilidade inclusos</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Benefícios */}
            <div className="bg-gray-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Nossos Benefícios</h3>
              <div className="space-y-6">
                {benefits.map((b, i) => (
                  <div key={i} className="flex items-start space-x-4">
                    <div className="bg-green-100 p-3 rounded-full flex-shrink-0">{b.icon}</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{b.title}</h4>
                      <p className="text-gray-600 text-sm">{b.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Processo de Coleta */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Como Funciona Nosso Processo</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Um processo simples, eficiente e totalmente rastreável para garantir a destinação correta dos materiais recicláveis
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="bg-green-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                    {step.number}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-green-600 text-white justify-cente">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Pronto para Implementar a Coleta Seletiva?</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Entre em contato conosco para mais informações sobre nossos serviços 
            de coleta seletiva e programas de conscientização ambiental.
          </p>
          <div className="flex justify-center gap-3 sm:gap-6 flex-wrap">
            <Link to="/contato">
              <Button className="bg-white text-green-600 hover:bg-gray-100 
                px-8 py-4 sm:px-8 sm:py-4 
                rounded-full text-md sm:text-lg font-semibold 
                flex items-center justify-center">
                <Phone size={20} />
                (64) 9 9260-3912
              </Button>
            </Link>

            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="bg-green-700 hover:bg-green-800 
                px-8 py-4 sm:px-8 sm:py-4 
                rounded-full text-md sm:text-lg font-semibold 
                border-2 border-white 
                flex items-center justify-center gap-2">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
                  alt="WhatsApp"
                  className="w-6 h-6 sm:w-7 sm:h-7 shrink-0"
                />
                WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default ColetaSeletivaPage
