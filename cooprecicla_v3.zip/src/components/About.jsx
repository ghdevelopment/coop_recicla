import { CheckCircle, Users, MapPin, Calendar } from 'lucide-react'

const About = () => {
  const highlights = [
    {
      icon: <Calendar className="text-green-600" size={24} />,
      title: "Fundada em 2008",
      description: "Mais de 17 anos de experiência em gestão de resíduos"
    },
    {
      icon: <MapPin className="text-green-600" size={24} />,
      title: "Rio Verde/GO",
      description: "Atendendo todo o Sudoeste Goiano"
    },
    {
      icon: <Users className="text-green-600" size={24} />,
      title: "Cooperativa Social",
      description: "Gerando renda e oportunidades para catadores"
    },
    {
      icon: <CheckCircle className="text-green-600" size={24} />,
      title: "Conformidade Legal",
      description: "Processos em acordo com a regulamentação"
    }
  ]

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide">
                Quem Somos
              </h2>
              <h3 className="text-4xl font-bold text-gray-900 leading-tight">
                Cooperativa de Trabalho de Catadores de Material Reciclável
              </h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                A <strong>COOP-RECICLA</strong> é uma cooperativa fundada em 2008 que oferece 
                serviços especializados de coleta e transporte de resíduos sólidos, garantindo 
                a destinação ambientalmente correta dos materiais.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Sediada em Rio Verde/Goiás, nossa cooperativa conta com infraestrutura completa 
                para atender a demanda de nossos clientes, realizando o processamento e destinação 
                dos materiais recicláveis em total conformidade com a regulamentação legal.
              </p>
            </div>

            {/* Mission Statement */}
            <div className="bg-green-50 p-6 rounded-2xl border-l-4 border-green-600">
              <h4 className="text-xl font-semibold text-gray-900 mb-3">Nossa Missão</h4>
              <p className="text-gray-700">
                Promover a sustentabilidade ambiental através da gestão responsável de resíduos, 
                gerando oportunidades de trabalho e renda para catadores, enquanto contribuímos 
                para a preservação do meio ambiente e o desenvolvimento da economia circular.
              </p>
            </div>
          </div>

          {/* Highlights Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {highlights.map((item, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">
                      {item.title}
                    </h4>
                    <p className="text-gray-600 text-sm">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
