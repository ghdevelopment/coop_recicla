import {
  ArrowLeft, GraduationCap, BookOpen, Trophy, Cpu, Megaphone,
  School, Users, Calendar, CheckCircle, Phone
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Link } from 'react-router-dom'
import educacaoAmbientalImg from '@/assets/educacao-ambiental.png'

const EducacaoAmbientalPage = () => {
  const WHATSAPP_NUMBER = '5564992603912'
  const WHATSAPP_MESSAGE = 'Olá! Quero saber mais sobre o serviço de Educação Ambiental.'
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`

  const acoes = [
    { icon: <BookOpen className="text-green-600" size={22} />, title: 'Educação & Sensibilização', desc: 'Conteúdos práticos sobre reciclagem, descarte responsável e impactos ambientais, para diferentes públicos.' },
    { icon: <Trophy className="text-green-600" size={22} />, title: 'Gincanas de Recicláveis', desc: 'Atividades semestrais que engajam a comunidade e aumentam o envio de materiais aos PEVs.' },
    { icon: <Cpu className="text-green-600" size={22} />, title: 'Museu Itinerante', desc: 'Tecnologia antiga para discutir consumo consciente e descarte de lixo eletrônico.' },
    { icon: <Megaphone className="text-green-600" size={22} />, title: 'Comunicação Comunitária', desc: 'Campanhas em redes sociais, rádio e TV para ampliar adesão e reduzir rejeitos.' },
    { icon: <School className="text-green-600" size={22} />, title: 'Parcerias com Escolas', desc: 'Integração com a rede de ensino — detalhes no programa abaixo.' },
    { icon: <CheckCircle className="text-green-600" size={22} />, title: 'Consultoria em E-lixo', desc: 'Suporte técnico a instituições no descarte de eletrônicos, com orientações e relatórios.' },
  ]

  return (
    <div className="min-h-screen bg-white">

      {/* HERO padronizado (altura fixa + imagem absoluta) */}
      <section className="relative bg-green-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/10" aria-hidden="true" />

        <div className="container mx-auto px-4 relative z-10 py-16 lg:py-20">
          {/* Voltar */}
          <div className="mb-6">
            <Link to="/servicos">
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white rounded-full px-6 py-2 flex items-center gap-2 transition-all"
              >
                <ArrowLeft size={18} />
                Voltar
              </Button>
            </Link>
          </div>

          {/* Grid hero */}
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            {/* Título + ícone */}
            <div className="max-w-2xl">
              <div className="flex items-center mb-6">
                <div className="bg-white rounded-full mr-4 shadow-sm w-16 h-16 lg:w-20 lg:h-20 flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="text-green-600 w-10 h-10 lg:w-12 lg:h-12" />
                </div>
                <div>
                  <h1 className="text-4xl lg:text-5xl font-bold mb-2">Educação Ambiental</h1>
                  <p className="text-lg lg:text-xl text-green-100">
                    Conscientização prática para formar hábitos sustentáveis desde cedo.
                  </p>
                </div>
              </div>
            </div>

            {/* Imagem (não altera a altura do header) */}
            <div className="relative">
              <div
                className="
                  relative mx-auto w-full max-w-[520px]
                  h-[260px] sm:h-[260px] md:h-[320px] lg:h-[340px] xl:h-[360px]
                "
              >
                {/* halo/chão */}
                <div
                  className="absolute bottom-2 left-1/2 -translate-x-1/2 w-3/4 h-5 rounded-full bg-black/15 blur-lg opacity-50"
                  aria-hidden="true"
                />
                {/* imagem absoluta */}
                <img
                  src={educacaoAmbientalImg}
                  alt="Educação Ambiental - Coop-Recicla"
                  loading="eager"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-contain drop-shadow-[0_8px_20px_rgba(0,0,0,0.25)] pointer-events-none select-none"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Principal (visão geral + ações) */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Como Atuamos</h2>
              <p className="text-gray-700 leading-relaxed mb-6">
                A COOP-RECICLA realiza ações de educação ambiental que incentivam a separação de recicláveis,
                o cuidado com o meio ambiente e a prática da sustentabilidade. Com palestras, gincanas,
                projetos em escolas e campanhas de comunicação, estimulamos atitudes responsáveis e fortalecemos
                a consciência da comunidade.
              </p>

              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded-r-lg">
                <h4 className="font-semibold text-gray-900 mb-2">Destaques</h4>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} />Palestras mensais em escolas indicadas pela Secretaria Municipal de Meio Ambiente</li>
                  <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} />Gincanas semestrais que engajam estudantes na separação de materiais</li>
                  <li className="flex items-start"><CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={16} />Museu itinerante sobre consumo de eletrônicos e descarte de e-lixo</li>
                </ul>
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Nossas Ações</h3>
              <div className="grid sm:grid-cols-2 gap-6">
                {acoes.map((a, i) => (
                  <Card key={i} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-5">
                      <div className="flex items-start gap-3">
                        <div className="bg-green-100 p-2.5 rounded-full flex-shrink-0">
                          {a.icon}
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900">{a.title}</h4>
                          <p className="text-gray-600 text-sm mt-1">{a.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Programa nas Escolas */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-green-100 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <School className="text-green-600" size={32} />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Programa nas Escolas</h2>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Parceria com a rede de ensino para desenvolver consciência ambiental desde cedo,
              com atividades dinâmicas, materiais didáticos e acompanhamento contínuo.
            </p>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="bg-green-100 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <Users className="text-green-600" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Formato</h3>
                <p className="text-gray-600">Encontros interativos, dinâmicas em grupo e atividades guiadas — presenciais ou híbridas.</p>
              </div>

              <div className="text-center">
                <div className="bg-green-100 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <Calendar className="text-green-600" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Cronograma</h3>
                <p className="text-gray-600">Ações mensais e eventos semestrais, combinados com cada escola parceira.</p>
              </div>

              <div className="text-center">
                <div className="bg-green-100 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="text-green-600" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Resultados</h3>
                <p className="text-gray-600">Maior adesão aos PEVs, redução de rejeitos e hábitos sustentáveis consolidados.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA final */}
      <section className="py-16 bg-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Quer levar a Educação Ambiental para sua escola ou instituição?
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Fale com nossa equipe e conheça os formatos de palestras, gincanas, museu itinerante e consultoria.
          </p>
          <div className="flex justify-center gap-3 sm:gap-6 flex-wrap">
            <Link to="/contato">
              <Button className="bg-white text-green-600 hover:bg-gray-100 
                px-8 py-4 sm:px-8 sm:py-4 
                rounded-full text-md sm:text-lg font-semibold 
                flex items-center justify-center">
                <Phone size={20} />
                (64) 9 9260-3912
              </Button>
            </Link>

            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="bg-green-700 hover:bg-green-800 
                px-8 py-4 sm:px-8 sm:py-4 
                rounded-full text-md sm:text-lg font-semibold 
                border-2 border-white 
                flex items-center justify-center gap-2">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
                  alt="WhatsApp"
                  className="w-6 h-6 sm:w-7 sm:h-7 shrink-0"
                />
                WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default EducacaoAmbientalPage
