import { ArrowRight, CalendarDays } from 'lucide-react'
import { Button } from '@/components/ui/button'

import { Link } from 'react-router-dom'

const BlogSection = () => {
  const posts = [
    {
      id: 1,
      title: "COOP RECICLA lança programa de educação ambiental em escolas",
      date: "15 de Setembro, 2025",
      excerpt: "Nossa cooperativa iniciou um novo programa para conscientizar crianças e adolescentes sobre a importância da reciclagem...",
      link: "#"
    },
    {
      id: 2,
      title: "Parceria com empresas locais impulsiona coleta seletiva em Rio Verde",
      date: "01 de Setembro, 2025",
      excerpt: "Novas parcerias estratégicas estão ampliando nossa capacidade de coleta e o volume de materiais reciclados na região...",
      link: "#"
    },
    {
      id: 3,
      title: "Dia Mundial da Limpeza: COOP RECICLA participa de ação comunitária",
      date: "20 de Agosto, 2025",
      excerpt: "Voluntários e membros da cooperativa se uniram para limpar áreas públicas e promover a conscientização ambiental...",
      link: "#"
    }
  ]

  return (
    <section id="blog" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Nosso Blog
          </h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">
            Últimas Notícias e Eventos
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Fique por dentro das novidades, projetos e ações da COOP RECICLA em prol da sustentabilidade e da comunidade.
          </p>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {posts.map((post) => (
            <div 
              key={post.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="p-6 space-y-4">
                <div className="flex items-center text-gray-500 text-sm">
                  <CalendarDays size={16} className="mr-2" />
                  <span>{post.date}</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 leading-tight">
                  {post.title}
                </h4>
                <p className="text-gray-600 leading-relaxed">
                  {post.excerpt}
                </p>
                <a 
                  href={post.link}
                  className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold transition-colors duration-200"
                >
                  Leia Mais
                  <ArrowRight className="ml-2" size={16} />
                </a>
              </div>
            </div>
          ))}
        </div>

	        {/* Call to Action for Blog Page */}
	        <div className="text-center">
	          <div className="flex flex-col sm:flex-row gap-4 justify-center">
	            <Link to="/novidades/publicacoes">
	              <Button 
	                variant="outline" 
	                size="lg" 
	                className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 rounded-full text-lg font-semibold"
	              >
	                Ver Todas as Publicações
	                <ArrowRight className="ml-2" size={20} />
	              </Button>
	            </Link>
	          </div>
	        </div>
      </div>
    </section>
  )
}

export default BlogSection
