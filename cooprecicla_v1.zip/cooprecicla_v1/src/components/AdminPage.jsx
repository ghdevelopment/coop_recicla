import { useState, useEffect } from 'react'
import { 
  ArrowLeft, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  X, 
  Upload, 
  Calendar, 
  Tag, 
  Eye,
  Search,
  Filter,
  MoreVertical,
  FileText,
  Image as ImageIcon
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'

const AdminPage = () => {
  const [posts, setPosts] = useState([
    {
      id: 1,
      titulo: "COOP RECICLA lança programa de educação ambiental em escolas",
      resumo: "Nossa cooperativa iniciou um novo programa para conscientizar crianças e adolescentes sobre a importância da reciclagem...",
      conteudo: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      data: "2025-09-15",
      categoria: "Educação",
      status: "Publicado",
      autor: "Equipe COOP RECICLA",
      imagem: "https://via.placeholder.com/400x250/22C55E/FFFFFF?text=Educação+Ambiental",
      tags: ["educação", "escolas", "sustentabilidade"],
      visualizacoes: 1250
    },
    {
      id: 2,
      titulo: "Parceria com empresas locais impulsiona coleta seletiva em Rio Verde",
      resumo: "Novas parcerias estratégicas estão ampliando nossa capacidade de coleta e o volume de materiais reciclados na região...",
      conteudo: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
      data: "2025-09-01",
      categoria: "Parcerias",
      status: "Publicado",
      autor: "João Silva",
      imagem: "https://via.placeholder.com/400x250/059669/FFFFFF?text=Parcerias+Locais",
      tags: ["parcerias", "empresas", "coleta"],
      visualizacoes: 890
    },
    {
      id: 3,
      titulo: "Dia Mundial da Limpeza: COOP RECICLA participa de ação comunitária",
      resumo: "Voluntários e membros da cooperativa se uniram para limpar áreas públicas e promover a conscientização ambiental...",
      conteudo: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
      data: "2025-08-20",
      categoria: "Eventos",
      status: "Rascunho",
      autor: "Maria Santos",
      imagem: "https://via.placeholder.com/400x250/0D9488/FFFFFF?text=Dia+Mundial+Limpeza",
      tags: ["evento", "limpeza", "comunidade"],
      visualizacoes: 0
    }
  ])

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingPost, setEditingPost] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('todos')
  const [filterCategory, setFilterCategory] = useState('todas')

  const [formData, setFormData] = useState({
    titulo: '',
    resumo: '',
    conteudo: '',
    categoria: '',
    status: 'Rascunho',
    autor: '',
    imagem: '',
    tags: ''
  })

  const categorias = ['Educação', 'Parcerias', 'Eventos', 'Sustentabilidade', 'Tecnologia', 'Comunidade']
  const statusOptions = ['Rascunho', 'Publicado', 'Arquivado']

  const resetForm = () => {
    setFormData({
      titulo: '',
      resumo: '',
      conteudo: '',
      categoria: '',
      status: 'Rascunho',
      autor: '',
      imagem: '',
      tags: ''
    })
    setEditingPost(null)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    const newPost = {
      ...formData,
      id: editingPost ? editingPost.id : Date.now(),
      data: editingPost ? editingPost.data : new Date().toISOString().split('T')[0],
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      visualizacoes: editingPost ? editingPost.visualizacoes : 0
    }

    if (editingPost) {
      setPosts(posts.map(post => post.id === editingPost.id ? newPost : post))
    } else {
      setPosts([newPost, ...posts])
    }

    resetForm()
    setIsDialogOpen(false)
  }

  const handleEdit = (post) => {
    setEditingPost(post)
    setFormData({
      titulo: post.titulo,
      resumo: post.resumo,
      conteudo: post.conteudo,
      categoria: post.categoria,
      status: post.status,
      autor: post.autor,
      imagem: post.imagem,
      tags: post.tags.join(', ')
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id) => {
    setPosts(posts.filter(post => post.id !== id))
  }

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.resumo.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === 'todos' || post.status === filterStatus
    const matchesCategory = filterCategory === 'todas' || post.categoria === filterCategory
    
    return matchesSearch && matchesStatus && matchesCategory
  })

  const getStatusColor = (status) => {
    switch (status) {
      case 'Publicado': return 'bg-green-100 text-green-700'
      case 'Rascunho': return 'bg-yellow-100 text-yellow-700'
      case 'Arquivado': return 'bg-gray-100 text-gray-700'
      default: return 'bg-gray-100 text-gray-700'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">

              <div>
                <h1 className="text-2xl font-bold text-gray-900">Administração do Blog</h1>
                <p className="text-gray-600">Gerencie notícias e eventos da COOP RECICLA</p>
              </div>
            </div>
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={resetForm}
                >
                  <Plus className="mr-2" size={16} />
                  Nova Publicação
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingPost ? 'Editar Publicação' : 'Nova Publicação'}
                  </DialogTitle>
                  <DialogDescription>
                    {editingPost ? 'Edite as informações da publicação' : 'Crie uma nova publicação para o blog'}
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="titulo">Título *</Label>
                      <Input
                        id="titulo"
                        value={formData.titulo}
                        onChange={(e) => setFormData({...formData, titulo: e.target.value})}
                        placeholder="Digite o título da publicação"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="autor">Autor *</Label>
                      <Input
                        id="autor"
                        value={formData.autor}
                        onChange={(e) => setFormData({...formData, autor: e.target.value})}
                        placeholder="Nome do autor"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="resumo">Resumo *</Label>
                    <Textarea
                      id="resumo"
                      value={formData.resumo}
                      onChange={(e) => setFormData({...formData, resumo: e.target.value})}
                      placeholder="Breve resumo da publicação (máximo 200 caracteres)"
                      maxLength={200}
                      rows={3}
                      required
                    />
                    <div className="text-xs text-gray-500 text-right">
                      {formData.resumo.length}/200 caracteres
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="conteudo">Conteúdo *</Label>
                    <Textarea
                      id="conteudo"
                      value={formData.conteudo}
                      onChange={(e) => setFormData({...formData, conteudo: e.target.value})}
                      placeholder="Conteúdo completo da publicação"
                      rows={8}
                      required
                    />
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="categoria">Categoria *</Label>
                      <Select 
                        value={formData.categoria} 
                        onValueChange={(value) => setFormData({...formData, categoria: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {categorias.map(categoria => (
                            <SelectItem key={categoria} value={categoria}>
                              {categoria}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="status">Status *</Label>
                      <Select 
                        value={formData.status} 
                        onValueChange={(value) => setFormData({...formData, status: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {statusOptions.map(status => (
                            <SelectItem key={status} value={status}>
                              {status}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="imagem">URL da Imagem</Label>
                      <Input
                        id="imagem"
                        value={formData.imagem}
                        onChange={(e) => setFormData({...formData, imagem: e.target.value})}
                        placeholder="https://exemplo.com/imagem.jpg"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags</Label>
                    <Input
                      id="tags"
                      value={formData.tags}
                      onChange={(e) => setFormData({...formData, tags: e.target.value})}
                      placeholder="educação, sustentabilidade, reciclagem (separadas por vírgula)"
                    />
                    <div className="text-xs text-gray-500">
                      Separe as tags com vírgulas
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4 border-t">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancelar
                    </Button>
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      <Save className="mr-2" size={16} />
                      {editingPost ? 'Salvar Alterações' : 'Criar Publicação'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filtros e Busca */}
        <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                <Input
                  placeholder="Buscar publicações..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os Status</SelectItem>
                  {statusOptions.map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas as Categorias</SelectItem>
                  {categorias.map(categoria => (
                    <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Estatísticas */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total de Posts</p>
                  <p className="text-2xl font-bold text-gray-900">{posts.length}</p>
                </div>
                <FileText className="text-green-600" size={24} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Publicados</p>
                  <p className="text-2xl font-bold text-green-600">
                    {posts.filter(p => p.status === 'Publicado').length}
                  </p>
                </div>
                <Eye className="text-green-600" size={24} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Rascunhos</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {posts.filter(p => p.status === 'Rascunho').length}
                  </p>
                </div>
                <Edit className="text-yellow-600" size={24} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Visualizações</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {posts.reduce((total, post) => total + post.visualizacoes, 0)}
                  </p>
                </div>
                <Eye className="text-blue-600" size={24} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de Publicações */}
        <div className="space-y-4">
          {filteredPosts.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <FileText className="mx-auto mb-4 text-gray-400" size={48} />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Nenhuma publicação encontrada
                </h3>
                <p className="text-gray-600">
                  {searchTerm || filterStatus !== 'todos' || filterCategory !== 'todas'
                    ? 'Tente ajustar os filtros de busca'
                    : 'Crie sua primeira publicação clicando no botão "Nova Publicação"'
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex gap-6">
                    {/* Imagem */}
                    <div className="flex-shrink-0">
                      <div className="w-24 h-24 bg-gray-200 rounded-lg overflow-hidden">
                        {post.imagem ? (
                          <img 
                            src={post.imagem} 
                            alt={post.titulo}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ImageIcon className="text-gray-400" size={24} />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Conteúdo */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 truncate pr-4">
                          {post.titulo}
                        </h3>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical size={16} />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(post)}>
                              <Edit className="mr-2" size={14} />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDelete(post.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="mr-2" size={14} />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>

                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                        {post.resumo}
                      </p>

                      <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                        <span className="flex items-center">
                          <Calendar className="mr-1" size={12} />
                          {new Date(post.data).toLocaleDateString('pt-BR')}
                        </span>
                        <span>Por {post.autor}</span>
                        <span className="flex items-center">
                          <Eye className="mr-1" size={12} />
                          {post.visualizacoes} visualizações
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(post.status)}>
                            {post.status}
                          </Badge>
                          <Badge variant="outline">
                            {post.categoria}
                          </Badge>
                        </div>

                        <div className="flex gap-2">
                          {post.tags.slice(0, 3).map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {post.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{post.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}

export default AdminPage
