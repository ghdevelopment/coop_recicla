import { BookOpen, Download, ExternalLink, ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useState } from 'react'
import { Link } from 'react-router-dom'

const EducationalResources = () => {
  const [currentIndex, setCurrentIndex] = useState(0)

  const resources = [
    {
      id: 1,
      title: "Manual de Gestão de Resíduos Sólidos",
      author: "ABRELPE",
      type: "Manual",
      description: "Guia completo sobre gestão sustentável de resíduos sólidos urbanos.",
      cover: "https://via.placeholder.com/200x280/22C55E/FFFFFF?text=Manual+Gestão",
      downloadUrl: "#"
    },
    {
      id: 2,
      title: "Economia Circular e Sustentabilidade",
      author: "Ellen MacArthur Foundation",
      type: "Livro",
      description: "Conceitos fundamentais sobre economia circular aplicada à gestão de resíduos.",
      cover: "https://via.placeholder.com/200x280/059669/FFFFFF?text=Economia+Circular",
      downloadUrl: "#"
    },
    {
      id: 3,
      title: "Reciclagem: Processos e Tecnologias",
      author: "Universidade Federal de Goiás",
      type: "Trabalho Acadêmico",
      description: "Estudo sobre tecnologias modernas aplicadas aos processos de reciclagem.",
      cover: "https://via.placeholder.com/200x280/0D9488/FFFFFF?text=Processos+Reciclagem",
      downloadUrl: "#"
    },
    {
      id: 4,
      title: "Impactos Ambientais da Reciclagem",
      author: "Instituto de Pesquisas Ambientais",
      type: "Artigo Científico",
      description: "Análise dos benefícios ambientais dos processos de reciclagem de materiais.",
      cover: "https://via.placeholder.com/200x280/16A34A/FFFFFF?text=Impactos+Ambientais",
      downloadUrl: "#"
    },
    {
      id: 5,
      title: "Cooperativismo e Sustentabilidade",
      author: "OCB - Organização das Cooperativas Brasileiras",
      type: "Guia",
      description: "Como as cooperativas contribuem para o desenvolvimento sustentável.",
      cover: "https://via.placeholder.com/200x280/15803D/FFFFFF?text=Cooperativismo",
      downloadUrl: "#"
    },
    {
      id: 6,
      title: "Educação Ambiental na Prática",
      author: "Ministério do Meio Ambiente",
      type: "Manual",
      description: "Metodologias práticas para implementação de programas de educação ambiental.",
      cover: "https://via.placeholder.com/200x280/166534/FFFFFF?text=Educação+Ambiental",
      downloadUrl: "#"
    }
  ]

  const itemsPerPage = 4
  const totalPages = Math.ceil(resources.length / itemsPerPage)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex + itemsPerPage >= resources.length ? 0 : prevIndex + itemsPerPage
    )
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex - itemsPerPage < 0 ? Math.max(0, resources.length - itemsPerPage) : prevIndex - itemsPerPage
    )
  }

  const currentResources = resources.slice(currentIndex, currentIndex + itemsPerPage)

  return (
    <section id="educational-resources" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Recursos Educacionais
          </h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">
            Biblioteca de Conhecimento
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Acesse nossa coleção de livros, manuais, trabalhos acadêmicos e artigos científicos sobre reciclagem, sustentabilidade e gestão de resíduos.
          </p>
        </div>

	        {/* Carousel */}
	        <div className="relative">
	          {/* Layout para Mobile: 2 colunas, espaçamento menor, texto mais resumido */}
	          <div className="grid grid-cols-2 md:hidden gap-3 mb-6">
	            {currentResources.slice(0, 2).map((resource) => (
	              <div 
	                key={resource.id}
	                className="bg-gray-50 rounded-xl p-3 hover:shadow-lg transition-all duration-300"
	              >
	                <div className="aspect-[3/4] bg-gradient-to-br from-green-400 to-green-600 rounded-md mb-2 flex items-center justify-center overflow-hidden">
	                  <img 
	                    src={resource.cover} 
	                    alt={resource.title}
	                    className="w-full h-full object-cover"
	                  />
	                </div>
	                <div className="space-y-1">
	                  <h4 className="font-bold text-gray-900 text-xs leading-tight line-clamp-2">
	                    {resource.title}
	                  </h4>
	                  <p className="text-[10px] text-gray-600 font-medium line-clamp-1">
	                    {resource.author}
	                  </p>
	                  <div className="flex gap-1 pt-1">
	                    <Button 
	                      size="xs" 
	                      className="bg-green-600 hover:bg-green-700 text-white flex-1 text-[10px] h-6"
	                    >
	                      <Download size={10} className="mr-1" />
	                      Baixar
	                    </Button>
	                    <Button 
	                      variant="outline" 
	                      size="xs" 
	                      className="border-green-600 text-green-600 hover:bg-green-50 h-6 w-6 p-0"
	                    >
	                      <ExternalLink size={10} />
	                    </Button>
	                  </div>
	                </div>
	              </div>
	            ))}
	          </div>
	
	          {/* Layout para Desktop/Tablet: 4 colunas, visual original */}
	          <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
	            {currentResources.map((resource) => (
	              <div 
	                key={resource.id}
	                className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-2"
	              >
	                <div className="aspect-[3/4] bg-gradient-to-br from-green-400 to-green-600 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
	                  <img 
	                    src={resource.cover} 
	                    alt={resource.title}
	                    className="w-full h-full object-cover"
	                  />
	                </div>
	                <div className="space-y-3">
	                  <div className="flex items-center justify-between">
	                    <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">
	                      {resource.type}
	                    </span>
	                    <BookOpen size={16} className="text-gray-400" />
	                  </div>
	                  <h4 className="font-bold text-gray-900 text-sm leading-tight line-clamp-2">
	                    {resource.title}
	                  </h4>
	                  <p className="text-xs text-gray-600 font-medium line-clamp-1">
	                    {resource.author}
	                  </p>
	                  <p className="text-xs text-gray-500 leading-relaxed line-clamp-3">
	                    {resource.description}
	                  </p>
	                  <div className="flex gap-2 pt-2">
	                    <Button 
	                      size="sm" 
	                      className="bg-green-600 hover:bg-green-700 text-white flex-1 text-xs"
	                    >
	                      <Download size={12} className="mr-1" />
	                      Baixar
	                    </Button>
	                    <Button 
	                      variant="outline" 
	                      size="sm" 
	                      className="border-green-600 text-green-600 hover:bg-green-50"
	                    >
	                      <ExternalLink size={12} />
	                    </Button>
	                  </div>
	                </div>
	              </div>
	            ))}
	          </div>

          {/* Navigation Arrows */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={prevSlide}
                className="border-green-600 text-green-600 hover:bg-green-50"
              >
                <ChevronLeft size={16} />
              </Button>
              
              <div className="flex gap-2">
                {Array.from({ length: totalPages }, (_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index * itemsPerPage)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      Math.floor(currentIndex / itemsPerPage) === index
                        ? 'bg-green-600'
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={nextSlide}
                className="border-green-600 text-green-600 hover:bg-green-50"
              >
                <ChevronRight size={16} />
              </Button>
            </div>
          )}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
	            <Link to="/recursos-educacionais/biblioteca">
	              <Button 
	                variant="outline" 
	                size="lg" 
	                className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 rounded-full text-lg font-semibold"
	              >
	                Ver Biblioteca Completa
                  
	                <ArrowRight className="ml-2" size={16} />
	              </Button>
	            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default EducationalResources
