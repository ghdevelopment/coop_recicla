import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Menu, X, Phone, Mail } from "lucide-react";
import coopLogo from "../assets/coop-recicla-logo.png";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const toggleMenu = () => setIsMenuOpen((v) => !v);

  // todos são seções da landing com URLs limpas
  const menuItems = [
    { name: "Início", href: "/inicio" },
    { name: "Quem Somos", href: "/quem-somos" },
    { name: "Serviços", href: "/servicos" },
    { name: "Sustentabilidade", href: "/sustentabilidade" },
    { name: "Novidades", href: "/novidades" },
    { name: "Biblioteca", href: "/recursos-educacionais" },
    { name: "Contato", href: "/contato" },
  ];

  const WHATSAPP_NUMBER = "5564992603912";
  const WHATSAPP_MESSAGE =
    "Olá, gostaria de mais informações sobre os serviços da Coop-recicla.";
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    WHATSAPP_MESSAGE
  )}`;

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Top bar */}
      <div className="bg-green-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Phone size={14} />
              <span>(64) 3621-3333</span>
            </div>
            <div className="flex items-center space-x-1">
              <Mail size={14} />
              <span>contato@cooperativarecicla.com.br</span>
            </div>
          </div>
          <div className="hidden md:block">
            <span>Rio Verde/GO - Sustentabilidade em Ação</span>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img src={coopLogo} alt="COOP RECICLA Logo" className="h-20 w-auto" />
            <div>
              <h1 className="text-xl font-bold text-green-700">COOP-RECICLA</h1>
              <p className="text-sm text-gray-600">Cooperativa de Reciclagem</p>
            </div>
          </div>

          {/* Desktop menu */}
          <div className="hidden lg:flex items-center space-x-8">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-gray-700 hover:text-green-600 font-medium transition-colors duration-200"
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* CTA + Mobile toggle */}
          <div className="flex items-center space-x-4">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold px-6 py-2 rounded-full">
                Fale Conosco
              </Button>
            </a>
            <button
              onClick={toggleMenu}
              className="lg:hidden p-2 rounded-md text-gray-700 hover:text-green-600"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-gray-200">
            <div className="flex flex-col space-y-3 pt-4">
              {menuItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-gray-700 hover:text-green-600 font-medium py-2 transition-colors duration-200"
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
