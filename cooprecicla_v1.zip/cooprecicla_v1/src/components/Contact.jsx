import { Button } from '@/components/ui/button'
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react'
import facebookLogo from '../assets/facebook.png'
import instagramLogo from '../assets/Instagram.png'
import whatsappLogo from '../assets/whatsapp.png'

const Contact = () => {
  const WHATSAPP_NUMBER = '5564992603912' 
  const WHATSAPP_MESSAGE = 'Olá, gostaria de mais informações sobre os serviços da Coop-recicla.'
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`
  const contactInfo = [
    {
      icon: <Phone className="text-green-600" size={22} />,
      title: "Telefone",
      info: "(64) 3621-3333",
      description: "Atendimento de segunda à sexta"
    },
    {
      icon: <Mail className="text-green-600" size={22} />,
      title: "E-mail",
      info: "contato@cooperativarecicla.com.br",
      description: "Resposta em até 24 horas"
    },
    {
      icon: <MapPin className="text-green-600" size={22} />,
      title: "Endereço",
      info: "Rio Verde/GO",
      description: "Sudoeste Goiano"
    },
    {
      icon: <Clock className="text-green-600" size={22} />,
      title: "Horário",
      info: "07:00 às 17:00",
      description: "Segunda a sexta-feira"
    }
  ]

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Entre em Contato
          </h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">
            Vamos Conversar Sobre Sustentabilidade
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Estamos prontos para atender sua empresa com soluções personalizadas 
            em gestão de resíduos. Entre em contato conosco!
          </p>
        </div>

        {/* Grid principal: cards levemente maiores e colunas mais próximas */}
        <div className="grid gap-8 xl:gap-10 lg:grid-cols-[1.08fr_1fr]">
          {/* Coluna 1: Informações + Mapa + Social */}
          <div className="space-y-8">
            {/* Contact Information */}
            <div>
              <h4 className="text-2xl font-bold text-gray-900 mb-6">
                Informações de Contato
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {contactInfo.map((item, index) => (
                  <div 
                    key={index}
                    className="bg-gray-50 p-6 rounded-xl hover:bg-gray-100 transition-colors duration-200"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="bg-green-100 p-3 rounded-full">
                        {item.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h5 className="font-semibold text-gray-900 mb-1">
                          {item.title}
                        </h5>
                        {/* deixa quebrar quando precisar, mas com quebra “bonita” */}
                        <p className="text-gray-900 font-medium mb-1 break-all sm:break-words">
                          {item.info}
                        </p>
                        <p className="text-gray-600 text-sm">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="bg-gray-100 rounded-xl p-8 text-center">
              <MapPin className="text-gray-400 mx-auto mb-4" size={48} />
              <h5 className="text-lg font-semibold text-gray-700 mb-2">
                Nossa Localização
              </h5>
              <p className="text-gray-600">
                Rio Verde/GO - Sudoeste Goiano
              </p>
              <Button 
                variant="outline" 
                className="mt-4 border-green-600 text-green-600 hover:bg-green-50"
              >
                Ver no Mapa
              </Button>
            </div>

            {/* Social Media */}
            <div>
              <h5 className="text-lg font-semibold text-gray-900 mb-4">
                Siga-nos nas Redes Sociais
              </h5>

              <div className="flex space-x-4">
	                {/* Facebook */}
	                <a
	                  href="https://www.facebook.com/Coopreciclasudoeste" 
	                  target="_blank"
	                  rel="noopener noreferrer"
	                  aria-label="Facebook"
	                  className="relative w-12 h-12 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
	                >
	                  <img
	                    src={facebookLogo}
	                    alt="facebook logo"
	                    className="absolute inset-0 w-full h-full object-cover object-center block select-none pointer-events-none"
	                    draggable="false"
	                  />
	                </a>
	
	                {/* Instagram */}
	                <a
	                  href="https://www.instagram.com/coop_recicla" 
	                  target="_blank"
	                  rel="noopener noreferrer"
	                  aria-label="Instagram"
	                  className="relative w-12 h-12 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
	                >
	                  <img
	                    src={instagramLogo}
	                    alt="instagram logo"
	                    className="absolute inset-0 w-full h-full object-cover object-center block select-none pointer-events-none"
	                    draggable="false"
	                  />
	                </a>

	                {/* WhatsApp */}
	                <a
	                  href={whatsappLink}
	                  target="_blank"
	                  rel="noopener noreferrer"
	                  aria-label="WhatsApp"
	                  className="relative w-12 h-12 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
	                >
	                  <img
	                    src={whatsappLogo}
	                    alt="whatsapp logo"
	                    className="absolute inset-0 w-full h-full object-cover object-center block select-none pointer-events-none"
	                    draggable="false"
	                  />
	                </a>
              </div>
            </div>
          </div>

          {/* Coluna 2: Formulário */}
          <div className="bg-gray-50 rounded-2xl p-8 lg:-mt-6">
            <h4 className="text-2xl font-bold text-gray-900 -mt-2 mb-6">
              Solicite um Orçamento
            </h4>
            <form className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome *
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Seu nome completo"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Empresa
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Nome da empresa"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="seu@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Telefone *
                  </label>
                  <input
                    type="tel"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="(64) 99999-9999"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Serviço de Interesse
                </label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent">
                  <option value="">Selecione um serviço</option>
                  <option value="coleta-seletiva">Coleta Seletiva</option>
                  <option value="cacamba-ecologica">Caçamba Ecológica</option>
                  <option value="educacao-ambiental">Educação Ambiental</option>
                  <option value="consultoria">Consultoria em Sustentabilidade</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mensagem *
                </label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Conte-nos mais sobre suas necessidades..."
                ></textarea>
              </div>

              <Button 
                type="submit"
                className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg font-semibold text-lg"
              >
                Enviar Mensagem
                <Send className="ml-2" size={20} />
              </Button>

              <p className="text-sm text-gray-600 text-center">
                * Campos obrigatórios. Responderemos em até 24 horas.
              </p>
            </form>
          </div>
        </div>

        {/* WhatsApp CTA */}
        <div className="mt-16 text-center">
          <div className="bg-green-600 text-white rounded-2xl p-8 inline-block">
            <h4 className="text-2xl font-bold mb-4">Precisa de Atendimento Imediato?</h4>
            <p className="text-lg mb-6 opacity-90">
              Fale conosco pelo WhatsApp e receba atendimento personalizado
            </p>
	            <a 
	              href={whatsappLink}
	              target="_blank"
	              rel="noopener noreferrer"
	            >
	              <Button 
	                className="bg-white text-green-600 hover:bg-gray-100 px-8 py-4 rounded-full font-semibold text-lg"
	              >
	                <img className="h-9 w-auto mr-2" src={whatsappLogo} alt="whatsapp logo" /> Chamar no WhatsApp
	              </Button>
	            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
