import { useState } from 'react'
import { Search, Filter, Download, Eye, BookOpen, FileText, GraduationCap, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'

const LibraryPage = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')

  const categories = [
    { id: 'all', name: 'Todos', icon: BookOpen },
    { id: 'academic', name: 'Trabalhos Acadêmicos', icon: GraduationCap },
    { id: 'books', name: 'Livros', icon: BookOpen },
    { id: 'articles', name: 'Artigos', icon: FileText },
    { id: 'manuals', name: 'Manuais', icon: FileText }
  ]

  const resources = [
    {
      id: 1,
      title: "Manual de Gestão de Resíduos Sólidos Urbanos",
      author: "Ministério do Meio Ambiente",
      category: "manuals",
      year: 2023,
      pages: 156,
      description: "Guia completo para implementação de sistemas de gestão de resíduos sólidos em municípios brasileiros.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "📋"
    },
    {
      id: 2,
      title: "Economia Circular e Sustentabilidade",
      author: "Dr. Maria Silva",
      category: "books",
      year: 2022,
      pages: 284,
      description: "Análise profunda dos princípios da economia circular e sua aplicação em cooperativas de reciclagem.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "📚"
    },
    {
      id: 3,
      title: "Impacto Socioeconômico das Cooperativas de Catadores",
      author: "João Santos",
      category: "academic",
      year: 2023,
      pages: 98,
      description: "Dissertação de mestrado sobre o papel das cooperativas na inclusão social e desenvolvimento econômico.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "🎓"
    },
    {
      id: 4,
      title: "Tecnologias Limpas na Reciclagem",
      author: "Instituto de Pesquisa Ambiental",
      category: "articles",
      year: 2023,
      pages: 45,
      description: "Artigo científico sobre inovações tecnológicas no processamento de materiais recicláveis.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "🔬"
    },
    {
      id: 5,
      title: "Educação Ambiental em Comunidades",
      author: "Ana Costa",
      category: "books",
      year: 2022,
      pages: 198,
      description: "Metodologias práticas para implementação de programas de educação ambiental.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "🌱"
    },
    {
      id: 6,
      title: "Análise do Ciclo de Vida de Materiais Recicláveis",
      author: "Carlos Oliveira",
      category: "academic",
      year: 2023,
      pages: 124,
      description: "Tese de doutorado sobre avaliação do impacto ambiental de diferentes materiais recicláveis.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "♻️"
    },
    {
      id: 7,
      title: "Políticas Públicas para Gestão de Resíduos",
      author: "Secretaria de Meio Ambiente",
      category: "manuals",
      year: 2023,
      pages: 89,
      description: "Manual sobre legislação e políticas públicas relacionadas à gestão de resíduos sólidos.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "⚖️"
    },
    {
      id: 8,
      title: "Sustentabilidade e Desenvolvimento Local",
      author: "Revista Ambiental Brasileira",
      category: "articles",
      year: 2023,
      pages: 32,
      description: "Artigo sobre o papel das cooperativas de reciclagem no desenvolvimento sustentável local.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "🏘️"
    },
    {
      id: 9,
      title: "Gestão Financeira em Cooperativas",
      author: "Prof. Roberto Lima",
      category: "books",
      year: 2022,
      pages: 245,
      description: "Guia prático para gestão financeira e administrativa de cooperativas de trabalho.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "💰"
    },
    {
      id: 10,
      title: "Inovação Social na Reciclagem",
      author: "Fernanda Rocha",
      category: "academic",
      year: 2023,
      pages: 156,
      description: "Estudo sobre inovações sociais implementadas por cooperativas de catadores no Brasil.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "💡"
    },
    {
      id: 11,
      title: "Manual de Segurança no Trabalho",
      author: "COOP RECICLA",
      category: "manuals",
      year: 2023,
      pages: 67,
      description: "Protocolo de segurança e saúde ocupacional para trabalhadores da reciclagem.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "🦺"
    },
    {
      id: 12,
      title: "Logística Reversa e Economia Circular",
      author: "Instituto de Logística",
      category: "articles",
      year: 2023,
      pages: 28,
      description: "Análise da implementação de sistemas de logística reversa em cadeias de reciclagem.",
      downloadUrl: "#",
      previewUrl: "#",
      image: "🚛"
    }
  ]

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
	          <div className="flex items-center gap-4 mb-6">
	            <div>
	              <h1 className="text-3xl font-bold text-gray-900">Biblioteca de Recursos Educacionais</h1>
	              <p className="text-gray-600 mt-2">Acesse nossa coleção completa de materiais sobre sustentabilidade e reciclagem</p>
	            </div>
	          </div>

          {/* Search and Filter */}
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Buscar por título, autor ou descrição..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {categories.map((category) => {
                const Icon = category.icon
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`flex items-center gap-2 whitespace-nowrap ${
                      selectedCategory === category.id 
                        ? 'bg-green-600 text-white' 
                        : 'text-gray-700 hover:bg-green-50'
                    }`}
                  >
                    <Icon size={16} />
                    {category.name}
                  </Button>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <p className="text-gray-600">
            {filteredResources.length} {filteredResources.length === 1 ? 'resultado encontrado' : 'resultados encontrados'}
          </p>
        </div>

	        {/* Resource Grid */}
	        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
	          {filteredResources.map((resource) => (
	            <div key={resource.id} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
	              <div className="p-4 md:p-6">
	                <div className="flex items-start gap-3 md:gap-4 mb-3 md:mb-4">
	                  <div className="text-2xl md:text-4xl">{resource.image}</div>
	                  <div className="flex-1">
	                    <h3 className="text-sm md:text-lg font-semibold text-gray-900 mb-1 md:mb-2 line-clamp-2">
	                      {resource.title}
	                    </h3>
	                    <p className="text-xs text-gray-600 mb-1 line-clamp-1">Por: {resource.author}</p>
	                    <div className="flex items-center gap-2 md:gap-4 text-[10px] md:text-xs text-gray-500">
	                      <span>{resource.year}</span>
	                      <span>•</span>
	                      <span>{resource.pages} pág.</span>
	                    </div>
	                  </div>
	                </div>
	
	                <p className="text-gray-600 text-xs md:text-sm mb-3 md:mb-4 line-clamp-3">
	                  {resource.description}
	                </p>
	
	                <div className="flex gap-2">
	                  <Button 
	                    size="sm" 
	                    className="flex-1 bg-green-600 hover:bg-green-700 text-white text-xs"
	                    onClick={() => window.open(resource.downloadUrl, '_blank')}
	                  >
	                    <Download size={14} className="mr-1" />
	                    Baixar
	                  </Button>
	                  <Button 
	                    size="sm" 
	                    variant="outline"
	                    className="flex-1 border-green-600 text-green-600 hover:bg-green-50 text-xs"
	                    onClick={() => window.open(resource.previewUrl, '_blank')}
	                  >
	                    <Eye size={14} className="mr-1" />
	                    Visualizar
	                  </Button>
	                </div>
	              </div>
	            </div>
	          ))}
	        </div>

        {filteredResources.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Nenhum resultado encontrado</h3>
            <p className="text-gray-600">Tente ajustar sua busca ou filtros para encontrar o que procura.</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default LibraryPage
