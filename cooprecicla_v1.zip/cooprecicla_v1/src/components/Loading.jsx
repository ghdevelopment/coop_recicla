import { useEffect, useState } from 'react'
import { Recycle } from 'lucide-react'

const Loading = () => {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  if (!isLoading) return null

  return (
    <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
      <div className="text-center space-y-2">
        <div className="relative">
          <Recycle 
            size={64} 
            className="text-green-600 animate-spin mx-auto" 
            style={{ animationDuration: '2s' }}/>
          
          <div className="absolute inset-0 rounded-full opacity-20 animate-pulse"></div>
        </div>

        <div className="space-y-2">
          <p className="text-gray-600">Carregando sustentabilidade...</p>
          <div className="w-54 h-2 bg-gray-200 rounded-full mx-auto overflow-hidden">
          <div className="h-full bg-gradient-to-r from-green-500 to-blue-500 rounded-full animate-pulse"></div>
        </div>
        
        </div>
      </div>
    </div>
  )
}

export default Loading
