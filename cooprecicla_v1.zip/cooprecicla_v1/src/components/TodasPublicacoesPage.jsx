import { useState, useEffect } from 'react'
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Calendar, 
  Tag, 
  Eye, 
  ArrowRight,
  Clock,
  User,
  ChevronDown,
  Grid,
  List,
  SortAsc,
  SortDesc
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'

const TodasPublicacoesPage = () => {
  const [posts, setPosts] = useState([
    {
      id: 1,
      titulo: "COOP RECICLA lança programa de educação ambiental em escolas",
      resumo: "Nossa cooperativa iniciou um novo programa para conscientizar crianças e adolescentes sobre a importância da reciclagem e sustentabilidade. O projeto já alcançou mais de 500 estudantes em 10 escolas da região.",
      data: "2025-09-15",
      categoria: "Educação",
      autor: "Equipe COOP RECICLA",
      imagem: "https://via.placeholder.com/400x250/22C55E/FFFFFF?text=Educação+Ambiental",
      tags: ["educação", "escolas", "sustentabilidade", "crianças"],
      visualizacoes: 1250,
      tempoLeitura: "5 min"
    },
    {
      id: 2,
      titulo: "Parceria com empresas locais impulsiona coleta seletiva em Rio Verde",
      resumo: "Novas parcerias estratégicas estão ampliando nossa capacidade de coleta e o volume de materiais reciclados na região. As empresas parceiras demonstram compromisso real com a sustentabilidade.",
      data: "2025-09-01",
      categoria: "Parcerias",
      autor: "João Silva",
      imagem: "https://via.placeholder.com/400x250/059669/FFFFFF?text=Parcerias+Locais",
      tags: ["parcerias", "empresas", "coleta", "crescimento"],
      visualizacoes: 890,
      tempoLeitura: "3 min"
    },
    {
      id: 3,
      titulo: "Dia Mundial da Limpeza: COOP RECICLA participa de ação comunitária",
      resumo: "Voluntários e membros da cooperativa se uniram para limpar áreas públicas e promover a conscientização ambiental. A ação mobilizou mais de 200 pessoas em diferentes pontos da cidade.",
      data: "2025-08-20",
      categoria: "Eventos",
      autor: "Maria Santos",
      imagem: "https://via.placeholder.com/400x250/0D9488/FFFFFF?text=Dia+Mundial+Limpeza",
      tags: ["evento", "limpeza", "comunidade", "voluntários"],
      visualizacoes: 1450,
      tempoLeitura: "4 min"
    },
    {
      id: 4,
      titulo: "Inovação tecnológica: Nova máquina de triagem aumenta eficiência",
      resumo: "Investimento em tecnologia moderna permite processar 40% mais materiais recicláveis por dia. A nova máquina representa um marco na modernização da cooperativa.",
      data: "2025-08-05",
      categoria: "Tecnologia",
      autor: "Carlos Oliveira",
      imagem: "https://via.placeholder.com/400x250/16A34A/FFFFFF?text=Tecnologia+Triagem",
      tags: ["tecnologia", "inovação", "eficiência", "modernização"],
      visualizacoes: 720,
      tempoLeitura: "6 min"
    },
    {
      id: 5,
      titulo: "Workshop de compostagem ensina técnicas sustentáveis",
      resumo: "Evento gratuito ensinou moradores a transformar resíduos orgânicos em adubo natural. Mais de 80 famílias participaram e aprenderam técnicas práticas de compostagem doméstica.",
      data: "2025-07-28",
      categoria: "Educação",
      autor: "Ana Costa",
      imagem: "https://via.placeholder.com/400x250/15803D/FFFFFF?text=Workshop+Compostagem",
      tags: ["workshop", "compostagem", "sustentabilidade", "educação"],
      visualizacoes: 650,
      tempoLeitura: "4 min"
    },
    {
      id: 6,
      titulo: "Cooperativa recebe certificação de qualidade ambiental",
      resumo: "COOP RECICLA obtém importante certificação que reconhece suas práticas sustentáveis e compromisso com o meio ambiente. O selo valida anos de trabalho dedicado.",
      data: "2025-07-15",
      categoria: "Conquistas",
      autor: "Diretoria COOP RECICLA",
      imagem: "https://via.placeholder.com/400x250/166534/FFFFFF?text=Certificação+Ambiental",
      tags: ["certificação", "qualidade", "reconhecimento", "sustentabilidade"],
      visualizacoes: 980,
      tempoLeitura: "3 min"
    },
    {
      id: 7,
      titulo: "Projeto piloto de coleta em condomínios mostra resultados positivos",
      resumo: "Iniciativa experimental em 5 condomínios residenciais aumentou em 60% a separação correta de materiais recicláveis. O sucesso indica expansão do programa.",
      data: "2025-07-02",
      categoria: "Projetos",
      autor: "Equipe de Projetos",
      imagem: "https://via.placeholder.com/400x250/22C55E/FFFFFF?text=Projeto+Condomínios",
      tags: ["projeto", "condomínios", "coleta", "resultados"],
      visualizacoes: 540,
      tempoLeitura: "5 min"
    },
    {
      id: 8,
      titulo: "Feira de sustentabilidade atrai milhares de visitantes",
      resumo: "Evento anual da COOP RECICLA reuniu expositores, palestras e atividades educativas. A feira se consolidou como principal evento de sustentabilidade da região.",
      data: "2025-06-20",
      categoria: "Eventos",
      autor: "Comissão Organizadora",
      imagem: "https://via.placeholder.com/400x250/059669/FFFFFF?text=Feira+Sustentabilidade",
      tags: ["feira", "sustentabilidade", "evento", "educação"],
      visualizacoes: 2100,
      tempoLeitura: "7 min"
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('todas')
  const [sortBy, setSortBy] = useState('data-desc')
  const [viewMode, setViewMode] = useState('grid')
  const [currentPage, setCurrentPage] = useState(1)
  const postsPerPage = 6

  const categorias = ['Educação', 'Parcerias', 'Eventos', 'Tecnologia', 'Conquistas', 'Projetos']
  const todasTags = [...new Set(posts.flatMap(post => post.tags))]

  // Filtrar e ordenar posts
  const filteredAndSortedPosts = posts
    .filter(post => {
      const matchesSearch = post.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           post.resumo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      const matchesCategory = filterCategory === 'todas' || post.categoria === filterCategory
      return matchesSearch && matchesCategory
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'data-desc':
          return new Date(b.data) - new Date(a.data)
        case 'data-asc':
          return new Date(a.data) - new Date(b.data)
        case 'visualizacoes-desc':
          return b.visualizacoes - a.visualizacoes
        case 'titulo-asc':
          return a.titulo.localeCompare(b.titulo)
        default:
          return 0
      }
    })

  // Paginação
  const totalPages = Math.ceil(filteredAndSortedPosts.length / postsPerPage)
  const startIndex = (currentPage - 1) * postsPerPage
  const currentPosts = filteredAndSortedPosts.slice(startIndex, startIndex + postsPerPage)

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  const getCategoryColor = (category) => {
    const colors = {
      'Educação': 'bg-blue-100 text-blue-700',
      'Parcerias': 'bg-green-100 text-green-700',
      'Eventos': 'bg-purple-100 text-purple-700',
      'Tecnologia': 'bg-orange-100 text-orange-700',
      'Conquistas': 'bg-yellow-100 text-yellow-700',
      'Projetos': 'bg-pink-100 text-pink-700'
    }
    return colors[category] || 'bg-gray-100 text-gray-700'
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="container mx-auto px-4 py-12">

          
          <div className="max-w-4xl">
            <h1 className="text-4xl font-bold mb-4">Todas as Publicações</h1>
            <p className="text-xl text-green-100">
              Acompanhe todas as novidades, projetos e conquistas da COOP RECICLA. 
              Fique por dentro das ações que estão transformando nossa comunidade.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filtros e Controles */}
        <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Busca */}
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                <Input
                  placeholder="Buscar por título, conteúdo ou tags..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Controles */}
            <div className="flex gap-3 items-center">
              {/* Filtro por Categoria */}
              <Select 
                value={filterCategory} 
                onValueChange={(value) => {
                  setFilterCategory(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger className="w-48">
                  <Filter className="mr-2" size={16} />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas as Categorias</SelectItem>
                  {categorias.map(categoria => (
                    <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Ordenação */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="data-desc">Mais Recentes</SelectItem>
                  <SelectItem value="data-asc">Mais Antigas</SelectItem>
                  <SelectItem value="visualizacoes-desc">Mais Visualizadas</SelectItem>
                  <SelectItem value="titulo-asc">Ordem Alfabética</SelectItem>
                </SelectContent>
              </Select>

              {/* Modo de Visualização */}
              <div className="flex border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid size={16} />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List size={16} />
                </Button>
              </div>
            </div>
          </div>

          {/* Estatísticas */}
          <div className="mt-4 pt-4 border-t flex items-center justify-between text-sm text-gray-600">
            <span>
              Mostrando {startIndex + 1}-{Math.min(startIndex + postsPerPage, filteredAndSortedPosts.length)} de {filteredAndSortedPosts.length} publicações
            </span>
            <span>
              Total de visualizações: {posts.reduce((total, post) => total + post.visualizacoes, 0).toLocaleString()}
            </span>
          </div>
        </div>

        {/* Lista de Publicações */}
        {currentPosts.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Search className="mx-auto mb-4 text-gray-400" size={48} />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Nenhuma publicação encontrada
              </h3>
              <p className="text-gray-600">
                Tente ajustar os termos de busca ou filtros para encontrar o que procura.
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            {viewMode === 'grid' ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
                {currentPosts.map((post) => (
                  <Card key={post.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div className="aspect-video bg-gradient-to-br from-green-400 to-green-600 overflow-hidden">
                      <img 
                        src={post.imagem} 
                        alt={post.titulo}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-3">
                        <Badge className={getCategoryColor(post.categoria)}>
                          {post.categoria}
                        </Badge>
                        <div className="flex items-center text-xs text-gray-500">
                          <Clock className="mr-1" size={12} />
                          {post.tempoLeitura}
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-bold text-gray-900 mb-3 line-clamp-2 leading-tight">
                        {post.titulo}
                      </h3>
                      
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                        {post.resumo}
                      </p>

                      <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                        <div className="flex items-center">
                          <Calendar className="mr-1" size={12} />
                          {formatDate(post.data)}
                        </div>
                        <div className="flex items-center">
                          <Eye className="mr-1" size={12} />
                          {post.visualizacoes}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-xs text-gray-600">
                          <User className="mr-1" size={12} />
                          {post.autor}
                        </div>
                        <Button size="sm" variant="outline" className="text-green-600 border-green-600 hover:bg-green-50">
                          Ler Mais
                          <ArrowRight className="ml-1" size={12} />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-6 mb-8">
                {currentPosts.map((post) => (
                  <Card key={post.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex gap-6">
                        <div className="flex-shrink-0">
                          <div className="w-32 h-24 bg-gray-200 rounded-lg overflow-hidden">
                            <img 
                              src={post.imagem} 
                              alt={post.titulo}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <Badge className={getCategoryColor(post.categoria)}>
                                {post.categoria}
                              </Badge>
                              <div className="flex items-center text-xs text-gray-500">
                                <Clock className="mr-1" size={12} />
                                {post.tempoLeitura}
                              </div>
                            </div>
                            <div className="flex items-center text-xs text-gray-500">
                              <Eye className="mr-1" size={12} />
                              {post.visualizacoes}
                            </div>
                          </div>

                          <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-1">
                            {post.titulo}
                          </h3>

                          <p className="text-gray-600 mb-3 line-clamp-2">
                            {post.resumo}
                          </p>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <div className="flex items-center">
                                <Calendar className="mr-1" size={12} />
                                {formatDate(post.data)}
                              </div>
                              <div className="flex items-center">
                                <User className="mr-1" size={12} />
                                {post.autor}
                              </div>
                            </div>

                            <Button size="sm" variant="outline" className="text-green-600 border-green-600 hover:bg-green-50">
                              Ler Mais
                              <ArrowRight className="ml-1" size={12} />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Paginação */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Anterior
                </Button>
                
                {Array.from({ length: totalPages }, (_, index) => index + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? 'default' : 'outline'}
                    onClick={() => setCurrentPage(page)}
                    className={currentPage === page ? 'bg-green-600 hover:bg-green-700' : ''}
                  >
                    {page}
                  </Button>
                ))}

                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Próxima
                </Button>
              </div>
            )}
          </>
        )}

        {/* Tags Populares */}
        <div className="bg-white rounded-lg p-6 mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Tags Populares</h3>
          <div className="flex flex-wrap gap-2">
            {todasTags.slice(0, 15).map((tag) => (
              <Button
                key={tag}
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchTerm(tag)
                  setCurrentPage(1)
                }}
                className="text-xs hover:bg-green-50 hover:border-green-600 hover:text-green-600"
              >
                <Tag className="mr-1" size={10} />
                {tag}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default TodasPublicacoesPage
