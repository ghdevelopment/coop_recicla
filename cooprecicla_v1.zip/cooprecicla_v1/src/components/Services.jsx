// Services.jsx
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { ArrowRight, CheckCircle } from 'lucide-react'
import pevImg from '@/assets/pev.png'
import cacambaImg from '@/assets/cacamba.png'
import educacaoAmbientalImg from '@/assets/educacao-ambiental.png'

const ServiceCard = ({ service, index }) => {
  const hasImage = Boolean(service.image)
  const isEducacao = service.title === 'Educação Ambiental'

  // FALLBACKS
  const wrapDefault = 'w-full max-w-[560px] h-48 md:h-56 xl:h-60'
  const scaleDefault = 'scale-[1.00]'
  const haloDefault   = 'w-[86%] h-[56%] bg-black/15 blur-xl opacity-45'

  const wrapClass  = service.imageWrapClass    || wrapDefault
  const scaleClass = service.imageScaleClasses || scaleDefault
  const haloClass  = service.haloClass || haloDefault

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 flex flex-col h-full">
      {/* Cabeçalho */}
      <div className="bg-white text-center relative px-6 pt-6 pb-4">
        <div className="min-h-[84px] md:min-h-[92px] flex flex-col items-center justify-center">
          {!hasImage && (
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-3">
              {service.icon}
            </div>
          )}
          <h4 className="text-2xl font-bold text-green-600">{service.title}</h4>
        </div>

        {/* Imagem */}
        {hasImage && (
          <div className="relative flex justify-center mt-4">
            <div className={`relative mx-auto ${wrapClass}`}>
              {/* halo/chão (omitido se haloClass for vazio) */}
              {haloClass && (
                <div
                  aria-hidden
                  className={`absolute left-1/2 -translate-x-1/2 bottom-2 rounded-[999px] ${haloClass}`}
                />
              )}
              {/* imagem */}
              <img
                src={service.image}
                alt={service.title}
                loading="lazy"
                decoding="async"
                className={[
                  'absolute inset-0 w-full h-full object-contain origin-center',
                  isEducacao
                    ? 'rounded-xl drop-shadow-none filter-none' // sem sombra aqui
                    : 'drop-shadow-[0_10px_22px_rgba(0,0,0,0.20)]',
                  scaleClass
                ].join(' ')}
              />
            </div>
          </div>
        )}
      </div>

      {/* Conteúdo */}
      <div className="p-6 flex flex-col flex-1 space-y-6">
        <p className="text-gray-600 leading-relaxed">{service.description}</p>

        <div className="space-y-3">
          {service.features.map((feature, i) => (
            <div key={i} className="flex items-center space-x-3">
              <CheckCircle className="text-green-600 flex-shrink-0" size={16} />
              <span className="text-gray-700 text-sm">{feature}</span>
            </div>
          ))}
        </div>

        <div className="mt-auto">
          <Link
            to={
              index === 0
                ? '/servicos/coleta-seletiva'
                : index === 1
                ? '/servicos/cacamba-ecologica'
                : '/servicos/educacao-ambiental'
            }
          >
            <Button className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 rounded-full">
              Saiba Mais <ArrowRight className="ml-2" size={16} />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

const Services = () => {
  const COMMON_WRAP = 'w-full max-w-[560px] h-48 md:h-56 xl:h-60'

  const services = [
    {
      title: 'Coleta Seletiva',
      description:
        'Serviço completo de coleta seletiva para empresas e condomínios, com cronograma personalizado.',
      features: [
        'Coleta programada',
        'Relatórios mensais',
        'Certificados ambientais',
        'Rastreabilidade completa',
      ],
      image: pevImg,
      imageWrapClass: COMMON_WRAP,
      imageScaleClasses:
        'scale-[1.35] sm:scale-[1.25] md:scale-[1.25] lg:scale-[1.15] xl:scale-[1.25]',
      haloClass: 'w-[82%] h-[54%] bg-black/12 blur-xl opacity-40',
    },
    {
      title: 'Caçamba Ecológica',
      description:
        'Aluguel de caçambas ecológicas para empresas com diferentes capacidades e planos flexíveis de coleta.',
      features: [
        'Diferentes tamanhos',
        'Planos semanais, quinzenais e mensais',
        'Coleta programada',
        'Destinação certificada',
      ],
      image: cacambaImg,
      imageWrapClass: COMMON_WRAP,
      imageScaleClasses:
        'scale-[1.00] sm:scale-[1.02] md:scale-[1.00] lg:scale-[1.18] xl:scale-[1.00]',
      haloClass: 'w-[88%] h-[56%] bg-black/15 blur-xl opacity-45',
    },
    {
      title: 'Educação Ambiental',
      description:
        'Programas de conscientização e educação ambiental para escolas, empresas e comunidades.',
      features: [
        'Palestras educativas',
        'Material didático',
        'Workshops práticos',
        'Acompanhamento pedagógico',
      ],
      image: educacaoAmbientalImg,
      imageWrapClass: COMMON_WRAP,
      imageScaleClasses:
        'scale-[1.2] sm:scale-[1.2] md:scale-[1.2] lg:scale-[1.2] xl:scale-[1.18]',
      haloClass: '', 
    },
  ]

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-sm font-semibold text-green-600 uppercase tracking-wide mb-4">
            Nossos Serviços
          </h2>
          <h3 className="text-4xl font-bold text-gray-900 mb-6">
            Soluções Completas em Gestão de Resíduos
          </h3>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Oferecemos serviços especializados para empresas, condomínios e
            instituições que buscam destinação ambientalmente correta de seus
            resíduos.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <ServiceCard key={service.title} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Services
