import express from 'express'
import { z } from 'zod'
import { db, findOrCreateTagsByNames, getWorkTags, setWorkTags } from '../database.js'
import { requireAuth } from '../middleware/auth.js'
import { nanoid } from 'nanoid'
import { deleteImageFile } from '../utils/fileManager.js'

const router = express.Router()

const WorkSchema = z.object({
  title: z.string().min(3),
  author: z.string().min(2).optional(),
  category: z.enum(['academic', 'books', 'articles', 'manuals', 'children', 'law']).optional(),
  year: z.number().int().min(1900).max(new Date().getFullYear() + 1).optional(),
  pages: z.number().int().min(1).max(10000).optional(),
  description: z.string().min(5).max(1000),
  url: z.string().url().optional(),
  downloadUrl: z.string().url().optional().or(z.literal('#')).optional(),
  previewUrl: z.string().url().optional().or(z.literal('#')).optional(),
  image: z.string().optional(),
  tags: z.array(z.string()).optional()
})

router.get('/', async (req, res) => {
  const { category, tag, search, sort } = req.query
  
  let query = 'SELECT * FROM works WHERE 1=1'
  const params = []
  
  if (category) {
    query += ' AND category = ?'
    params.push(category)
  }
  
  if (tag) {
    const tagRecord = db.prepare('SELECT id FROM tags WHERE slug = ? OR name = ?').get(tag, tag)
    if (tagRecord) {
      query += ' AND id IN (SELECT work_id FROM work_tags WHERE tag_id = ?)'
      params.push(tagRecord.id)
    } else {
      return res.json([])
    }
  }
  
  if (search) {
    const s = `%${search.toLowerCase()}%`
    query += ' AND (LOWER(title) LIKE ? OR LOWER(author) LIKE ? OR LOWER(description) LIKE ?)'
    params.push(s, s, s)
  }
  
  // Ordenação
  const srt = sort || '-createdAt'
  if (srt === '-createdAt') {
    query += ' ORDER BY created_at DESC'
  } else if (srt === 'createdAt') {
    query += ' ORDER BY created_at ASC'
  }
  
  const works = db.prepare(query).all(...params)
  const mapped = works.map((w) => ({
    ...w,
    // Converte snake_case do SQLite para camelCase do front-end
    previewUrl: w.preview_url,
    downloadUrl: w.download_url,
    createdAt: w.created_at,
    updatedAt: w.updated_at,
    tags: getWorkTags(w.id)
  }))
  
  res.json(mapped)
})

router.post('/', requireAuth, async (req, res) => {
  const parse = WorkSchema.safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  
  const { tags = [], url, ...data } = parse.data
  const tagIds = findOrCreateTagsByNames(tags)
  
  const now = new Date().toISOString()
  const id = nanoid()
  
  const stmt = db.prepare(`
    INSERT INTO works (
      id, title, author, category, year, pages, description, preview_url, download_url, image, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `)
  
  stmt.run(
    id,
    data.title,
    data.author || null,
    data.category || 'academic',
    data.year || null,
    data.pages || null,
    data.description,
    data.previewUrl || url || '#',
    data.downloadUrl || '#',
    data.image || null,
    now,
    now
  )
  
  setWorkTags(id, tagIds)
  
  const work = db.prepare('SELECT * FROM works WHERE id = ?').get(id)
  res.status(201).json({
    ...work,
    previewUrl: work.preview_url,
    downloadUrl: work.download_url,
    createdAt: work.created_at,
    updatedAt: work.updated_at,
    tags: getWorkTags(id)
  })
})

router.put('/:id', requireAuth, async (req, res) => {
  const parse = WorkSchema.partial().safeParse(req.body)
  if (!parse.success) return res.status(400).json({ error: 'Dados inválidos' })
  
  const current = db.prepare('SELECT * FROM works WHERE id = ?').get(req.params.id)
  if (!current) return res.status(404).json({ error: 'Não encontrado' })
  
  const { tags, url, ...data } = parse.data
  
  const updates = []
  const params = []
  
  if (data.title !== undefined) {
    updates.push('title = ?')
    params.push(data.title)
  }
  if (data.author !== undefined) {
    updates.push('author = ?')
    params.push(data.author || null)
  }
  if (data.category !== undefined) {
    updates.push('category = ?')
    params.push(data.category)
  }
  if (data.year !== undefined) {
    updates.push('year = ?')
    params.push(data.year)
  }
  if (data.pages !== undefined) {
    updates.push('pages = ?')
    params.push(data.pages)
  }
  if (data.description !== undefined) {
    updates.push('description = ?')
    params.push(data.description)
  }
  if (data.previewUrl !== undefined || url !== undefined) {
    updates.push('preview_url = ?')
    params.push(data.previewUrl || url || current.preview_url)
  }
  if (data.downloadUrl !== undefined) {
    updates.push('download_url = ?')
    params.push(data.downloadUrl)
  }
  if (data.image !== undefined) {
    updates.push('image = ?')
    params.push(data.image || null)
  }
  
  updates.push('updated_at = ?')
  params.push(new Date().toISOString())
  
  params.push(req.params.id)
  
  if (updates.length > 0) {
    const query = `UPDATE works SET ${updates.join(', ')} WHERE id = ?`
    db.prepare(query).run(...params)
  }
  
  if (tags) {
    const tagIds = findOrCreateTagsByNames(tags)
    setWorkTags(req.params.id, tagIds)
  }
  
  const updated = db.prepare('SELECT * FROM works WHERE id = ?').get(req.params.id)
  res.json({
    ...updated,
    previewUrl: updated.preview_url,
    downloadUrl: updated.download_url,
    createdAt: updated.created_at,
    updatedAt: updated.updated_at,
    tags: getWorkTags(req.params.id)
  })
})

router.delete('/:id', requireAuth, async (req, res) => {
  const work = db.prepare('SELECT * FROM works WHERE id = ?').get(req.params.id)
  if (!work) return res.status(404).json({ error: 'Não encontrado' })
  
  db.prepare('DELETE FROM works WHERE id = ?').run(req.params.id)
  
  // ⚡ REMOÇÃO EM CASCATA: Deleta a imagem associada
  if (work.image) {
    deleteImageFile(work.image)
  }
  
  res.status(204).end()
})

export default router
