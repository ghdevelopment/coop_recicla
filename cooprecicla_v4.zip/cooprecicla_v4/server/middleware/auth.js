import jwt from 'jsonwebtoken'
import { isBlacklisted } from '../utils/tokenBlacklist.js'

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : null
  if (!token) return res.status(401).json({ error: 'Não autorizado' })
  
  // ⚡ PROTEÇÃO: Verifica se o token está na blacklist
  if (isBlacklisted(token)) {
    return res.status(401).json({ error: 'Token revogado' })
  }
  
  try {
    const secret = process.env.JWT_SECRET || 'dev-secret-change-me'
    const payload = jwt.verify(token, secret)
    req.user = payload
    req.token = token // Armazena o token para uso posterior (ex: logout)
    next()
  } catch (e) {
    return res.status(401).json({ error: 'Token inválido' })
  }
}
