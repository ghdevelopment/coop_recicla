/**
 * Sistema de blacklist de tokens JWT
 * Armazena tokens revogados em memória com expiração automática
 */

// Map para armazenar tokens revogados: token -> expiresAt
const blacklist = new Map()

/**
 * Adiciona um token à blacklist
 * @param {string} token - Token JWT a ser revogado
 * @param {number} expiresAt - Timestamp de expiração do token (em ms)
 */
export function addToBlacklist(token, expiresAt) {
  if (!token) return
  blacklist.set(token, expiresAt)
  console.log(`[tokenBlacklist] Token adicionado à blacklist (expira em ${new Date(expiresAt).toISOString()})`)
}

/**
 * Verifica se um token está na blacklist
 * @param {string} token - Token JWT a ser verificado
 * @returns {boolean} - true se o token está revogado, false caso contrário
 */
export function isBlacklisted(token) {
  if (!token) return false
  
  const expiresAt = blacklist.get(token)
  if (!expiresAt) return false
  
  // Se o token já expirou naturalmente, remove da blacklist
  if (Date.now() > expiresAt) {
    blacklist.delete(token)
    return false
  }
  
  return true
}

/**
 * Remove um token da blacklist (raramente necessário)
 * @param {string} token - Token JWT a ser removido
 * @returns {boolean} - true se removido, false se não estava na blacklist
 */
export function removeFromBlacklist(token) {
  return blacklist.delete(token)
}

/**
 * Limpa tokens expirados da blacklist
 * Deve ser executado periodicamente para liberar memória
 * @returns {number} - Quantidade de tokens removidos
 */
export function cleanExpiredTokens() {
  const now = Date.now()
  let removedCount = 0
  
  for (const [token, expiresAt] of blacklist.entries()) {
    if (now > expiresAt) {
      blacklist.delete(token)
      removedCount++
    }
  }
  
  if (removedCount > 0) {
    console.log(`[tokenBlacklist] ${removedCount} token(s) expirado(s) removido(s) da blacklist`)
  }
  
  return removedCount
}

/**
 * Retorna estatísticas da blacklist
 * @returns {object} - Objeto com estatísticas
 */
export function getBlacklistStats() {
  const now = Date.now()
  let activeCount = 0
  let expiredCount = 0
  
  for (const [, expiresAt] of blacklist.entries()) {
    if (now > expiresAt) {
      expiredCount++
    } else {
      activeCount++
    }
  }
  
  return {
    total: blacklist.size,
    active: activeCount,
    expired: expiredCount
  }
}

/**
 * Limpa toda a blacklist (use com cuidado!)
 */
export function clearBlacklist() {
  const size = blacklist.size
  blacklist.clear()
  console.log(`[tokenBlacklist] Blacklist limpa (${size} token(s) removido(s))`)
}

// Limpeza automática de tokens expirados a cada 1 hora
setInterval(() => {
  cleanExpiredTokens()
}, 60 * 60 * 1000)

// Limpeza inicial ao carregar o módulo
cleanExpiredTokens()
