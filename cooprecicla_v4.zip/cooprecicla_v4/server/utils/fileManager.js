import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const uploadsDir = path.resolve(__dirname, '..', 'uploads')

/**
 * Extrai o nome do arquivo de uma URL ou caminho
 * @param {string} imageUrl - URL ou caminho da imagem (ex: "/api/uploads/123.jpg" ou "https://...")
 * @returns {string|null} - Nome do arquivo ou null se não for local
 */
export function extractFilename(imageUrl) {
  if (!imageUrl || typeof imageUrl !== 'string') return null
  
  // Verifica se é um caminho local do servidor
  if (imageUrl.startsWith('/api/uploads/')) {
    return imageUrl.replace('/api/uploads/', '')
  }
  
  // Se for URL externa, não gerenciamos
  if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
    return null
  }
  
  return null
}

/**
 * Deleta um arquivo de imagem do disco
 * @param {string} imageUrl - URL ou caminho da imagem
 * @returns {boolean} - true se deletado com sucesso, false caso contrário
 */
export function deleteImageFile(imageUrl) {
  const filename = extractFilename(imageUrl)
  if (!filename) return false
  
  const filepath = path.join(uploadsDir, filename)
  
  try {
    if (fs.existsSync(filepath)) {
      fs.unlinkSync(filepath)
      console.log(`[fileManager] Arquivo deletado: ${filename}`)
      return true
    } else {
      console.warn(`[fileManager] Arquivo não encontrado: ${filename}`)
      return false
    }
  } catch (error) {
    console.error(`[fileManager] Erro ao deletar arquivo ${filename}:`, error)
    return false
  }
}

/**
 * Deleta múltiplos arquivos de imagem
 * @param {string[]} imageUrls - Array de URLs ou caminhos de imagens
 * @returns {number} - Quantidade de arquivos deletados com sucesso
 */
export function deleteMultipleImages(imageUrls) {
  if (!Array.isArray(imageUrls)) return 0
  
  let deletedCount = 0
  for (const url of imageUrls) {
    if (deleteImageFile(url)) {
      deletedCount++
    }
  }
  
  return deletedCount
}

/**
 * Verifica se um arquivo existe no diretório de uploads
 * @param {string} filename - Nome do arquivo
 * @returns {boolean} - true se existe, false caso contrário
 */
export function fileExists(filename) {
  if (!filename) return false
  const filepath = path.join(uploadsDir, filename)
  return fs.existsSync(filepath)
}

/**
 * Lista todos os arquivos órfãos (não referenciados no banco)
 * @param {object} db - Instância do banco de dados
 * @returns {string[]} - Array de nomes de arquivos órfãos
 */
export async function findOrphanFiles(db) {
  await db.read()
  
  // Coleta todas as imagens referenciadas no banco
  const referencedImages = new Set()
  
  // Posts
  for (const post of db.data.posts) {
    if (post.imagem) {
      const filename = extractFilename(post.imagem)
      if (filename) referencedImages.add(filename)
    }
  }
  
  // Works
  for (const work of db.data.works) {
    if (work.image) {
      const filename = extractFilename(work.image)
      if (filename) referencedImages.add(filename)
    }
  }
  
  // Lista todos os arquivos no diretório uploads
  const allFiles = fs.readdirSync(uploadsDir)
  
  // Identifica órfãos
  const orphans = allFiles.filter(file => !referencedImages.has(file))
  
  return orphans
}

/**
 * Limpa arquivos órfãos do diretório de uploads
 * @param {object} db - Instância do banco de dados
 * @returns {number} - Quantidade de arquivos deletados
 */
export async function cleanOrphanFiles(db) {
  const orphans = await findOrphanFiles(db)
  
  let deletedCount = 0
  for (const filename of orphans) {
    const filepath = path.join(uploadsDir, filename)
    try {
      fs.unlinkSync(filepath)
      console.log(`[fileManager] Órfão deletado: ${filename}`)
      deletedCount++
    } catch (error) {
      console.error(`[fileManager] Erro ao deletar órfão ${filename}:`, error)
    }
  }
  
  return deletedCount
}
