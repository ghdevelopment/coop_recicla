import { ExternalLink, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import planetaImage from '../assets/planeta.webp'
import pegadaImage from '../assets/pegada.webp'

const EcologicalFootprint = () => {
  return (
    <section id="ecological-footprint" className="relative overflow-hidden bg-green-600/95 py-24">
      {/* planeta decorativo à direita */}
      <img
        src={planetaImage}
        alt="Planeta Terra"
        aria-hidden="true"
        className="pointer-events-none select-none absolute right-[12%] top-1/2 -translate-y-1/2 w-[500px] opacity-25 hidden lg:block animate-slow-spin"
        draggable="false"
      />



      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl">
          {/* cabeçalho com ícone e título */}
          <div className="flex items-center gap-3 mb-4 text-white">
            <div className="bg-white p-3 rounded-full w-[56px] h-[56px] flex items-center justify-center overflow-hidden">
              <img
                src={pegadaImage}
                alt="Ícone de pegada ecológica"
                className="w-8 h-8 object-contain select-none pointer-events-none"
                draggable="false"
              />
            </div>
            <h2 className="text-sm font-semibold uppercase tracking-wide">
              Calculadora de Pegada Ecológica
            </h2>
          </div>

          {/* título principal */}
          <h3 className="text-4xl font-bold text-white leading-tight mb-4">
            Descubra Seu Impacto no Planeta
          </h3>

          {/* descrição */}
          <p className="text-lg text-green-50 leading-relaxed mb-6">
            Descubra quantos planetas seriam necessários se todos vivessem como
            você. Responda perguntas simples e receba insights sobre como
            reduzir seu impacto ambiental.
          </p>

          {/* lista de vantagens */}
          <ul className="space-y-3 mb-8">
            {[
              'Avaliação rápida e gratuita',
              'Dicas personalizadas para reduzir seu impacto',
              'Baseado em dados científicos confiáveis',
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-3 text-green-50">
                <CheckCircle className="text-yellow-400" size={20} />
                <span>{item}</span>
              </li>
            ))}
          </ul>

          {/* botão principal */}
          <Button
            asChild
            size="lg"
            className="bg-white text-green-700 hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold shadow-md"
          >
            <a
              href="https://www.footprintcalculator.org/home/pt"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Abrir calculadora de pegada ecológica"
            >
              Calcular Minha Pegada
              <ExternalLink className="ml-2" size={20} />
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}

export default EcologicalFootprint
