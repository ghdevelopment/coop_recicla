import { useState, useEffect } from 'react'
import {
  Search, Filter, Calendar, Tag, Eye, ArrowRight,
  Clock, User, ArrowLeft
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Link, useNavigate } from 'react-router-dom'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { api } from '@/lib/api'

const categorias = [
  'Comunidade',
  'Conquistas',
  'Educação',
  'Eventos',
  'Parcerias',
  'Projetos',
  'Tecnologia'
]

const TodasPublicacoesPage = () => {
  // ===== Dados =====
  const [posts, setPosts] = useState([])
  useEffect(() => {
    const load = async () => {
      const data = await api.listPosts({ status: 'Publicado', sort: '-data' })
      setPosts(
        data.map((p) => ({
          id: p.id,
          titulo: p.titulo,
          resumo: p.resumo,
          data: p.data,
          categoria: p.categoria,
          autor: p.autor,
          imagem: p.imagem,
          tags: (p.tags || []).map((t) => t.name),
        }))
      )
    }
    load()
  }, [])

  // ===== Estado de UI =====
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('todas')
  const [sortBy, setSortBy] = useState('data-desc')
  const [currentPage, setCurrentPage] = useState(1)
  const postsPerPage = 6

  // ===== Utilitários =====
  const todasTags = [...new Set(posts.flatMap((post) => post.tags))]

  const filteredAndSortedPosts = posts
    .filter((post) => {
      const s = searchTerm.toLowerCase()
      const matchesSearch =
        post.titulo.toLowerCase().includes(s) ||
        post.resumo.toLowerCase().includes(s) ||
        post.tags.some((tag) => tag.toLowerCase().includes(s))
      const matchesCategory = filterCategory === 'todas' || post.categoria === filterCategory
      return matchesSearch && matchesCategory
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'data-desc': return new Date(b.data) - new Date(a.data)
        case 'data-asc': return new Date(a.data) - new Date(b.data)
        case 'titulo-asc': return a.titulo.localeCompare(b.titulo)
        default: return 0
      }
    })

  const totalPages = Math.ceil(filteredAndSortedPosts.length / postsPerPage)
  const startIndex = (currentPage - 1) * postsPerPage
  const currentPosts = filteredAndSortedPosts.slice(startIndex, startIndex + postsPerPage)

  const formatDate = (d) =>
    new Date(d).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })

  const getCategoryColor = (category) => {
    const colors = {
      Educação: 'bg-blue-100 text-blue-700',
      Parcerias: 'bg-green-100 text-green-700',
      Eventos: 'bg-purple-100 text-purple-700',
      Tecnologia: 'bg-orange-100 text-orange-700',
      Conquistas: 'bg-yellow-100 text-yellow-700',
      Projetos: 'bg-pink-100 text-pink-700',
      Comunidade: 'bg-gray-100 text-gray-700',
    }
    return colors[category] || 'bg-gray-100 text-gray-700'
  }

  const navigate = useNavigate()
  const go = (id) => navigate(`/novidades/publicacoes/${id}`)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER PADRÃO (mesmo estilo do site/notícias) */}
      <div className="bg-green-600 text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="mb-6">
            <Link to="/novidades">
              <Button
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white rounded-full px-6 py-2 flex items-center gap-2 transition-all">
                <ArrowLeft size={20} />
                Voltar
              </Button>
            </Link>
          </div>
          <div className="max-w-4xl">
            <h1 className="text-4xl font-bold mb-4">Todas as Publicações</h1>
            <p className="text-xl text-green-100">
              Acompanhe todas as novidades, projetos e conquistas da COOP-RECICLA.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* FILTROS / CONTROLES */}
        <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 lg:gap-6 justify-between flex-wrap">
            {/* Busca (fluída) */}
            <div className="w-full lg:flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-green-700" size={16} />
                <Input
                  placeholder="Buscar por título, conteúdo ou tags..."
                  value={searchTerm}
                  onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1) }}
                  className="pl-10 h-11 w-full sm:w-[32rem] md:w-[36rem] lg:w-full max-w-full"
                />
              </div>
            </div>

            {/* Controles à direita — padronizados com sublinhado verde */}
            <div className="w-full lg:w-auto flex flex-col sm:flex-row gap-3 items-stretch sm:items-center flex-wrap">
              {/* Categoria com sublinhado verde */}
              <Select
                value={filterCategory}
                onValueChange={(value) => { setFilterCategory(value); setCurrentPage(1) }}
                className="h-[46px] border-green-600 text-green-700 hover:bg-green-50 flex items-center gap-2"
              >
                <SelectTrigger className="w-full sm:w-56 shrink-0 h-46 border-0 border-b-2 rounded-none focus:ring-0 focus:outline-none border-gray-200 focus:border-green-600">
                  <Filter size={16} className="mr-2 text-green-700" />
                  <SelectValue placeholder="Todas as Categorias" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas as Categorias</SelectItem>
                  {categorias.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Ordenação com sublinhado verde */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-48 shrink-0 h-11 border-0 border-b-2 rounded-none focus:ring-0 focus:outline-none border-gray-200 focus:border-green-600">
                  <Filter size={16} className="mr-2 text-green-700" />
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="data-desc">Mais Recentes</SelectItem>
                  <SelectItem value="data-asc">Mais Antigas</SelectItem>
                  <SelectItem value="titulo-asc">Título (A-Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Estatísticas */}
          <div className="mt-4 pt-4 border-t grid gap-2 sm:flex sm:items-center sm:justify-between text-sm text-gray-600">
            <span>
              Mostrando {startIndex + 1}-{Math.min(startIndex + postsPerPage, filteredAndSortedPosts.length)} de {filteredAndSortedPosts.length} publicações
            </span>
          </div>
        </div>

        {/* LISTA (apenas GRID) */}
        {currentPosts.length === 0 ? (
          <div className="bg-white rounded-lg p-12 text-center shadow-sm">
            <Search className="mx-auto mb-4 text-gray-400" size={48} />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Nenhuma publicação encontrada
            </h3>
            <p className="text-gray-600">
              Tente ajustar os termos de busca ou filtros para encontrar o que procura.
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 mb-8">
              {currentPosts.map((post) => (
                <div
                  key={post.id}
                  role="article"
                  aria-label={post.titulo}
                  className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col h-full cursor-pointer"
                  onClick={() => go(post.id)}
                >
                  {/* Capa – mesmo padrão do card que já funciona */}
                  <Link to={`/novidades/publicacoes/${post.id}`} className="block">
                    <div className="relative w-full bg-gray-100 overflow-hidden">
                      {/* Alturas por breakpoint; em lg vira 16:9 */}
                      <div className="w-full h-80 sm:h-80 md:h-80 lg:h-80 xl:h-80">
                        <img
                          src={post.imagem}
                          alt={post.titulo}
                          className="w-full h-full object-cover transition-transform duration-300"
                          loading="lazy"
                          decoding="async"
                        />
                      </div>
                    </div>
                  </Link>

                  {/* Conteúdo */}
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-center justify-between mb-3">
                      <Badge className={getCategoryColor(post.categoria)}>
                        {post.categoria}
                      </Badge>
                    </div>

                    <h3 className="text-lg font-bold text-gray-900 mb-3 leading-tight line-clamp-2">
                      {post.titulo}
                    </h3>

                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {post.resumo}
                    </p>

                    <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                      <div className="flex items-center">
                        <User className="mr-1" size={12} />
                        {post.autor}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="mr-1" size={12} />
                        {formatDate(post.data)}
                      </div>
                    </div>

                    {/* Botão padrão */}
                    <div className="mt-auto">
                      <Button
                        onClick={(e) => {
                          e.stopPropagation()
                          go(post.id)
                        }}
                        className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 rounded-full"
                      >
                        Ler Mais <ArrowRight className="ml-2" size={16} />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Paginação (mantém igual) */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Anterior
                </Button>

                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? 'default' : 'outline'}
                    onClick={() => setCurrentPage(page)}
                    className={currentPage === page ? 'bg-green-600 hover:bg-green-700' : ''}
                  >
                    {page}
                  </Button>
                ))}

                <Button
                  variant="outline"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Próxima
                </Button>
              </div>
            )}
          </>
        )}


        {/* Tags Populares */}
        <div className="bg-white rounded-lg p-6 mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Tags Populares</h3>
          <div className="flex flex-wrap gap-2">
            {todasTags.slice(0, 15).map((tag) => (
              <Button
                key={tag}
                variant="outline"
                size="sm"
                onClick={() => { setSearchTerm(tag); setCurrentPage(1) }}
                className="text-xs hover:bg-green-50 hover:border-green-600 hover:text-green-600"
              >
                <Tag className="mr-1" size={10} />
                {tag}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default TodasPublicacoesPage
