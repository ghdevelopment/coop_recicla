import { Phone, Mail, MapPin, Heart } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import coopLogo from '../assets/coop-recicla-logo.webp'
import facebookLogo from '../assets/facebook.webp'
import instagramLogo from '../assets/Instagram.webp'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const quickLinks = [
    { name: "Início", href: "/inicio" },
    { name: "Quem Somos", href: "/quem-somos" },
    { name: "Serviços", href: "/servicos" },
    { name: "Sustentabilidade", href: "/sustentabilidade" },
    { name: "Novidades", href: "/novidades" },
    { name: "Biblioteca", href: "/recursos-educacionais" },
    { name: "Contato", href: "/contato" },
  ]

  const WHATSAPP_NUMBER = '5511999999999' // Substituir pelo número real da cooperativa
  const WHATSAPP_MESSAGE = 'Olá, gostaria de mais informações sobre os serviços da Cooprecicla.'
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`

	  const location = useLocation()
	
	  const handleAnchorClick = (e, targetId) => {
	    e.preventDefault()
	    if (location.pathname !== '/') {
	      window.location.href = `/#${targetId}`
	    } else {
	      const targetElement = document.getElementById(targetId)
	      if (targetElement) {
	        targetElement.scrollIntoView({ behavior: 'smooth' })
	      }
	    }
	  }

	  const services = [
	    { name: 'Coleta Seletiva', href: '/servicos/coleta-seletiva' },
	    { name: 'Caçamba Ecológica', href: '/servicos/cacamba-ecologica' },
	    { name: 'Educação Ambiental', href: '/servicos/educacao-ambiental' },
	    { name: 'Consultoria Ambiental', href: '/contato' } // Redireciona para o contato para solicitar consultoria
	  ]

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <Link to={'/inicio'} className='flex items-center space-x-3'>
                <img 
                  src={coopLogo} 
                  alt="COOP RECICLA Logo" 
                  className="h-25 w-auto"
                />
                <div>
                  <h3 className="text-xl font-bold text-white">COOP-RECICLA</h3>
                  <p className="text-gray-400 text-sm">Cooperativa de Reciclagem</p>
                </div>
            </Link>
            <p className="text-gray-300 leading-relaxed">
              Transformando resíduos em sustentabilidade desde 2008. 
              Comprometidos com o meio ambiente e o desenvolvimento social.
            </p>

	            <div className="flex space-x-4">
	              {/* Facebook */}
	              <a
	                href="https://www.facebook.com/cooprecicla" // Substituir pelo link real
	                target="_blank"
	                rel="noopener noreferrer"
	                aria-label="Facebook"
	                className="relative w-10 h-10 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
	              >
	                <img
	                  src={facebookLogo}
	                  alt="facebook logo"
	                  className="absolute inset-0 w-full h-full object-cover object-center block select-none pointer-events-none"
	                  draggable="false"
	                />
	              </a>
	
	              {/* Instagram */}
	              <a
	                href="https://www.instagram.com/cooprecicla" // Substituir pelo link real
	                target="_blank"
	                rel="noopener noreferrer"
	                aria-label="Instagram"
	                className="relative w-10 h-10 rounded-full overflow-hidden ring-1 ring-black/10 hover:ring-black/20 transition"
	              >
	                <img
	                  src={instagramLogo}
	                  alt="instagram logo"
	                  className="absolute inset-0 w-full h-full object-cover object-center block select-none pointer-events-none"
	                  draggable="false"
	                />
	              </a>
	            </div>

          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <Link 
                    to={link.href}
                    onClick={link.isAnchor ? (e) => handleAnchorClick(e, link.targetId) : undefined}
                    className="text-gray-300 hover:text-green-400 transition-colors duration-200"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Nossos Serviços</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
	                  <Link 
	                    to={service.href}
	                    className="text-gray-300 hover:text-green-400 transition-colors duration-200"
	                    onClick={(e) => {
	                      if (service.href.startsWith('/#')) {
	                        handleAnchorClick(e, service.href.substring(2))
	                      }
	                    }}
	                  >
	                    {service.name}
	                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contato</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Phone className="text-green-400 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-white font-medium">(64) 9 9260-3912</p>
                  <p className="text-gray-400 text-sm">Segunda a sexta, 07:00 às 17:00</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Mail className="text-green-400 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-white font-medium">coop-recicla@hotmail.com</p>
                  <p className="text-gray-400 text-sm">Resposta em até 24 horas</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="text-green-400 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-white font-medium">Rio Verde/GO</p>
                  <p className="text-gray-400 text-sm">Sudoeste Goiano</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-center items-center">
            <div className="text-gray-400 text-sm text-center">
              © {currentYear} COOP-RECICLA. Todos os direitos reservados.
            </div>
          </div>
        </div>
      </div>




    </footer>
  )
}

export default Footer
