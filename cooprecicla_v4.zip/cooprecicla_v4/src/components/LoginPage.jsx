// components/LoginPage.jsx
import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card'
import { api } from '@/lib/api'
import {
  ArrowLeft
} from 'lucide-react'

const LoginPage = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  // Se já estiver logado (token + user), vai direto pro painel /admin/painel
  useEffect(() => {
    const token = localStorage.getItem('token')
    const storedUser = localStorage.getItem('user')

    if (token && storedUser) {
      navigate('/admin/painel', { replace: true })
    }
  }, [navigate])

  const handleLogin = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const { token, user } = await api.login(username, password)
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))

      if (typeof onLoginSuccess === 'function') {
        onLoginSuccess(true)
      }

      // redireciona pro painel único do admin
      navigate('/admin/painel')
    } catch (err) {
      setError(err.message || 'Usuário ou senha inválidos.')
    }
  }

  return (

    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <Link to="/inicio">
            <Button
              variant="outline"
              className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 flex items-center gap-2 transition-all"
            >
              <ArrowLeft size={20} />
              Voltar
            </Button>
          </Link>
        </div>

        <Card className="w-full">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-green-700 mt-8">
              Login Administrativo
            </CardTitle>
            <CardDescription>
              Acesse o painel de gerenciamento do site
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username">Usuário</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="usuário"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {error && (
                <p className="text-red-500 text-sm text-center">{error}</p>
              )}
              <Button
                type="submit"
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Entrar
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>

  )
}

export default LoginPage
