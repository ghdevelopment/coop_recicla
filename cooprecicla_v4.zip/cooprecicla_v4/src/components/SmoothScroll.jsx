import { useEffect } from "react";
import { useLocation } from "react-router-dom";

const PATH_TO_ID = {
  "/": "hero",
  "/inicio": "hero",
  "/quem-somos": "about",
  "/servicos": "services",
  "/sustentabilidade": "sustainability",
  "/novidades": "blog",
  "/recursos-educacionais": "education",
  "/contato": "contact",
};

const EXTRA_OFFSET_MAP = {
  about: -50,
  services: -50,
  sustainability: -50,
  blog: -50,
  education: -50,
  contact: -50,
};

const SmoothScroll = () => {
  const location = useLocation();

  useEffect(() => {
    const scrollToIdBelowHeader = (id) => {
      const el = document.getElementById(id);
      if (!el) return;

      const headerEl = document.querySelector("header");
      const headerHeight = headerEl?.offsetHeight ?? 0;
      const extraOffset = EXTRA_OFFSET_MAP[id] ?? 0;

      const top =
        el.getBoundingClientRect().top +
        window.scrollY -
        (headerHeight + extraOffset);

      window.scrollTo({ top, behavior: "smooth" });
    };

    const id = PATH_TO_ID[location.pathname];

    if (id) {
      // Rota de seção da landing → rolar até a seção (com offset)
      setTimeout(() => scrollToIdBelowHeader(id), 150);
    } else {
      // Rota "página real" (ex.: /servicos/cacamba-ecologica) → ir ao topo
      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    // Permite rolar novamente ao clicar na mesma rota de seção
    const handleRepeatedClick = (e) => {
      const a = e.target.closest("a[href]");
      if (!a) return;

      const href = a.getAttribute("href");
      if (href === location.pathname) {
        const againId = PATH_TO_ID[href];
        if (againId) {
          e.preventDefault();
          scrollToIdBelowHeader(againId);
        }
      }
    };

    document.addEventListener("click", handleRepeatedClick);
    return () => document.removeEventListener("click", handleRepeatedClick);
  }, [location.pathname]);

  return null;
};

export default SmoothScroll;
