// App.jsx
import { Routes, Route, useLocation, useNavigate, Navigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./App.css";

import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Sustainability from "./components/Sustainability";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import SmoothScroll from "./components/SmoothScroll";
import Loading from "./components/Loading";
import BlogSection from "./components/BlogSection";
import EducationalResources from "./components/EducationalResources";
import EcologicalFootprint from "./components/EcologicalFootprint";

import LibraryPage from "./components/LibraryPage";
import ColetaSeletivaPage from "./components/ColetaSeletivaPage";
import CacambaEcologicaPage from "./components/CacambaEcologicaPage";
import EducacaoAmbientalPage from "./components/EducacaoAmbientalPage";
import AdminPage from "./components/AdminPage";
import TodasPublicacoesPage from "./components/TodasPublicacoesPage";
import LoginPage from "./components/LoginPage";
import WhatsAppButton from "./components/WhatsAppButton";
import PostPage from "./components/PostPage";
import { api } from "@/lib/api"; // ⬅ para eventualmente chamar /logout

// Landing Page (Home)
const HomePage = () => (
  <>
    <section id="hero">
      <Hero />
    </section>
    <section id="about" className="scroll-mt-28 md:scroll-mt-32">
      <About />
    </section>
    <section id="services" className="scroll-mt-28 md:scroll-mt-32">
      <Services />
    </section>
    <section id="sustainability" className="scroll-mt-28 md:scroll-mt-32">
      <Sustainability />
    </section>
    <section id="pegada-ecologica" className="scroll-mt-28 md:scroll-mt-32">
      <EcologicalFootprint />
    </section>
    <section id="blog" className="scroll-mt-28 md:scroll-mt-32">
      <BlogSection />
    </section>
    <section id="education" className="scroll-mt-28 md:scroll-mt-32">
      <EducationalResources />
    </section>
    <section id="contact" className="scroll-mt-28 md:scroll-mt-32">
      <Contact />
    </section>
  </>
);

// Layout principal
const MainLayout = ({ children }) => {
  const showWhatsAppButton = true;
  return (
    <>
      <Header />
      <main className="pt-0">{children}</main>
      <Footer />
      {showWhatsAppButton && <WhatsAppButton />}
    </>
  );
};

// Layout Auth (sem header/footer)
const AuthLayout = ({ children }) => <>{children}</>;

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLoginSuccess = () => setIsLoggedIn(true);

  const handleLogout = async () => {
    try {
      const token = localStorage.getItem("token");
      // opcional: chamar o backend para revogar o token
      if (token && api?.logout) {
        await api.logout();
      }
    } catch (e) {
      console.error("Erro ao fazer logout:", e);
    } finally {
      try {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
      } catch {}
      setIsLoggedIn(false);
      navigate("/inicio"); // 👈 depois de sair, volta pra /inicio
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) setIsLoggedIn(true);
  }, []);

  return (
    <div className="min-h-screen">
      <Loading />
      <SmoothScroll />

      <Routes>
        {/* Home */}
        <Route path="/" element={<MainLayout><HomePage /></MainLayout>} />

        {/* Páginas REAIS (fora da landing) */}
        <Route path="recursos-educacionais/biblioteca" element={<MainLayout><LibraryPage /></MainLayout>} />
        <Route path="servicos/coleta-seletiva" element={<MainLayout><ColetaSeletivaPage /></MainLayout>} />
        <Route path="servicos/cacamba-ecologica" element={<MainLayout><CacambaEcologicaPage /></MainLayout>} />
        <Route path="servicos/educacao-ambiental" element={<MainLayout><EducacaoAmbientalPage /></MainLayout>} />
        <Route path="novidades/publicacoes" element={<MainLayout><TodasPublicacoesPage /></MainLayout>} />
        <Route path="novidades/publicacoes/:id" element={<MainLayout><PostPage /></MainLayout>} />

        {/* Seções da landing page -> renderizam a Home */}
        {[
          "/inicio",
          "/quem-somos",
          "/servicos",
          "/sustentabilidade",
          "/novidades",
          "/recursos-educacionais",
          "/contato",
        ].map((p) => (
          <Route key={p} path={p} element={<MainLayout><HomePage /></MainLayout>} />
        ))}

        {/* /admin → sempre a tela de login (ela mesma redireciona se já tiver token) */}
        <Route
          path="/admin"
          element={
            <AuthLayout>
              <LoginPage onLoginSuccess={handleLoginSuccess} />
            </AuthLayout>
          }
        />

        {/* /admin/painel → se não estiver logado, redireciona para /admin */}
        <Route
          path="/admin/painel"
          element={
            isLoggedIn ? (
              <AuthLayout>
                <AdminPage onBack={handleLogout} />
              </AuthLayout>
            ) : (
              <Navigate to="/admin" replace />
            )
          }
        />


        {/* 404 */}
        <Route
          path="*"
          element={
            <div className="flex flex-col items-center justify-center min-h-screen text-center bg-gradient-to-b from-green-50 to-white text-gray-800 px-6">
              <h1 className="text-7xl font-extrabold text-green-600 mb-4 drop-shadow-sm">
                404
              </h1>
              <h2 className="text-2xl font-semibold mb-2">Página não encontrada</h2>
              <p className="text-gray-600 mb-6 max-w-md">
                A página que você procura pode ter sido reciclada ou movida.
              </p>
              <a
                href="/inicio"
                className="px-6 py-3 bg-green-600 text-white rounded-full shadow hover:bg-green-700 hover:shadow-lg transition-transform transform hover:-translate-y-1"
              >
                Voltar à página inicial
              </a>
            </div>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
